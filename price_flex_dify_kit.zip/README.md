# AI Price Flex — Dify Hackathon Implementation Kit

This package contains the working blueprint for a demo implementation of the **AI Price Flex** concept described in your slides.

## What is included
- `knowledge/` — product and governance knowledge documents for Dify
- `data/06_customers_100.csv` — 100 synthetic customers for analysis/dashboarding
- `data/07_demo_customers.json` — 5 hero customers for deterministic demo lookup
- `data/05_mock_ftp_policy.json` — simulated treasury/FTP assumptions
- `prompts/` — copy/paste prompts for the four Dify agent nodes
- `workflow/` — Dify workflow specification and Code node snippets
- `demo/` — mobile screen outline and 3-minute presentation script

## Recommended Dify setup
Use **Dify Cloud** for the hackathon. Start at https://dify.ai/pricing/dify-cloud . The current Sandbox plan is free and includes core app/workflow/knowledge capabilities with limited message credits; you can add your own model API key if the free credits are exhausted.

## Recommended app
Create one **Workflow** application named:
`AI Price Flex Engine`

## Four-agent pattern
`Customer -> Agent 1 ALCO/FTP -> Agent 2 Product Rate -> Agent 3 Dynamic Rate -> Guardrail -> Agent 4 Conductor -> Mobile Offer`

## Key design principle
The LLMs analyze/recommend; deterministic Code nodes perform exact lookup, eligibility and final-rate guardrails. This makes the demo much easier to explain and safer to reason about.

## Product sources used
OCBC Deposito IDR:
https://www.ocbc.id/id/individu/simpanan/deposito/deposito-idr

OCBC Tabungan Berjangka:
https://www.ocbc.id/id/individu/simpanan/tabungan-berjangka

OCBC TAKA:
https://www.ocbc.id/id/individu/simpanan/tabungan-berjangka/taka

## Disclaimer
This is a hackathon prototype. All customer data, FTP assumptions, price-flex uplifts, campaign rules and business KPIs in this kit are simulated and should not be presented as official OCBC pricing, policy or performance.
