"""
run_demo.py
Uji cepat pipeline Agent 1 -> 2 -> 3 -> (bagian rule Agent 4) TANPA perlu API
key LLM sama sekali -- langsung panggil fungsi Python-nya. Cocok untuk
memastikan logika inti sudah benar sebelum coba versi CrewAI penuh (yang
butuh API key & biaya token untuk bagian penulisan pesan natural).

Untuk versi lengkap dengan agent CrewAI + LLM menulis pesan notifikasi,
pakai: python3 -m src.crew (butuh ANTHROPIC_API_KEY atau ganti provider lain
di src/crew.py)

Jalankan: python3 run_demo.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.pricing_engine import FTPInput, calc_ftp, calc_base_product_rate
from src.dynamic_rate_model import DynamicRateAgent
from src.conductor_rules import CampaignWindow, should_send_offer, next_send_time_label


def run_pipeline(customer: dict, target_produk: str, market_context: dict, campaign: CampaignWindow, tanggal_cek: str):
    # Agent 1
    ftp_input = FTPInput(**market_context, )
    ftp = calc_ftp(ftp_input, tenor_bulan=customer["tenor_preference_bulan"])
    print(f"[Agent 1 - AI Alco/FTP] FTP tenor {customer['tenor_preference_bulan']} bulan: {ftp:.4%}")

    # Agent 2
    base_rate = calc_base_product_rate(ftp, target_produk)
    print(f"[Agent 2 - AI Product Rate] Base rate {target_produk}: {base_rate:.4%}")

    # Agent 3
    agent3 = DynamicRateAgent()
    rec = agent3.recommend(customer, target_produk, base_rate)
    print(f"[Agent 3 - AI Dynamic Rate] {rec}")

    # Agent 4 (bagian rule saja)
    decision = should_send_offer(campaign, tanggal_cek, target_produk, rec["eligible"])
    decision["waktu_kirim_disarankan"] = next_send_time_label(customer["jam_transaksi_favorit"])
    print(f"[Agent 4 - AI Conductor] {decision}")

    if decision["should_send"]:
        pesan = (
            f"Halo! Ada promo bunga hingga {rec['final_rate']:.2%} untuk "
            f"{target_produk} kamu bulan ini. Yuk cek di OCBC mobile sebelum "
            f"promo berakhir."
        )
        print(f"\n>>> Draf notifikasi (template, tanpa LLM): {pesan}")
    else:
        print("\n>>> Tidak ada notifikasi dikirim (tidak eligible atau di luar periode campaign).")

    return {"ftp": ftp, "base_rate": base_rate, "agent3": rec, "agent4": decision}


if __name__ == "__main__":
    market_context = {
        "base_cost_of_fund": 0.0550,
        "stock_of_money_ratio": 0.95,
        "demand_supply_index": 0.4,
        "competitor_benchmark": 0.0525,
        "market_trend_bps": 3,
    }
    campaign = CampaignWindow(
        nama_campaign="Price Flex Launch - TAKA Online",
        tanggal_mulai="2026-09-01",
        tanggal_selesai="2026-09-30",
        produk="TAKA Online",
    )

    # --- Contoh nasabah eligible & profil bagus (harus dapat rate tinggi) ---
    customer_bagus = {
        "customer_id": "CUST-DEMO-01",
        "usia": 32,
        "vintage_bulan": 48,
        "saldo_rata_rata": 55_000_000,
        "product_holding": 3,
        "profitability_score": 82,
        "engagement_score": 90,
        "jumlah_transaksi_bulanan": 18,
        "tenor_preference_bulan": 12,
        "jam_transaksi_favorit": "19:00-21:00",
    }
    print("=" * 70)
    print("CONTOH 1: Nasabah profil bagus")
    print("=" * 70)
    run_pipeline(customer_bagus, "TAKA Online", market_context, campaign, "2026-09-09")

    # --- Contoh nasabah tidak eligible (saldo kecil, tenor pendek) ---
    customer_kecil = {
        "customer_id": "CUST-DEMO-02",
        "usia": 24,
        "vintage_bulan": 3,
        "saldo_rata_rata": 800_000,
        "product_holding": 1,
        "profitability_score": 15,
        "engagement_score": 20,
        "jumlah_transaksi_bulanan": 2,
        "tenor_preference_bulan": 1,
        "jam_transaksi_favorit": "20:00-22:00",
    }
    print("\n" + "=" * 70)
    print("CONTOH 2: Nasabah saldo kecil (harus tidak eligible)")
    print("=" * 70)
    run_pipeline(customer_kecil, "TAKA Online", market_context, campaign, "2026-09-09")
