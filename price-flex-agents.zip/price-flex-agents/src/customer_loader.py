"""
customer_loader.py
Helper untuk memuat data nasabah dari data/customer_data.csv (300 baris
sintetis), supaya run_demo.py dan src/crew.py bisa dipakai dengan nasabah
mana pun -- tidak lagi hardcode 1 nasabah contoh saja.
"""
import os
import pandas as pd

CSV_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "customer_data.csv")


def list_customer_ids(n: int = 10) -> list[str]:
    """Kembalikan n customer_id pertama, untuk ditampilkan sebagai opsi."""
    df = pd.read_csv(CSV_PATH)
    return df["customer_id"].head(n).tolist()


def load_customer(customer_id: str | None = None) -> dict:
    """
    Ambil satu baris nasabah dari data/customer_data.csv sebagai dict,
    siap dipakai pipeline (run_demo.py / src/crew.py).

    Kalau customer_id=None, ambil baris PERTAMA (bukan acak, supaya hasilnya
    reproducible tiap kali dijalankan tanpa argumen).
    """
    df = pd.read_csv(CSV_PATH)

    if customer_id is None:
        row = df.iloc[0]
    else:
        match = df[df["customer_id"] == customer_id]
        if match.empty:
            contoh = ", ".join(df["customer_id"].head(5).tolist())
            raise ValueError(
                f"customer_id '{customer_id}' tidak ditemukan di data/customer_data.csv. "
                f"Contoh ID yang tersedia: {contoh}, ... (total {len(df)} baris)"
            )
        row = match.iloc[0]

    return {
        "customer_id": row["customer_id"],
        "usia": int(row["usia"]),
        "vintage_bulan": int(row["vintage_bulan"]),
        "saldo_rata_rata": int(row["saldo_rata_rata"]),
        "product_holding": int(row["product_holding"]),
        "profitability_score": int(row["profitability_score"]),
        "engagement_score": int(row["engagement_score"]),
        "jumlah_transaksi_bulanan": int(row["jumlah_transaksi_bulanan"]),
        "tenor_preference_bulan": int(row["tenor_preference_bulan"]),
        "jam_transaksi_favorit": row["jam_transaksi_favorit"],
        "target_produk": row["target_produk"],  # produk yang "cocok" untuk nasabah ini di data sintetis
    }


if __name__ == "__main__":
    print("10 customer_id pertama yang tersedia:")
    for cid in list_customer_ids():
        print(f"  - {cid}")
    print()
    print("Contoh load_customer('CUST-0003'):")
    print(load_customer("CUST-0003"))
