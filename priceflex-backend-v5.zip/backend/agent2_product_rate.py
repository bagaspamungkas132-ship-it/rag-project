"""
Agent 2 - AI Product Rate
Fungsi: menentukan margin per product berdasarkan FTP sehingga menghasilkan
harga dasar per product. Owner: Product Owner, Treasury.

Untuk hackathon: margin per product disederhanakan jadi dictionary tetap.
Di production, ini bisa jadi model optimasi margin berbasis elastisitas
volume/rate historis.

--- Kalibrasi Deposito Online ke rate publik OCBC ------------------------
DEPOSITO_ONLINE_AMOUNT_TIERS & DEPOSITO_ONLINE_MARGIN di bawah dikalibrasi
supaya get_base_rate("Deposito Online", ...) menghasilkan angka yang PERSIS
sama dengan "COUNTER RATE IDR - ONLINE (OCBC Mobile & Internet Banking)"
yang live di web OCBC per 2026-09-18 - screenshot referensi ada di riwayat
chat/README. Ini bukti bahwa base_rate PriceFlex bukan angka sintetis;
kalau tabel publik berubah, tinggal update angka margin di sini (FTP-nya
sendiri ada di data/ftp_curve.csv, terpisah - lihat agent1_ftp.py) supaya
base_rate tetap sinkron dengan rate card resmi.

Tabel publiknya di-tier per PLACEMENT AMOUNT (bukan segment nasabah) -
konsisten dengan cara bank umumnya melakukan "volume pricing" untuk deposito:
nasabah manapun yang taruh dana lebih besar dapat rate lebih baik, terlepas
dari segmennya. Segmentasi nasabah (MASS/PREMIER/dst) baru masuk nanti di
Agent 3 sebagai bagian dari eligibility target audience, bukan di sini.
"""
from agent1_ftp import get_ftp

# Margin (percentage points) added on top of FTP, varies by product & tenor.
# Dipakai untuk produk yang BELUM dikalibrasi ke rate publik (mis. TAKA
# Online) - lihat DEPOSITO_ONLINE_MARGIN di bawah untuk yang sudah.
MARGIN_TABLE = {
    ("TAKA Online", 3): 0.75,
    ("TAKA Online", 6): 0.85,
    ("TAKA Online", 12): 0.95,
    ("Deposito Online", 3): 0.60,
    ("Deposito Online", 6): 0.70,
    ("Deposito Online", 12): 0.85,
}

# Placement-amount tiers, sama persis dengan tabel Counter Rate publik:
#   T1: >= IDR 1 Jt  - <  IDR 500 Jt
#   T2: >= IDR 500 Jt - <= IDR 2 M
#   T3: >  IDR 2 M    - <= IDR 10 M
# (batas atas T1 EKSKLUSIF - persis kata "< IDR 500 Mio" di tabel publik,
# supaya IDR 500jt jatuh ke T2, bukan dobel-match ke T1)
DEPOSITO_ONLINE_TIER_CUTOFFS = [
    ("T1", 500_000_000),      # < 500jt -> T1
    ("T2", 2_000_000_000),    # < 2M (setelah lolos cutoff T1) -> T2
    ("T3", 10_000_000_000),   # sisanya -> T3
]

# Margin per (tier, tenor_months), dikalibrasi supaya FTP (data/ftp_curve.csv)
# + margin = angka persis di tabel Counter Rate publik:
#   T1, 1m/3m: 3.85 + 0.40 = 4.25%   T1, 6m/12m: 4.05 + 0.45 = 4.50%
#   T2, 1m/3m: 3.85 + 0.90 = 4.75%   T2, 6m/12m: 4.05 + 0.95 = 5.00%
#   T3 sama dengan T2 (tabel publiknya juga sama utk T2 & T3).
DEPOSITO_ONLINE_MARGIN = {
    ("T1", 1): 0.40, ("T1", 3): 0.40, ("T1", 6): 0.45, ("T1", 12): 0.45,
    ("T2", 1): 0.90, ("T2", 3): 0.90, ("T2", 6): 0.95, ("T2", 12): 0.95,
    ("T3", 1): 0.90, ("T3", 3): 0.90, ("T3", 6): 0.95, ("T3", 12): 0.95,
}


def get_amount_tier(placement_amount_idr: float) -> str:
    """Map a placement amount to its Counter Rate tier (T1/T2/T3), using
    half-open cutoffs matching the real table's ">= / <" wording exactly
    (so a boundary amount like IDR 500jt lands in T2, not T1). Amounts
    below IDR 1jt are clamped to T1 rather than raising an error - the
    demo shouldn't break just because a customer's AUM sits slightly
    outside the published range."""
    for label, upper_bound in DEPOSITO_ONLINE_TIER_CUTOFFS:
        if placement_amount_idr < upper_bound:
            return label
    return DEPOSITO_ONLINE_TIER_CUTOFFS[-1][0]  # >= largest cutoff -> top tier (T3)


def get_margin(product: str, tenor_months: int, placement_amount_idr: float | None = None) -> float:
    if product == "Deposito Online" and placement_amount_idr is not None:
        tier = get_amount_tier(placement_amount_idr)
        return DEPOSITO_ONLINE_MARGIN.get((tier, tenor_months), 0.70)
    return MARGIN_TABLE.get((product, tenor_months), 0.70)


def get_base_rate(
    segment: str,
    product: str,
    tenor_months: int,
    placement_amount_idr: float | None = None,
) -> float:
    """Base rate card = FTP (Agent 1) + margin (Agent 2).
    `placement_amount_idr` is required to reproduce the real published
    Counter Rate for Deposito Online (tiered by amount, not segment) - see
    module docstring. If omitted, falls back to the flat legacy margin."""
    ftp = get_ftp(segment, product, tenor_months)
    margin = get_margin(product, tenor_months, placement_amount_idr)
    return round(ftp + margin, 2)


if __name__ == "__main__":
    print("Deposito Online, 12 bulan, per placement amount tier:")
    for label, amount in [("T1", 100_000_000), ("T2", 500_000_000), ("T3", 5_000_000_000)]:
        rate = get_base_rate("Emerging Affluent", "Deposito Online", 12, placement_amount_idr=amount)
        tier = get_amount_tier(amount)
        print(f"  {label} (IDR {amount:,}, resolved tier={tier}): {rate}% p.a.")
    rate = get_base_rate("Emerging Affluent", "TAKA Online", 12)
    print(f"TAKA Online, 12 bulan (legacy, no amount tiering): {rate}% p.a.")
