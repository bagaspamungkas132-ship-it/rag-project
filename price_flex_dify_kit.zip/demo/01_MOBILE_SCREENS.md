# Mobile Demo Screens

## Screen 1 — Home
Show a normal banking home screen with a subtle section:
**Personalized for you**

## Screen 2 — Notification
`🔔 OCBC`

`A special rate is available for you`

`Deposito Online`
`5.35% p.a.`

`[ View Offer ]`

Label the prototype data somewhere unobtrusively as `Demo / Simulated Offer`.

## Screen 3 — Offer Detail
- Product: Deposito Online
- Placement: Rp500,000,000
- Tenor: 6 months
- Personalized rate: 5.35% p.a.
- Offer expiry: 23:59
- CTA: `Take This Offer`

## Screen 4 — Success
`Your offer is reserved`

`5.35% p.a.`
`Valid until 23:59`

The success state is enough for the hackathon; do not build a real banking transaction.
