"""
Agent 3 - AI Dynamic Rate
Fungsi: menentukan special rate per customer berdasarkan Customer Life Time
Value dan berbagai variable atribut per customer. Owner: Product Owner,
Segment/Proposition Owner.

Untuk hackathon: scoring pakai weighted formula sederhana (bukan model ML
terlatih) supaya cepat didemo, tapi strukturnya sudah siap diganti dengan
XGBoost/LightGBM kalau ada waktu lebih. Guardrail (batas kenaikan rate)
WAJIB ada supaya tidak jadi pricing bebas/diskriminatif.
"""

# Guardrail: kenaikan rate personal maksimum di atas base rate, dalam % poin.
# Angka ini yang secara konsep harus disetujui Treasury/ALCO.
GUARDRAIL_MAX_UPLIFT = 0.95  # contoh: base 3.80% -> max personal rate 4.75%

# Asumsi rentang normalisasi (production: ambil dari distribusi data aktual)
AUM_MAX = 500_000_000
VINTAGE_MAX_YEARS = 15


def _normalize(value: float, max_value: float) -> float:
    return max(0.0, min(1.0, value / max_value))


def score_customer(customer: dict) -> float:
    """
    Menghasilkan skor 0-100 sebagai proxy Customer Lifetime Value.
    Bobot: AUM 40%, vintage 25%, profitability 20%, engagement 15%.
    """
    aum_score = _normalize(customer["aum_idr"], AUM_MAX)
    vintage_score = _normalize(customer["vintage_years"], VINTAGE_MAX_YEARS)
    profitability_score = customer["profitability_score"] / 100
    engagement_score = customer["engagement_score"] / 100

    score = (
        0.40 * aum_score
        + 0.25 * vintage_score
        + 0.20 * profitability_score
        + 0.15 * engagement_score
    ) * 100
    return round(score, 1)


def get_personalized_rate(base_rate: float, score: float) -> float:
    """
    Memetakan skor (0-100) ke uplift rate, di-clamp ke GUARDRAIL_MAX_UPLIFT
    supaya tetap dalam batas yang disetujui Treasury.
    """
    uplift = (score / 100) * GUARDRAIL_MAX_UPLIFT
    uplift = round(min(uplift, GUARDRAIL_MAX_UPLIFT), 2)
    return round(base_rate + uplift, 2)


def is_eligible(customer: dict, min_score: float = 30.0) -> bool:
    """Filter sederhana: hanya nasabah dengan skor di atas ambang batas
    yang berhak menerima penawaran dynamic rate."""
    return score_customer(customer) >= min_score


if __name__ == "__main__":
    dummy_customer = {
        "aum_idr": 300_000_000,
        "vintage_years": 6,
        "profitability_score": 70,
        "engagement_score": 60,
    }
    s = score_customer(dummy_customer)
    print(f"Customer score: {s}")
    print(f"Personalized rate on base 3.80%: {get_personalized_rate(3.80, s)}%")
