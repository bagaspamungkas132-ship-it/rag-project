"""
train_model.py
Melatih model ML untuk Agent 3 (AI Dynamic Rate).

Model memprediksi rate_uplift_bps (basis poin tambahan di atas base_product_rate
dari Agent 2) berdasarkan atribut nasabah: usia, vintage, saldo (AUM/LUM),
product_holding, profitability_score, engagement_score, dll.

Jalankan sekali (atau setiap ada data baru): python src/train_model.py
Menyimpan model terlatih ke models/dynamic_rate_model.pkl
"""
import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
import joblib
import os

FEATURES = [
    "usia",
    "vintage_bulan",
    "saldo_rata_rata",
    "product_holding",
    "profitability_score",
    "engagement_score",
    "jumlah_transaksi_bulanan",
    "tenor_preference_bulan",
]
TARGET = "rate_uplift_bps"


def train():
    df = pd.read_csv(os.path.join(os.path.dirname(__file__), "..", "data", "customer_data.csv"))

    X = df[FEATURES]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = GradientBoostingRegressor(
        n_estimators=200,
        max_depth=3,
        learning_rate=0.05,
        random_state=42,
    )
    model.fit(X_train, y_train)

    pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, pred)
    r2 = r2_score(y_test, pred)
    print(f"Test MAE: {mae:.2f} bps")
    print(f"Test R^2: {r2:.3f}")

    importances = pd.Series(model.feature_importances_, index=FEATURES).sort_values(ascending=False)
    print("\nFeature importance:")
    print(importances)

    os.makedirs(os.path.join(os.path.dirname(__file__), "..", "models"), exist_ok=True)
    model_path = os.path.join(os.path.dirname(__file__), "..", "models", "dynamic_rate_model.pkl")
    joblib.dump({"model": model, "features": FEATURES}, model_path)
    print(f"\nModel saved to {model_path}")
    return model, mae, r2


if __name__ == "__main__":
    train()
