"""
Shared feature encoding for Agent 3 (AI Dynamic Rate).

Dipakai oleh DUA tempat:
  1. agent3_train_model.py  - saat training model XGBoost
  2. agent3_dynamic_rate.py - saat inference (skor customer real-time)

Sengaja dipisah jadi modul sendiri (bukan didefinisikan ulang di 2 tempat)
supaya urutan & definisi fitur antara training dan inference TIDAK PERNAH
berbeda - ini penyebab paling umum model ML "salah" di production (training-
serving skew). Modul ini murni Python stdlib, tidak butuh pandas/numpy/xgboost,
jadi aman diimpor di mana saja termasuk saat xgboost belum ter-install.

CATATAN PERUBAHAN: profitability_score & engagement_score sudah DIHAPUS dari
fitur (keputusan tim - data itu sintetis acak, tidak representatif). Segmen
sekarang berasal dari functionalsubgroup (skema data riil), bukan lagi
"segment" 3 kategori lama. Product holding sekarang ~28 flag biner (bukan 1
kolom kategori "product_holding" 4 nilai).

PRODUCT_FLAG_COLUMNS di bawah SENGAJA diduplikasi dari
data/customer_profile_gen.py (bukan diimpor lintas folder) supaya modul ini
tetap ringan diimpor dari mana saja tanpa path hacking - kalau salah satu
diubah, ubah juga yang satunya.
"""

PRODUCT_FLAG_COLUMNS = [
    "ph_27", "sa_idr", "ca_idr", "ca_fcy", "casa_fcy", "sa_taka", "td",
    "sa_tnd_rdn", "td_str", "sa_tnd_jnr", "creditcard", "personalloan",
    "kpr", "kmg", "revolver", "nonrevolver", "kur", "ibl", "iil",
    "tradebg", "tradelc", "tradeloan", "ori", "unittrust",
    "ba_unitlink", "ba_nonunitlink", "emas", "wpb",
]

RISK_PROFILE_ORDINAL = {
    "A - Rendah": 1, "B - Menengah": 2, "C - Menengah Tinggi": 3, "D - Tinggi": 4,
}
EDUCATION_ORDINAL = {
    "D - <SMA": 1, "C - SMA": 2, "B - S1/D3": 3, "A - S2/S3": 4,
}
AGE_MIN, AGE_MAX = 18, 65

FEATURE_NAMES = [
    "aum_idr_million",
    "lum_idr_million",
    "income_idr_million",
    "customerage",
    "risk_profile_score",
    "is_married",
    "education_score",
    "is_active",
    "is_female",
    "fsg_mass",
    "fsg_premier_banking",
    "fsg_business_banking",
    "ph_27bal_idr_million",
] + PRODUCT_FLAG_COLUMNS


def encode_features(customer: dict) -> list:
    """Convert a customer record (dict with the same keys as a row in
    customers.csv / historical_customers.csv) into a fixed-order numeric
    feature vector, matching FEATURE_NAMES exactly."""
    functionalsubgroup = customer["functionalsubgroup"]

    return [
        float(customer["aum_idr"]) / 1_000_000,
        float(customer["lum_idr"]) / 1_000_000,
        float(customer["income_idr"]) / 1_000_000,
        float(customer["customerage"]),
        float(RISK_PROFILE_ORDINAL.get(customer["customerriskprofile"], 1)),
        1.0 if str(customer["maritalstatus"]).startswith("A") else 0.0,
        float(EDUCATION_ORDINAL.get(customer["customereducation"], 1)),
        1.0 if customer["customeractivitystatus"] == "Active" else 0.0,
        1.0 if customer["customergender"] == "F" else 0.0,
        1.0 if functionalsubgroup == "MASS" else 0.0,
        1.0 if functionalsubgroup == "PREMIER BANKING" else 0.0,
        1.0 if functionalsubgroup == "BUSINESS BANKING" else 0.0,
        float(customer.get("ph_27bal_idr", 0)) / 1_000_000,
    ] + [float(customer.get(col, 0)) for col in PRODUCT_FLAG_COLUMNS]
