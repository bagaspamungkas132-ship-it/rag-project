"""
Bangun / update index vektor dari seluruh dokumen di config.yaml.
Jalankan sekali di awal, lalu ulangi tiap ada file baru (file lama yang
tidak berubah otomatis dilewati berdasarkan hash isi file).

Pakai --rebuild untuk membangun ulang index dari nol.
"""
import os
import sys
import hashlib
import yaml
from tqdm import tqdm

sys.path.append(os.path.dirname(__file__))
from pdf_parser import extract_pdf_text
from md_parser import extract_md_text
from text_splitter import split_text
from embedder import Embedder
from vector_store import VectorStore


def file_hash(filepath: str) -> str:
    h = hashlib.md5()
    with open(filepath, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def collect_files(folders_cfg: list) -> list:
    files = []
    for entry in folders_cfg:
        base = entry["path"]
        ftype = entry.get("type", "auto")
        if not os.path.isdir(base):
            print(f"[WARN] Folder tidak ditemukan, dilewati: {base}")
            continue
        for root, _, filenames in os.walk(base):
            for fn in filenames:
                ext = os.path.splitext(fn)[1].lower()
                if ftype == "pdf" and ext != ".pdf":
                    continue
                if ftype == "md" and ext != ".md":
                    continue
                if ext not in (".pdf", ".md"):
                    continue
                files.append(os.path.join(root, fn))
    return files


def main():
    with open("config.yaml", "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    rebuild = "--rebuild" in sys.argv

    store = VectorStore(
        dim=cfg["embedding"]["dim"],
        index_path=cfg["vector_store"]["index_path"],
        metadata_path=cfg["vector_store"]["metadata_path"],
    )

    already_indexed = {}
    if not rebuild and store.exists():
        store.load()
        already_indexed = store.get_indexed_files()
        print(f"Index lama ditemukan: {len(already_indexed)} file sudah terindeks.")
    else:
        print("Membangun index baru dari nol...")

    print("Memuat model embedding (unduhan pertama kali bisa agak lama)...")
    embedder = Embedder(cfg["embedding"]["model_name"], cfg["embedding"].get("device", "cpu"))

    all_files = collect_files(cfg["folders"])
    print(f"Total file ditemukan di semua folder: {len(all_files)}")

    new_files = []
    for fp in all_files:
        h = file_hash(fp)
        if fp in already_indexed and already_indexed[fp] == h:
            continue
        new_files.append((fp, h))

    print(f"File baru / berubah yang akan diproses: {len(new_files)}")

    for fp, h in tqdm(new_files, desc="Indexing"):
        ext = os.path.splitext(fp)[1].lower()
        try:
            text = extract_pdf_text(fp) if ext == ".pdf" else extract_md_text(fp)
        except Exception as e:
            print(f"[ERROR] Gagal parsing {fp}: {e}")
            continue

        if not text.strip():
            continue

        chunks = split_text(
            text,
            chunk_size=cfg["chunking"]["chunk_size"],
            overlap=cfg["chunking"]["chunk_overlap"],
        )
        if not chunks:
            continue

        embeddings = embedder.encode(chunks, batch_size=cfg["embedding"]["batch_size"])
        metadata_list = [
            {
                "filepath": fp,
                "filename": os.path.basename(fp),
                "folder": os.path.dirname(fp),
                "file_hash": h,
                "chunk_text": chunk,
            }
            for chunk in chunks
        ]
        store.add(embeddings, metadata_list)

    store.save()
    print(f"Selesai. Total chunk di index sekarang: {len(store.metadata)}")


if __name__ == "__main__":
    main()
