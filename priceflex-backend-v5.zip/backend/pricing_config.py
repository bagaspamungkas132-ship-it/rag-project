"""
PriceFlex - central pricing & eligibility configuration.

Single source of truth for every business rule/threshold that Product,
Treasury, Risk or Compliance might want to challenge or tune. Nothing in
agent3_dynamic_rate.py or agent4_conductor.py should hardcode a business
number directly - it should import it from here, so that:

  1. Tuning a rule (e.g. "raise the max age to 45") means editing ONE line
     in ONE file, not hunting through agent code.
  2. When a teammate pushes back on a guardrail/threshold in a review, this
     is the file you point them to and negotiate over - every number here
     is meant to be defensible on its own (who approves it, why this value).

Nothing in this file talks to xgboost, pandas, or any other dependency -
it is safe to import from anywhere, including before packages are installed.
"""

# ---------------------------------------------------------------------------
# Target audience: Emerging Affluent, Gen Z & Millennial only.
# PriceFlex is scoped to this segment on purpose (see project brief) - a
# 65-year-old Business Banking customer should NEVER be eligible, regardless
# of how high their CLV score is.
# ---------------------------------------------------------------------------

# Age range in years, checked against `customerage`.
# Default reasoning (as of 2026): Gen Z ~ born 2000-2012 (age 14-26),
# Millennial ~ born 1981-1996 (age 30-45). Floored at 18 (legal banking age)
# and capped at 43 to stay inside "Millennial", not drift into Gen X.
# Change these two numbers to widen/narrow the target age window.
ELIGIBLE_AGE_MIN = 18
ELIGIBLE_AGE_MAX = 43

# functionalsubgroup values considered part of the "Emerging Affluent"
# target segment. BUSINESS BANKING is intentionally excluded - it is a
# wholesale/SME segment, not an individual retail Gen Z/Millennial customer.
# Owner: Segment/Proposition Owner.
ELIGIBLE_FUNCTIONAL_SUBGROUPS = {"MASS", "PREMIER BANKING"}

# ---------------------------------------------------------------------------
# Agent 3 - CLV/propensity score threshold, derived from CAMPAIGN CAPACITY -
# NOT from AUC. AUC measures how well the model RANKS customers relative to
# each other; it says nothing about where to cut that ranking. The cutoff is
# a business decision: "how many target-audience customers can Treasury
# actually afford to give a special rate to this campaign?"
#
# CAMPAIGN_CAPACITY_PCT below is that business decision. The actual score
# number is computed by agent3_calibrate_threshold.py (scores every current
# target-audience customer in data/customers.csv, then finds the score at
# this percentile) and cached to model/agent3_eligibility_threshold.json.
# Re-run that script whenever: the model is retrained, this percentage
# changes, or the customer base changes meaningfully.
# ---------------------------------------------------------------------------
CAMPAIGN_CAPACITY_PCT = 0.20  # e.g. 0.20 = top 20% of target-audience customers by CLV score

# Fallback threshold used ONLY if agent3_calibrate_threshold.py has never
# been run yet (no cached threshold file present) - so the app still works
# out of the box before the first calibration run.
ELIGIBILITY_SCORE_MIN_DEFAULT = 30.0

# ---------------------------------------------------------------------------
# Guardrail: maximum personal-rate uplift, expressed as a RELATIVE PERCENTAGE
# of base_rate - not a fixed pp add-on. This is deliberate, not just a
# preference:
#
# 1. It's how real interest-rate caps are commonly structured. The clearest
#    public precedent is the FDIC's rate-cap rule for deposit-taking
#    institutions in the US: the cap is defined as a PERCENTAGE of a
#    reference rate (their "local rate cap" = 90% of the highest local
#    rate; their "national rate cap" formula also uses "120% of the
#    reference Treasury yield"), not a flat bps number - because a flat pp
#    add-on means something very different at a 2% base than at a 6% base.
#    Source: FDIC "National Rates and Rate Caps", fdic.gov/national-rates-and-rate-caps
#    (retrieved 2026-09-18).
# 2. It scales sensibly across OUR own tenor/tier grid, where base_rate
#    itself already ranges 4.25%-5.00% (see agent2_product_rate.py) - a
#    fixed +0.95pp meant something different at 4.25% (+22%) than at 5.00%
#    (+19%); a % cap keeps the RELATIVE generosity consistent everywhere.
#
# Sanity check against OCBC's own public "Payday Deposito" blanket promo
# (screenshot, valid 25 Aug-5 Sep 2026, IDR, no promo code needed) - this is
# the size of uplift the bank ALREADY publicly offers to everyone, useful as
# an upper reference point for what "reasonable" looks like:
#   vs T1 counter rate: 1m +23.5%, 3m +29.4%, 6m/12m +35.1%
#   vs T2/T3 counter rate: 1m +10.5%, 3m +15.8%, 6m/12m +21.6%
# PriceFlex's 1:1 personalization is a SUPPLEMENTARY kicker on top of
# whichever base/promo rate already applies - not meant to compete with or
# exceed a blanket campaign - so GUARDRAIL_MAX_UPLIFT_PCT below is set well
# below that observed range on purpose.
# ---------------------------------------------------------------------------
GUARDRAIL_MAX_UPLIFT_PCT = 0.03  # max +3% relative to base_rate (e.g. base 4.50% -> capped at 4.635%)

# Optional SECONDARY absolute cap in percentage points, applied on top of
# (i.e. whichever is smaller than) the relative cap above - a belt-and-
# braces limit so the relative % cap can never translate into a huge pp
# jump if base_rate itself is ever unusually high for some future
# tenor/tier. Set to a number (e.g. 1.00) to enable; None disables it.
GUARDRAIL_MAX_UPLIFT_PP = None

# Optional absolute floor/cap on the final personal rate, applied on top of
# the uplift guardrail above (belt-and-braces, independent of base_rate).
# Set to a number (e.g. 6.00) to enable; leave as None to disable.
PERSONAL_RATE_MIN = None
PERSONAL_RATE_MAX = None
