"""
generate_data.py
Membuat dataset sintetis nasabah untuk melatih model Agent 3 (AI Dynamic Rate).
Jalankan sekali: python data/generate_data.py
Menghasilkan data/customer_data.csv (300 baris).

Kolom mengikuti "Variable Factors" Agent 3 di diagram:
demografis (usia), vintage (lama jadi nasabah), AUM/LUM (saldo), product_holding,
profitability_score, plus atribut tambahan dari project awal (engagement_score,
tenor_preference, jumlah_transaksi_bulanan).

Target: rate_uplift_bps (basis point tambahan di atas base_product_rate dari
Agent 2) -- ini yang akan dipelajari model ML Agent 3. Dibuat dari kombinasi
fitur + noise, supaya polanya bisa "ditemukan" model tapi tidak trivial.
"""
import numpy as np
import pandas as pd

np.random.seed(42)
N = 300

usia = np.random.randint(21, 65, N)
vintage_bulan = np.random.randint(1, 180, N)  # lama jadi nasabah OCBC
saldo_rata_rata = np.round(np.random.lognormal(mean=15.5, sigma=1.1, size=N), -3)
saldo_rata_rata = np.clip(saldo_rata_rata, 300_000, 500_000_000)
product_holding = np.random.randint(1, 6, N)  # jumlah produk yang dimiliki
profitability_score = np.random.randint(1, 100, N)  # skor internal profitabilitas nasabah
engagement_score = np.random.randint(1, 100, N)
jumlah_transaksi_bulanan = np.random.randint(0, 30, N)
tenor_preference_bulan = np.random.choice([1, 3, 6, 12, 24, 36, 60, 120], N)
target_produk = np.random.choice(["TAKA Online", "Deposito Online"], N)

df = pd.DataFrame({
    "customer_id": [f"CUST-{i+1:04d}" for i in range(N)],
    "usia": usia,
    "vintage_bulan": vintage_bulan,
    "saldo_rata_rata": saldo_rata_rata.astype(int),
    "product_holding": product_holding,
    "profitability_score": profitability_score,
    "engagement_score": engagement_score,
    "jumlah_transaksi_bulanan": jumlah_transaksi_bulanan,
    "tenor_preference_bulan": tenor_preference_bulan,
    "target_produk": target_produk,
})

# --- Ground-truth sintetis untuk rate_uplift_bps (dipelajari model, BUKAN rule keras) ---
# Semakin tinggi AUM, profitability, engagement, vintage -> uplift makin besar.
# Ini mensimulasikan "customer lifetime value" yang disebut di diagram Agent 3.
z = (
    0.30 * (df["saldo_rata_rata"] / df["saldo_rata_rata"].max())
    + 0.25 * (df["profitability_score"] / 100)
    + 0.20 * (df["engagement_score"] / 100)
    + 0.15 * (df["vintage_bulan"] / df["vintage_bulan"].max())
    + 0.10 * (df["product_holding"] / df["product_holding"].max())
)
noise = np.random.normal(0, 0.05, N)
z = np.clip(z + noise, 0, 1)
df["rate_uplift_bps"] = np.round(z * 75, 1)  # maksimum uplift 75 bps di atas base rate

# --- Kolom tambahan untuk Agent 4 (bukan dipakai training model, cuma dipakai
# untuk menentukan waktu kirim notifikasi) ---
JAM_FAVORIT_OPTIONS = [
    "07:00-09:00", "08:00-10:00", "12:00-13:00", "12:00-14:00",
    "18:00-20:00", "19:00-21:00", "20:00-22:00", "21:00-23:00",
]
df["jam_transaksi_favorit"] = np.random.choice(JAM_FAVORIT_OPTIONS, N)

df.to_csv("data/customer_data.csv", index=False)
print(f"Saved {len(df)} rows to data/customer_data.csv")
print(df.head())