"""
PriceFlex - Streamlit Demo

Jalankan dari dalam folder backend/:
    streamlit run streamlit_app.py

Ini adalah versi demo "1 aplikasi jalan semua" - tidak perlu FastAPI
terpisah, cocok untuk presentasi ke juri langsung dari VSCode.
"""
import csv
import json
import os

import streamlit as st
import streamlit.components.v1 as components

from agent1_ftp import get_ftp
from agent4_conductor import generate_offer

CUSTOMERS_PATH = os.path.join(os.path.dirname(__file__), "data", "customers.csv")
MOCKUP_PATH = os.path.join(
    os.path.dirname(__file__), "..", "frontend", "mobile_banking_mockup_interactive.html"
)

st.set_page_config(page_title="PriceFlex Demo", page_icon="💳", layout="wide")


@st.cache_data
def load_customers():
    with open(CUSTOMERS_PATH, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def render_mockup_with_offer(offer: dict) -> str:
    """Baca file mockup HTML apa adanya, lalu suntik hasil offer (dari Agent
    1-2-3-4) langsung ke dalamnya - tanpa perlu backend FastAPI terpisah
    saat didemokan lewat Streamlit."""
    with open(MOCKUP_PATH, encoding="utf-8") as f:
        html = f.read()

    injected = json.dumps(
        {
            "personalized_rate": offer["personalized_rate"],
            "tenor_months": offer["tenor_months"],
            "message": offer["message"],
        }
    )
    # Suntikkan data hasil agent sebagai variable global di HTML
    html = html.replace(
        "<body>",
        f"<body>\n<script>window.__PRICEFLEX_OFFER__ = {injected};</script>",
        1,
    )
    # Ganti pemanggilan fetch ke backend dengan data yang sudah dihitung
    # Streamlit di server, supaya mockup tidak perlu network call sendiri.
    html = html.replace(
        "loadOfferFromBackend();",
        (
            "if (window.__PRICEFLEX_OFFER__) { "
            "currentOffer = window.__PRICEFLEX_OFFER__; "
            "updateOfferUI(currentOffer); "
            "} else { loadOfferFromBackend(); }"
        ),
    )
    return html


customers = load_customers()
customer_options = {
    f"{c['name']} · {c['segment']} (ID {c['customer_id']})": int(c["customer_id"])
    for c in customers
}

st.title("💳 PriceFlex")
st.caption(
    "One People Company Hackathon — Price Flex: dari \"one rate for everyone\" "
    "ke \"the right rate for the right customer at the right time\""
)

with st.sidebar:
    st.header("Simulasi Nasabah")
    selected_label = st.selectbox("Pilih nasabah", list(customer_options.keys()))
    customer_id = customer_options[selected_label]
    run = st.button("🚀 Generate Personalized Offer", use_container_width=True)
    st.divider()
    st.caption(
        "LLM copywriting memakai model internal OCBC (lihat `config.yaml`). "
        "Kalau belum di-setup atau tidak bisa diakses, sistem otomatis "
        "memakai kalimat template sebagai fallback - demo tetap jalan."
    )

if run:
    st.session_state["offer"] = generate_offer(customer_id)

offer = st.session_state.get("offer")

col_agents, col_phone = st.columns([1.1, 1])

with col_agents:
    if not offer:
        st.info("Pilih nasabah di sidebar lalu klik **Generate Personalized Offer**.")
    elif not offer.get("eligible", False):
        st.warning(offer.get("message", "Nasabah belum memenuhi ambang batas penawaran."))
    else:
        st.subheader("Jejak keputusan 4 agent")
        a1, a2 = st.columns(2)
        a1.metric("Agent 1 · FTP dasar", f"{get_ftp(offer['segment'], offer['product'], offer['tenor_months'])}%")
        a2.metric("Agent 2 · Base rate", f"{offer['base_rate']}%")
        a3, a4 = st.columns(2)
        a3.metric("Agent 3 · Skor CLV", f"{offer['customer_score']}")
        a4.metric("Agent 4 · Rate personal", f"{offer['personalized_rate']}%", delta=f"+{round(offer['personalized_rate'] - offer['base_rate'], 2)}%")

        st.subheader("Pesan yang dikirim (generative, Agent 4)")
        st.success(offer["message"])

        with st.expander("Lihat raw JSON output"):
            st.json(offer)

        st.subheader("Arsitektur")
        st.markdown(
            """
            1. **AI Alco/FTP** — FTP dasar per segmen & produk (Treasury)
            2. **AI Product Rate** — FTP + margin = base rate
            3. **AI Dynamic Rate** — skor CLV nasabah → rate personal (dibatasi guardrail)
            4. **AI Conductor** — orkestrasi + copy pesan (LLM) + tampil di channel nasabah
            """
        )

with col_phone:
    st.subheader("Preview di aplikasi nasabah")
    if offer and offer.get("eligible", False):
        components.html(render_mockup_with_offer(offer), height=820, scrolling=True)
    else:
        with open(MOCKUP_PATH, encoding="utf-8") as f:
            components.html(f.read(), height=820, scrolling=True)
