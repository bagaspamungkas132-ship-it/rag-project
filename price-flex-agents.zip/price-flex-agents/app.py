"""
app.py
Dashboard Streamlit untuk demo visual pipeline Price Flex (Agent 1-4) ke
juri hackathon. Tidak butuh API key LLM -- memakai run_pipeline() dari
run_demo.py (kalkulasi + model ML asli, pesan notifikasi pakai template).

Kalau mau versi pesan notifikasi ditulis oleh LLM (CrewAI penuh), lihat
catatan di bagian bawah file ini.

Jalankan: streamlit run app.py
"""
import streamlit as st
import pandas as pd

from src.pricing_engine import FTPInput, calc_ftp, calc_base_product_rate
from src.dynamic_rate_model import DynamicRateAgent, GUARDRAIL
from src.conductor_rules import CampaignWindow, should_send_offer, next_send_time_label

st.set_page_config(page_title="Price Flex — AI Pricing Pipeline", layout="wide")

st.title("Price Flex — Demo Pipeline 4 Agent")
st.caption("AI Alco/FTP -> AI Product Rate -> AI Dynamic Rate -> AI Conductor")

# --- Sidebar: Market context (Agent 1 input) ---
st.sidebar.header("1. Market Context (input Agent 1 - AI Alco/FTP)")
base_cost_of_fund = st.sidebar.slider("Base cost of fund", 0.02, 0.08, 0.0550, 0.0005, format="%.4f")
stock_of_money_ratio = st.sidebar.slider("Stock of money ratio", 0.5, 1.5, 0.95, 0.01)
demand_supply_index = st.sidebar.slider("Demand/supply index (-1 s/d 1)", -1.0, 1.0, 0.4, 0.05)
competitor_benchmark = st.sidebar.slider("Competitor benchmark rate", 0.02, 0.08, 0.0525, 0.0005, format="%.4f")
market_trend_bps = st.sidebar.slider("Market trend (bps)", -20, 20, 3)

st.sidebar.header("2. Campaign (input Agent 4 - AI Conductor)")
tanggal_cek = st.sidebar.date_input("Tanggal cek", value=pd.Timestamp("2026-09-09")).strftime("%Y-%m-%d")
tanggal_mulai = st.sidebar.date_input("Campaign mulai", value=pd.Timestamp("2026-09-01")).strftime("%Y-%m-%d")
tanggal_selesai = st.sidebar.date_input("Campaign selesai", value=pd.Timestamp("2026-09-30")).strftime("%Y-%m-%d")

st.header("3. Profil Nasabah (input Agent 3 - AI Dynamic Rate)")
col1, col2, col3 = st.columns(3)
with col1:
    customer_id = st.text_input("Customer ID", "CUST-DEMO-01")
    usia = st.number_input("Usia", 18, 80, 32)
    vintage_bulan = st.number_input("Vintage (bulan jadi nasabah)", 0, 300, 48)
with col2:
    saldo_rata_rata = st.number_input("Saldo rata-rata (IDR)", 0, 1_000_000_000, 55_000_000, step=100_000)
    product_holding = st.number_input("Jumlah produk dimiliki", 1, 10, 3)
    profitability_score = st.slider("Profitability score", 1, 100, 82)
with col3:
    engagement_score = st.slider("Engagement score", 1, 100, 90)
    jumlah_transaksi_bulanan = st.number_input("Transaksi/bulan", 0, 60, 18)
    tenor_preference_bulan = st.selectbox("Tenor preference (bulan)", [1, 3, 6, 12, 24, 36, 60, 120], index=3)
    jam_transaksi_favorit = st.text_input("Jam transaksi favorit", "19:00-21:00")

target_produk = st.selectbox("Target produk", ["TAKA Online", "Deposito Online"])

if st.button("Jalankan Pipeline Price Flex", type="primary"):
    customer = {
        "customer_id": customer_id,
        "usia": usia,
        "vintage_bulan": vintage_bulan,
        "saldo_rata_rata": saldo_rata_rata,
        "product_holding": product_holding,
        "profitability_score": profitability_score,
        "engagement_score": engagement_score,
        "jumlah_transaksi_bulanan": jumlah_transaksi_bulanan,
        "tenor_preference_bulan": tenor_preference_bulan,
        "jam_transaksi_favorit": jam_transaksi_favorit,
    }

    st.divider()
    c1, c2, c3, c4 = st.columns(4)

    # Agent 1
    ftp_input = FTPInput(
        base_cost_of_fund=base_cost_of_fund,
        stock_of_money_ratio=stock_of_money_ratio,
        demand_supply_index=demand_supply_index,
        competitor_benchmark=competitor_benchmark,
        market_trend_bps=market_trend_bps,
    )
    ftp = calc_ftp(ftp_input, tenor_bulan=tenor_preference_bulan)
    with c1:
        st.metric("Agent 1 — FTP", f"{ftp:.4%}")
        st.caption("AI Alco/FTP")

    # Agent 2
    base_rate = calc_base_product_rate(ftp, target_produk)
    with c2:
        st.metric("Agent 2 — Base Rate", f"{base_rate:.4%}")
        st.caption(f"AI Product Rate ({target_produk})")

    # Agent 3
    agent3 = DynamicRateAgent()
    rec = agent3.recommend(customer, target_produk, base_rate)
    with c3:
        if rec["eligible"]:
            st.metric("Agent 3 — Final Rate", f"{rec['final_rate']:.4%}", delta=f"+{rec['uplift_bps_applied']} bps")
        else:
            st.metric("Agent 3 — Final Rate", "Tidak Eligible")
        st.caption("AI Dynamic Rate")

    # Agent 4
    campaign = CampaignWindow(
        nama_campaign="Price Flex Launch",
        tanggal_mulai=tanggal_mulai,
        tanggal_selesai=tanggal_selesai,
        produk=target_produk,
    )
    decision = should_send_offer(campaign, tanggal_cek, target_produk, rec["eligible"])
    decision["waktu_kirim_disarankan"] = next_send_time_label(jam_transaksi_favorit)
    with c4:
        st.metric("Agent 4 — Kirim?", "Ya" if decision["should_send"] else "Tidak")
        st.caption(f"Jam: {decision['waktu_kirim_disarankan']}")

    st.divider()

    if rec["eligible"]:
        rule = GUARDRAIL[target_produk]
        st.info(
            f"**Guardrail {target_produk}:** {rule['rate_min']:.2%} – {rule['rate_max']:.2%} "
            f"| Model memprediksi uplift mentah **{rec['uplift_bps_raw']} bps**, "
            f"diterapkan **{rec['uplift_bps_applied']} bps** setelah guardrail"
            + (" (guardrail AKTIF membatasi hasil model)." if rec.get("guardrail_hit") else ".")
        )

    if decision["should_send"] and rec["eligible"]:
        pesan = (
            f"Halo! Ada promo bunga hingga {rec['final_rate']:.2%} untuk "
            f"{target_produk} kamu bulan ini. Yuk cek di OCBC mobile sebelum "
            f"promo berakhir."
        )
        st.success(f"**Draf Notifikasi ke Nasabah:**\n\n{pesan}")
    else:
        st.warning(f"Tidak ada notifikasi dikirim. Alasan: {rec['reason']}")

    with st.expander("Lihat detail JSON tiap agent (untuk debug/Q&A juri)"):
        st.json({
            "agent1_ftp": ftp,
            "agent2_base_rate": base_rate,
            "agent3_dynamic_rate": rec,
            "agent4_conductor": decision,
        })

st.divider()
st.caption(
    "Catatan: pesan notifikasi di atas pakai template teks (tanpa LLM) supaya "
    "dashboard ini jalan tanpa API key. Versi dengan LLM menulis pesan secara "
    "natural ada di src/crew.py (jalankan `python3 -m src.crew`, butuh "
    "ANTHROPIC_API_KEY atau provider lain)."
)
