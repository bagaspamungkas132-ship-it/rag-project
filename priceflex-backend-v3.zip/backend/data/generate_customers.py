"""
Generate synthetic customer data ("nasabah hari ini") untuk demo PriceFlex.
No external libraries needed (pure Python stdlib) so it runs anywhere for free.

Skema kolom mengikuti taksonomi data nasabah riil (functionalgroup/
functionalsubgroup, ~28 product holding flag ph_xx/sa_xx/dst), BUKAN skema
demo lama (profitability_score/engagement_score sudah di-exclude sesuai
keputusan tim - lihat agent3_features.py).

Run:
    python generate_customers.py
Produces:
    customers.csv
"""
import csv
import os
import random

from customer_profile_gen import generate_profile, pricing_segment_for

OUTPUT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "customers.csv")

random.seed(42)  # reproducible results across the team

FIRST_NAMES = [
    "Budi", "Siti", "Andi", "Rina", "Dewi", "Agus", "Putri", "Rudi",
    "Sri", "Hendra", "Wati", "Joko", "Lina", "Yudi", "Maya", "Fajar",
]
LAST_NAMES = [
    "Santoso", "Wijaya", "Kusuma", "Pratama", "Saputra", "Lestari",
    "Nugroho", "Setiawan", "Hidayat", "Rahayu",
]

NUM_CUSTOMERS = 300


def generate_usual_txn_hours(seed_index: int) -> tuple[int, int]:
    """
    Simulates: "based on the last ~90 days of transaction timestamps in
    core banking / mobile app logs, what is this customer's peak activity
    window?" For the demo we synthesize this instead of mining real
    timestamps, but it's computed with a RNG seeded by the customer's row
    index (not the shared global `random` stream), so it's reproducible on
    its own and doesn't shift if the rest of this file changes.

    In production this column would instead be the output of a small
    stats job over real transaction logs (e.g. hour-of-day mode, or the
    interquartile range of transaction timestamps per customer).
    """
    rng = random.Random(seed_index * 7919 + 13)
    start_hour = rng.choice(list(range(6, 22)))
    width_hours = rng.choice([1, 1, 1, 2])  # mostly 1-hour windows, sometimes 2
    end_hour = min(start_hour + width_hours, 22)
    return start_hour, end_hour


def generate_row(seed_index: int) -> dict:
    customerid = f"CUST-{seed_index:03d}"
    name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
    profile = generate_profile(random)
    pricing_segment = pricing_segment_for(profile["functionalgroup"], profile["functionalsubgroup"])
    usual_txn_hour_start, usual_txn_hour_end = generate_usual_txn_hours(seed_index)

    row = {
        "customerid": customerid,
        "name": name,  # kolom demo-only (real schema tidak simpan nama di sini,
                        # tapi dibutuhkan buat teks pesan/narasi di UI)
        "pricing_segment": pricing_segment,  # dipakai Agent 1 (FTP) & Agent 2 (margin)
        **profile,
        "usual_txn_hour_start": usual_txn_hour_start,
        "usual_txn_hour_end": usual_txn_hour_end,
    }
    return row


def main():
    rows = [generate_row(i) for i in range(1, NUM_CUSTOMERS + 1)]
    fieldnames = list(rows[0].keys())
    with open(OUTPUT_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Generated {len(rows)} synthetic customers -> {OUTPUT_PATH}")
    print(f"Kolom: {fieldnames}")


if __name__ == "__main__":
    main()
