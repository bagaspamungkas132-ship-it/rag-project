import os
import pickle
import faiss
import numpy as np


class VectorStore:
    def __init__(self, dim: int, index_path: str, metadata_path: str):
        self.dim = dim
        self.index_path = index_path
        self.metadata_path = metadata_path
        self.index = faiss.IndexFlatIP(dim)   # inner product == cosine karena embedding dinormalisasi
        self.metadata = []

    def add(self, embeddings: np.ndarray, metadata_list: list):
        self.index.add(embeddings)
        self.metadata.extend(metadata_list)

    def search(self, query_embedding: np.ndarray, top_k: int = 8) -> list:
        scores, indices = self.index.search(query_embedding.reshape(1, -1), top_k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            results.append({"score": float(score), **self.metadata[idx]})
        return results

    def save(self):
        os.makedirs(os.path.dirname(self.index_path), exist_ok=True)
        faiss.write_index(self.index, self.index_path)
        with open(self.metadata_path, "wb") as f:
            pickle.dump(self.metadata, f)

    def load(self):
        self.index = faiss.read_index(self.index_path)
        with open(self.metadata_path, "rb") as f:
            self.metadata = pickle.load(f)

    def exists(self) -> bool:
        return os.path.exists(self.index_path) and os.path.exists(self.metadata_path)

    def get_indexed_files(self) -> dict:
        """Mapping filepath -> file_hash dari chunk yang sudah ada di index."""
        return {m["filepath"]: m["file_hash"] for m in self.metadata}
