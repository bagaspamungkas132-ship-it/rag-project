"""
run_demo.py
Uji cepat pipeline Agent 1 -> 2 -> 3 -> (bagian rule Agent 4) TANPA perlu API
key LLM sama sekali -- langsung panggil fungsi Python-nya. Cocok untuk
memastikan logika inti sudah benar sebelum coba versi CrewAI penuh (yang
butuh API key & biaya token untuk bagian penulisan pesan natural).

Untuk versi lengkap dengan agent CrewAI + LLM menulis pesan notifikasi,
pakai: python3 -m src.crew (butuh ANTHROPIC_API_KEY atau ganti provider lain
di src/crew.py)

Jalankan: python3 run_demo.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.pricing_engine import FTPInput, calc_ftp, calc_base_product_rate
from src.dynamic_rate_model import DynamicRateAgent
from src.conductor_rules import CampaignWindow, should_send_offer, next_send_time_label


def run_pipeline(customer: dict, target_produk: str, market_context: dict, campaign: CampaignWindow, tanggal_cek: str):
    # Agent 1
    ftp_input = FTPInput(**market_context, )
    ftp = calc_ftp(ftp_input, tenor_bulan=customer["tenor_preference_bulan"])
    print(f"[Agent 1 - AI Alco/FTP] FTP tenor {customer['tenor_preference_bulan']} bulan: {ftp:.4%}")

    # Agent 2
    base_rate = calc_base_product_rate(ftp, target_produk)
    print(f"[Agent 2 - AI Product Rate] Base rate {target_produk}: {base_rate:.4%}")

    # Agent 3
    agent3 = DynamicRateAgent()
    rec = agent3.recommend(customer, target_produk, base_rate)
    print(f"[Agent 3 - AI Dynamic Rate] {rec}")

    # Agent 4 (bagian rule saja)
    decision = should_send_offer(campaign, tanggal_cek, target_produk, rec["eligible"])
    decision["waktu_kirim_disarankan"] = next_send_time_label(customer["jam_transaksi_favorit"])
    print(f"[Agent 4 - AI Conductor] {decision}")

    if decision["should_send"]:
        pesan = (
            f"Halo! Ada promo bunga hingga {rec['final_rate']:.2%} untuk "
            f"{target_produk} kamu bulan ini. Yuk cek di OCBC mobile sebelum "
            f"promo berakhir."
        )
        print(f"\n>>> Draf notifikasi (template, tanpa LLM): {pesan}")
    else:
        print("\n>>> Tidak ada notifikasi dikirim (tidak eligible atau di luar periode campaign).")

    return {"ftp": ftp, "base_rate": base_rate, "agent3": rec, "agent4": decision}


if __name__ == "__main__":
    import sys
    from src.customer_loader import load_customer, list_customer_ids

    market_context = {
        "base_cost_of_fund": 0.0550,
        "stock_of_money_ratio": 0.95,
        "demand_supply_index": 0.4,
        "competitor_benchmark": 0.0525,
        "market_trend_bps": 3,
    }
    campaign = CampaignWindow(
        nama_campaign="Price Flex Launch",
        tanggal_mulai="2026-09-01",
        tanggal_selesai="2026-09-30",
        produk="ALL",  # berlaku untuk TAKA Online maupun Deposito Online
    )

    # Pilih customer_id lewat argumen: python3 run_demo.py CUST-0005
    # Tanpa argumen -> pakai CUST-0001 (baris pertama data/customer_data.csv)
    customer_id_arg = sys.argv[1] if len(sys.argv) > 1 else None
    customer = load_customer(customer_id_arg)
    target_produk = customer.pop("target_produk")  # dipakai sebagai parameter run_pipeline, bukan field customer

    print(f"Customer terpilih: {customer['customer_id']}  (target produk: {target_produk})")
    print(f"10 customer_id lain yang bisa dicoba: {', '.join(list_customer_ids())}")
    print(f"Cara pakai: python3 run_demo.py <customer_id>\n")

    print("=" * 70)
    print(f"PIPELINE UNTUK: {customer['customer_id']}")
    print("=" * 70)
    run_pipeline(customer, target_produk, market_context, campaign, "2026-09-09")
