"""
Generate synthetic customer data for the PriceFlex hackathon demo.
No external libraries needed (pure Python stdlib) so it runs anywhere for free.

Run:
    python generate_customers.py
Produces:
    customers.csv
"""
import csv
import random

random.seed(42)  # reproducible results across the team

FIRST_NAMES = [
    "Budi", "Siti", "Andi", "Rina", "Dewi", "Agus", "Putri", "Rudi",
    "Sri", "Hendra", "Wati", "Joko", "Lina", "Yudi", "Maya", "Fajar",
]
LAST_NAMES = [
    "Santoso", "Wijaya", "Kusuma", "Pratama", "Saputra", "Lestari",
    "Nugroho", "Setiawan", "Hidayat", "Rahayu",
]
SEGMENTS = ["Personal Banking", "Emerging Affluent", "Business Banking"]
PRODUCT_HOLDINGS = ["Savings only", "Savings + Card", "Savings + Investment", "Full suite"]

NUM_CUSTOMERS = 300


def generate_row(customer_id: int) -> dict:
    name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
    aum = round(random.uniform(2_000_000, 500_000_000), -3)  # IDR
    vintage_years = round(random.uniform(0.1, 15), 1)
    profitability_score = round(random.uniform(0, 100), 1)
    engagement_score = round(random.uniform(0, 100), 1)
    return {
        "customer_id": customer_id,
        "name": name,
        "segment": random.choice(SEGMENTS),
        "aum_idr": int(aum),
        "vintage_years": vintage_years,
        "product_holding": random.choice(PRODUCT_HOLDINGS),
        "profitability_score": profitability_score,
        "engagement_score": engagement_score,
    }


def main():
    rows = [generate_row(i) for i in range(1, NUM_CUSTOMERS + 1)]
    fieldnames = list(rows[0].keys())
    with open("customers.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Generated {len(rows)} synthetic customers -> customers.csv")


if __name__ == "__main__":
    main()
