"""
Agent 3 - AI Dynamic Rate
Fungsi: menentukan special rate per customer berdasarkan Customer Life Time
Value dan berbagai variable atribut per customer. Owner: Product Owner,
Segment/Proposition Owner.

Skoring HANYA lewat XGBoost - keputusan tim (bukan lagi 2 jalur/ada
fallback rule-based). Kalau package `xgboost` belum ter-install atau model
belum dilatih, fungsi skor akan raise RuntimeError yang jelas alasannya -
TIDAK diam-diam pindah ke metode lain, supaya angka yang ditampilkan ke
nasabah/juri selalu berasal dari satu sumber yang sama & bisa diaudit.

Semua threshold bisnis (rentang usia target, segmen target, ambang skor
eligibility, guardrail uplift) ada di pricing_config.py - satu tempat untuk
diubah-ubah / dinegosiasikan dengan Treasury/Risk/Product, bukan hardcode
di sini.
"""
import json
import os

from agent3_features import FEATURE_NAMES, encode_features
from pricing_config import (
    ELIGIBILITY_SCORE_MIN_DEFAULT,
    ELIGIBLE_AGE_MAX,
    ELIGIBLE_AGE_MIN,
    ELIGIBLE_FUNCTIONAL_SUBGROUPS,
    GUARDRAIL_MAX_UPLIFT_PCT,
    GUARDRAIL_MAX_UPLIFT_PP,
    PERSONAL_RATE_MAX,
    PERSONAL_RATE_MIN,
)

MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")
MODEL_PATH = os.path.join(MODEL_DIR, "agent3_clv_model.json")
METADATA_PATH = os.path.join(MODEL_DIR, "agent3_model_metadata.json")
THRESHOLD_PATH = os.path.join(MODEL_DIR, "agent3_eligibility_threshold.json")

_model = None
_model_load_error = None
try:
    import xgboost as xgb

    if os.path.exists(MODEL_PATH):
        try:
            _model = xgb.Booster()
            _model.load_model(MODEL_PATH)
        except Exception as e:  # model file corrupt/incompatible
            _model_load_error = f"Failed to load model file: {e}"
    else:
        _model_load_error = (
            f"Model not trained yet (file {MODEL_PATH} does not exist). "
            f"Run: python data/generate_training_data.py && python agent3_train_model.py"
        )
except ImportError as e:
    _model_load_error = (
        f"Package 'xgboost' is not installed ({e}). "
        f"Run: pip install -r requirements-optional-ml.txt"
    )


def _load_metadata() -> dict:
    if os.path.exists(METADATA_PATH):
        try:
            with open(METADATA_PATH, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


_METADATA = _load_metadata()


def _load_eligibility_threshold() -> dict:
    """Read the capacity-calibrated score cutoff cached by
    agent3_calibrate_threshold.py. Falls back to
    ELIGIBILITY_SCORE_MIN_DEFAULT (see pricing_config.py) if calibration has
    never been run - so the app still works before the first calibration."""
    if os.path.exists(THRESHOLD_PATH):
        try:
            with open(THRESHOLD_PATH, encoding="utf-8") as f:
                data = json.load(f)
            return {
                "score_min": float(data["score_min"]),
                "source": "calibrated",
                "capacity_pct": data.get("capacity_pct"),
                "n_target_audience": data.get("n_target_audience"),
                "n_eligible": data.get("n_eligible"),
                "computed_at": data.get("computed_at"),
            }
        except Exception:
            pass
    return {
        "score_min": ELIGIBILITY_SCORE_MIN_DEFAULT,
        "source": "default (not yet calibrated - run agent3_calibrate_threshold.py)",
        "capacity_pct": None,
        "n_target_audience": None,
        "n_eligible": None,
        "computed_at": None,
    }


_ELIGIBILITY = _load_eligibility_threshold()
ELIGIBILITY_SCORE_MIN = _ELIGIBILITY["score_min"]


def get_scoring_method() -> dict:
    """Transparency info for the UI: is the XGBoost model actually loaded
    and ready, plus its metadata (AUC, feature importance) and the current
    eligibility threshold (and how it was derived) for display."""
    return {
        "method": "xgboost" if _model is not None else "unavailable",
        "error": None if _model is not None else _model_load_error,
        "metadata": _METADATA,
        "eligibility": _ELIGIBILITY,
    }


def score_customer(customer: dict) -> float:
    """Score = XGBoost's predicted probability that this customer responds
    positively to the offer (learned from historical conversions), x 100.
    Raises RuntimeError if the model isn't loaded - by design there is no
    alternate scoring method to silently fall back to."""
    if _model is None:
        raise RuntimeError(
            f"Agent 3 scoring is unavailable: {_model_load_error}"
        )
    features = encode_features(customer)
    dmatrix = xgb.DMatrix([features], feature_names=FEATURE_NAMES)
    prob = float(_model.predict(dmatrix)[0])
    return round(prob * 100, 1)


def get_personalized_rate(base_rate: float, score: float) -> float:
    """
    Uplift is capped as a PERCENTAGE of base_rate (GUARDRAIL_MAX_UPLIFT_PCT
    in pricing_config.py) - not a fixed pp add-on. Score (0-100) prorates
    linearly within that capped band: score 100 -> full allowed uplift,
    score 0 -> none. See pricing_config.py for the reasoning (mirrors how
    real deposit-rate caps, e.g. FDIC's, are structured as a % of a
    reference rate) and for the optional secondary absolute pp cap.
    """
    max_uplift_pp = base_rate * GUARDRAIL_MAX_UPLIFT_PCT
    if GUARDRAIL_MAX_UPLIFT_PP is not None:
        max_uplift_pp = min(max_uplift_pp, GUARDRAIL_MAX_UPLIFT_PP)
    uplift = round((score / 100) * max_uplift_pp, 2)
    rate = round(base_rate + uplift, 2)
    if PERSONAL_RATE_MIN is not None:
        rate = max(rate, PERSONAL_RATE_MIN)
    if PERSONAL_RATE_MAX is not None:
        rate = min(rate, PERSONAL_RATE_MAX)
    return rate


def is_target_audience(customer: dict) -> bool:
    """PriceFlex is scoped to Emerging Affluent Gen Z & Millennial only
    (see pricing_config.py) - independent of CLV score. A customer outside
    this age/segment window is never eligible, no matter how high their
    score would be."""
    age = float(customer.get("customerage", 0))
    subgroup = customer.get("functionalsubgroup")
    return (
        ELIGIBLE_AGE_MIN <= age <= ELIGIBLE_AGE_MAX
        and subgroup in ELIGIBLE_FUNCTIONAL_SUBGROUPS
    )


def is_eligible(customer: dict) -> bool:
    """A customer is eligible only if BOTH: (1) they're in the target
    audience (age + segment), AND (2) their CLV score clears
    ELIGIBILITY_SCORE_MIN - a campaign-capacity-derived cutoff (see
    agent3_calibrate_threshold.py), not an arbitrary number. Order matters
    for cost: audience check is free, score requires a model call - so we
    check audience first."""
    if not is_target_audience(customer):
        return False
    return score_customer(customer) >= ELIGIBILITY_SCORE_MIN


if __name__ == "__main__":
    dummy_customer = {
        "aum_idr": 300_000_000,
        "lum_idr": 0,
        "income_idr": 25_000_000,
        "customerage": 29,
        "customerriskprofile": "C - Menengah Tinggi",
        "maritalstatus": "B - Belum Menikah",
        "customereducation": "B - S1/D3",
        "customeractivitystatus": "Active",
        "customergender": "F",
        "functionalgroup": "CONSUMER BANKING",
        "functionalsubgroup": "PREMIER BANKING",
        "ph_27bal_idr": 0,
        "ph_27": 1,
        "sa_idr": 1,
        "creditcard": 1,
        "td": 1,
        "unittrust": 1,
    }
    sm = get_scoring_method()
    print(f"Metode skor aktif: {sm['method']}")
    if sm["method"] == "xgboost":
        s = score_customer(dummy_customer)
        print(f"Customer score: {s}")
        print(f"Target audience? {is_target_audience(dummy_customer)}")
        print(f"Eligible? {is_eligible(dummy_customer)}")
        print(f"Personalized rate on base 3.80%: {get_personalized_rate(3.80, s)}%")
    else:
        print(f"Skor tidak tersedia: {sm['error']}")
