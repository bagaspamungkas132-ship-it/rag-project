"""
Agent 4 - AI Conductor
Fungsi: menampilkan offer ke customer baik berbasis aplikasi/web sesuai
jadwal program/campaign. Owner: Platform Owner, Segment/Proposition Owner.

Untuk hackathon: orkestrasi cukup pakai pemanggilan fungsi berurutan
(Agent 1 -> 2 -> 3), tidak perlu framework agent berat seperti
LangGraph/CrewAI kecuali ingin nilai tambah "agentic architecture".

Bagian "sesuai jadwal" di atas kita implementasikan sebagai notification
timing: notifikasi tidak dikirim di jam acak/global (mis. jam 9 pagi untuk
semua nasabah), tapi di jam nasabah itu sendiri biasanya aktif bertransaksi
(usual_txn_hour_start/end) - lihat pick_notification_time() di bawah.
"""
import csv
import os
import random
import time

from agent2_product_rate import get_base_rate
from agent3_dynamic_rate import score_customer, get_personalized_rate, is_eligible, get_scoring_method
from llm_client import generate_offer_message, generate_decision_narrative

CUSTOMERS_PATH = os.path.join(os.path.dirname(__file__), "data", "customers.csv")

# Campaign config - dalam production ini datang dari campaign management tool
CAMPAIGN_PRODUCT = "Deposito Online"
CAMPAIGN_TENOR_MONTHS = 12
OFFER_VALID_SECONDS = 60 * 60  # 1 jam, selaras dengan mockup

# Fallback window kalau data usual_txn_hour_* nasabah tidak ada/tidak valid.
DEFAULT_TXN_HOUR_START = 9
DEFAULT_TXN_HOUR_END = 10


def _load_customer(customer_id: str) -> dict | None:
    with open(CUSTOMERS_PATH, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row["customerid"] == customer_id:
                row["aum_idr"] = int(row["aum_idr"])
                row["lum_idr"] = int(row["lum_idr"])
                row["income_idr"] = int(row["income_idr"])
                row["customerage"] = int(row["customerage"])
                row["usual_txn_hour_start"] = int(
                    row.get("usual_txn_hour_start") or DEFAULT_TXN_HOUR_START
                )
                row["usual_txn_hour_end"] = int(
                    row.get("usual_txn_hour_end") or DEFAULT_TXN_HOUR_END
                )
                if row["usual_txn_hour_end"] <= row["usual_txn_hour_start"]:
                    row["usual_txn_hour_end"] = row["usual_txn_hour_start"] + 1
                return row
    return None


def pick_notification_time(hour_start: int, hour_end: int, rng: random.Random | None = None) -> tuple[int, int]:
    """
    Teknis perhitungan (ditunjukkan apa adanya ke juri, tidak ada "magic"):

    1. Agent 3 sudah menganalisis histori transaksi nasabah (di demo ini
       disintesis, di production dari log core banking/mobile) dan
       menyimpulkan rentang jam nasabah paling sering aktif, mis. 09:00-10:00.
    2. Rentang jam itu dikonversi ke menit sejak tengah malam:
       window = [hour_start * 60, hour_end * 60]
    3. Satu titik waktu diambil SECARA ACAK (uniform random) di dalam
       window itu -> supaya jadwal terasa natural/tidak robotic (tidak
       selalu persis jam bulat yang sama tiap hari), tapi tetap terjamin
       berada di jam nasabah biasanya membuka aplikasi (bukan jam 3 pagi).
    4. Hasilnya dibulatkan ke menit terdekat lalu dikonversi balik ke
       format jam:menit untuk ditampilkan di lock screen mockup.

    LLM TIDAK dipakai di sini - ini murni perhitungan numerik yang harus
    auditable/reproducible, konsisten dengan prinsip di README: LLM hanya
    untuk teks generatif, tidak pernah untuk angka/keputusan numerik.
    """
    rng = rng or random
    window_start_min = hour_start * 60
    window_end_min = hour_end * 60
    chosen_min = rng.uniform(window_start_min, window_end_min)
    chosen_min = round(chosen_min)
    hour, minute = divmod(chosen_min, 60)
    return hour, minute


def generate_offer(customer_id: str) -> dict:
    """Menjalankan Agent 1 -> 2 -> 3 secara berurutan dan menyusun offer
    yang siap dikirim ke Agent Conductor (channel/UI)."""
    customer = _load_customer(customer_id)
    if customer is None:
        return {"error": f"Customer {customer_id} not found"}

    if not is_eligible(customer):
        return {
            "eligible": False,
            "message": "Nasabah belum memenuhi ambang batas untuk penawaran khusus.",
        }

    # pricing_segment = hasil pemetaan functionalgroup/functionalsubgroup (skema
    # data riil) ke 3 kategori lama yang dipakai Agent 1 (FTP) & Agent 2 (margin)
    # - lihat data/customer_profile_gen.py:pricing_segment_for().
    pricing_segment = customer["pricing_segment"]
    base_rate = get_base_rate(
        segment=pricing_segment,
        product=CAMPAIGN_PRODUCT,
        tenor_months=CAMPAIGN_TENOR_MONTHS,
    )
    score = score_customer(customer)
    personal_rate = get_personalized_rate(base_rate, score)

    hour_start = customer["usual_txn_hour_start"]
    hour_end = customer["usual_txn_hour_end"]
    notif_hour, notif_minute = pick_notification_time(hour_start, hour_end)

    segment_label = f"{customer['functionalgroup']} - {customer['functionalsubgroup']}"

    message = generate_offer_message(
        customer_name=customer["name"],
        rate=personal_rate,
        tenor_months=CAMPAIGN_TENOR_MONTHS,
        product=CAMPAIGN_PRODUCT,
    )
    narrative = generate_decision_narrative(
        customer_name=customer["name"],
        segment=segment_label,
        score=score,
        base_rate=base_rate,
        personal_rate=personal_rate,
        hour_start=hour_start,
        hour_end=hour_end,
        notif_hour=notif_hour,
        notif_minute=notif_minute,
    )

    return {
        "eligible": True,
        "customer_id": customer_id,
        "customer_name": customer["name"],
        "segment": pricing_segment,  # dipakai internal (mis. get_ftp di Streamlit)
        "functionalgroup": customer["functionalgroup"],
        "functionalsubgroup": customer["functionalsubgroup"],
        "segment_label": segment_label,
        "product": CAMPAIGN_PRODUCT,
        "tenor_months": CAMPAIGN_TENOR_MONTHS,
        "base_rate": base_rate,
        "customer_score": score,
        "personalized_rate": personal_rate,
        "valid_until_epoch": int(time.time()) + OFFER_VALID_SECONDS,
        "message": message,
        # --- notification timing (Agent 4 scheduling logic) ---
        "usual_txn_hour_start": hour_start,
        "usual_txn_hour_end": hour_end,
        "notification_hour": notif_hour,
        "notification_minute": notif_minute,
        "notification_time_label": f"{notif_hour:02d}:{notif_minute:02d}",
        # --- LLM-generated explanation for the judges' panel ---
        "decision_narrative": narrative,
        # --- Agent 3 scoring transparency ---
        "scoring_method": get_scoring_method(),
    }


def reroll_notification_time(offer: dict) -> dict:
    """Pick a new random notification time within the same customer's usual
    window, without re-running Agent 1-3 (used by the Streamlit 'reroll'
    button to show that the timing is genuinely randomized per click)."""
    notif_hour, notif_minute = pick_notification_time(
        offer["usual_txn_hour_start"], offer["usual_txn_hour_end"]
    )
    offer["notification_hour"] = notif_hour
    offer["notification_minute"] = notif_minute
    offer["notification_time_label"] = f"{notif_hour:02d}:{notif_minute:02d}"
    return offer


if __name__ == "__main__":
    import json

    print(json.dumps(generate_offer("CUST-001"), indent=2, ensure_ascii=False))
