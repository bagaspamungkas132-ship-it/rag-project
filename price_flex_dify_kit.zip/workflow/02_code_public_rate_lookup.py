# Dify Code node — Published Reference Rate Lookup
# This is a static snapshot for the hackathon, not a live OCBC pricing service.


def main(product_name: str, placement_amount_idr: float, tenor_months: int) -> dict:
    p = (product_name or '').strip().lower()
    if 'deposit' in p:
        if tenor_months == 14:
            if placement_amount_idr < 5_000_000:
                return {"ok": False, "reason": "14-day Deposito requires minimum Rp5 million in this snapshot."}
            return {"ok": True, "published_rate_pct": 2.00, "source_type": "OCBC_public_snapshot"}
        if placement_amount_idr < 1_000_000:
            return {"ok": False, "reason": "Minimum Deposito placement is Rp1 million."}
        high_tier = placement_amount_idr >= 500_000_000
        if tenor_months in (1,3):
            rate = 4.75 if high_tier else 4.25
        elif tenor_months in (6,12):
            rate = 5.00 if high_tier else 4.50
        else:
            return {"ok": False, "reason": "Unsupported tenor for demo."}
        return {"ok": True, "published_rate_pct": rate, "source_type": "OCBC_public_snapshot"}

    if 'taka' in p:
        return {"ok": True, "published_rate_pct": 3.25, "source_type": "OCBC_public_snapshot"}

    return {"ok": False, "reason": "Unknown product."}
