"""
dynamic_rate_model.py
Wrapper untuk load model terlatih (dari train_model.py) dan melakukan prediksi
rate_uplift_bps untuk satu nasabah, lalu menerapkan GUARDRAIL supaya hasil akhir
tidak pernah keluar dari rentang Rate_min-Rate_max yang di-approve treasury.

Ini bagian paling penting dari sisi risk/compliance: model ML BOLEH salah atau
bias, tapi guardrail di sini yang menjamin rate akhir tetap aman.
"""
import os
import joblib
import pandas as pd

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "dynamic_rate_model.pkl")

# Guardrail rate per produk -- HARUS sinkron dengan Pricing_Rules yang sudah
# disetujui treasury (lihat Price-Flex-Sample-Data.xlsx sheet Pricing_Rules).
GUARDRAIL = {
    "TAKA Online": {"rate_min": 0.0350, "rate_max": 0.0475, "tenor_min": 6, "tenor_max": 120, "saldo_min": 2_000_000},
    "Deposito Online": {"rate_min": 0.0300, "rate_max": 0.0500, "tenor_min": 1, "tenor_max": 12, "saldo_min": 1_000_000},
}


class DynamicRateAgent:
    def __init__(self, model_path: str = MODEL_PATH):
        bundle = joblib.load(model_path)
        self.model = bundle["model"]
        self.features = bundle["features"]

    def check_eligibility(self, customer: dict, target_produk: str) -> bool:
        rule = GUARDRAIL[target_produk]
        saldo_ok = customer["saldo_rata_rata"] >= rule["saldo_min"]
        tenor_ok = rule["tenor_min"] <= customer["tenor_preference_bulan"] <= rule["tenor_max"]
        return bool(saldo_ok and tenor_ok)

    def predict_uplift_bps(self, customer: dict) -> float:
        X = pd.DataFrame([{f: customer[f] for f in self.features}])
        pred = float(self.model.predict(X)[0])
        return max(pred, 0.0)  # uplift tidak boleh negatif

    def recommend(self, customer: dict, target_produk: str, base_product_rate: float) -> dict:
        """
        Input:
          customer: dict berisi semua FEATURES (usia, vintage_bulan, saldo_rata_rata,
                    product_holding, profitability_score, engagement_score,
                    jumlah_transaksi_bulanan, tenor_preference_bulan)
          target_produk: "TAKA Online" atau "Deposito Online"
          base_product_rate: hasil dari Agent 2 (calc_base_product_rate)
        Output: dict siap dipakai Agent 4 (AI Conductor)
        """
        rule = GUARDRAIL[target_produk]
        eligible = self.check_eligibility(customer, target_produk)

        if not eligible:
            return {
                "customer_id": customer.get("customer_id", "-"),
                "eligible": False,
                "target_produk": target_produk,
                "final_rate": rule["rate_min"],
                "uplift_bps_raw": 0.0,
                "uplift_bps_applied": 0.0,
                "reason": "Tidak memenuhi syarat saldo minimum atau tenor untuk produk ini.",
            }

        uplift_bps_raw = self.predict_uplift_bps(customer)
        final_rate_uncapped = base_product_rate + (uplift_bps_raw / 10_000)

        # >>> GUARDRAIL: clip ke rentang Rate_min-Rate_max <<<
        final_rate = min(max(final_rate_uncapped, rule["rate_min"]), rule["rate_max"])
        uplift_bps_applied = round((final_rate - base_product_rate) * 10_000, 1)

        return {
            "customer_id": customer.get("customer_id", "-"),
            "eligible": True,
            "target_produk": target_produk,
            "base_product_rate": round(base_product_rate, 5),
            "uplift_bps_raw": round(uplift_bps_raw, 1),
            "uplift_bps_applied": uplift_bps_applied,
            "final_rate": round(final_rate, 5),
            "guardrail_hit": final_rate != round(final_rate_uncapped, 5),
            "reason": (
                f"Model memprediksi uplift {uplift_bps_raw:.1f} bps berdasarkan profil "
                f"nasabah (profitability, engagement, vintage). Rate akhir dijaga dalam "
                f"rentang guardrail {rule['rate_min']:.2%}-{rule['rate_max']:.2%}."
            ),
        }


if __name__ == "__main__":
    agent3 = DynamicRateAgent()
    sample_customer = {
        "customer_id": "CUST-DEMO-01",
        "usia": 32,
        "vintage_bulan": 48,
        "saldo_rata_rata": 55_000_000,
        "product_holding": 3,
        "profitability_score": 82,
        "engagement_score": 90,
        "jumlah_transaksi_bulanan": 18,
        "tenor_preference_bulan": 12,
    }
    result = agent3.recommend(sample_customer, "TAKA Online", base_product_rate=0.04637)
    for k, v in result.items():
        print(f"{k}: {v}")
