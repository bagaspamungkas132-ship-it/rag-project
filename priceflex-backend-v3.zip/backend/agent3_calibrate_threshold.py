"""
Agent 3 - eligibility threshold calibration.

Turns a BUSINESS decision (how many target-audience customers can Treasury
actually afford to give a special rate to this campaign?) into a SCORE
cutoff - instead of the threshold being an arbitrary number. AUC is NOT
used here on purpose: AUC measures how well the model ranks customers
relative to each other, not where along that ranking to draw the line -
that line is a capacity/cost decision, which is what this script computes.

Run this:
  - right after training/retraining the model (python agent3_train_model.py)
  - whenever CAMPAIGN_CAPACITY_PCT in pricing_config.py changes
  - whenever the customer base changes meaningfully (new segment mix, big
    growth in the target audience)

It scores every CURRENT target-audience customer in data/customers.csv
(the actual population this campaign will run against - deliberately NOT
data/historical_customers.csv, which is training data, not today's base),
finds the score at the CAMPAIGN_CAPACITY_PCT percentile, and caches it to
model/agent3_eligibility_threshold.json so agent3_dynamic_rate.py can use
it without re-scoring the whole customer base on every single lookup.

Usage:
    python agent3_calibrate_threshold.py
"""
import csv
import datetime
import json
import os

from agent3_dynamic_rate import (
    MODEL_DIR,
    THRESHOLD_PATH,
    get_scoring_method,
    is_target_audience,
    score_customer,
)
from pricing_config import CAMPAIGN_CAPACITY_PCT

CUSTOMERS_PATH = os.path.join(os.path.dirname(__file__), "data", "customers.csv")


def _load_target_audience_scores() -> list:
    with open(CUSTOMERS_PATH, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    scores = []
    for row in rows:
        row["customerage"] = int(row["customerage"])
        if is_target_audience(row):
            scores.append(score_customer(row))
    return scores


def threshold_for_capacity(scores: list, capacity_pct: float) -> float:
    """Score at the (top capacity_pct) cutoff, so that ~capacity_pct of the
    target-audience population scores at or above it."""
    if not scores:
        raise ValueError("No target-audience customers found in data/customers.csv")
    ranked = sorted(scores, reverse=True)
    cutoff_index = max(0, min(len(ranked) - 1, round(len(ranked) * capacity_pct) - 1))
    return ranked[cutoff_index]


def main():
    sm = get_scoring_method()
    if sm["method"] != "xgboost":
        raise SystemExit(
            f"Cannot calibrate: XGBoost model is not loaded ({sm['error']}).\n"
            f"Train it first:\n"
            f"  python data/generate_training_data.py\n"
            f"  python agent3_train_model.py"
        )

    scores = _load_target_audience_scores()
    print(f"Target-audience customers scored: {len(scores)} "
          f"(filtered from data/customers.csv by age+segment, see pricing_config.py)")
    print()
    print("Capacity -> threshold trade-off (sanity-check this before committing):")
    print(f"{'capacity':>10} {'threshold':>10} {'#eligible':>10}")
    for pct in [0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.75, 1.00]:
        t = threshold_for_capacity(scores, pct)
        n_eligible = sum(1 for s in scores if s >= t)
        marker = "  <- CAMPAIGN_CAPACITY_PCT" if abs(pct - CAMPAIGN_CAPACITY_PCT) < 1e-9 else ""
        print(f"{pct:>9.0%} {t:>10.1f} {n_eligible:>10d}{marker}")

    chosen_threshold = threshold_for_capacity(scores, CAMPAIGN_CAPACITY_PCT)
    n_eligible = sum(1 for s in scores if s >= chosen_threshold)

    os.makedirs(MODEL_DIR, exist_ok=True)
    with open(THRESHOLD_PATH, "w", encoding="utf-8") as f:
        json.dump(
            {
                "score_min": chosen_threshold,
                "capacity_pct": CAMPAIGN_CAPACITY_PCT,
                "n_target_audience": len(scores),
                "n_eligible": n_eligible,
                "computed_at": datetime.datetime.now().isoformat(timespec="seconds"),
            },
            f,
            indent=2,
        )
    print()
    print(
        f"Saved: capacity {CAMPAIGN_CAPACITY_PCT:.0%} -> score threshold "
        f"{chosen_threshold} ({n_eligible}/{len(scores)} target-audience "
        f"customers eligible) -> {THRESHOLD_PATH}"
    )


if __name__ == "__main__":
    main()
