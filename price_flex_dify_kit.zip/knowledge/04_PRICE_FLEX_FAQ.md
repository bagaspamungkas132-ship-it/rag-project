# Price Flex Demo FAQ

## What is Price Flex?
An AI-enabled decisioning concept that personalizes promotional pricing by customer, product economics, and timing instead of applying a single rate to everyone.

## What makes it agentic?
Four specialized roles collaborate: ALCO/FTP, Product Rate, Dynamic Rate, and Conductor. The workflow passes outputs from one role to the next and executes a final action recommendation.

## Why not let the LLM choose the final rate freely?
Because financial pricing needs deterministic guardrails. The LLM can analyze and recommend; a rules/code layer validates and clamps the final rate.

## Why choose a transaction-time window?
The demo uses historical transaction-hour behavior to identify when the customer is most likely to engage with an offer.

## Is this production banking logic?
No. All customer records, FTP assumptions, campaign ranges, and personalized uplifts in the demo are simulated unless separately approved and sourced.
