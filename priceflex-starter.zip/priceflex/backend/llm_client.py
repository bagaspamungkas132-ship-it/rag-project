"""
Client untuk LLM internal (OpenAI-compatible endpoint di-host internal OCBC).
Dipakai oleh Agent 4 (Conductor) untuk menulis copy pesan promo yang
dipersonalisasi, supaya bagian "generative AI" di arsitektur benar-benar
jalan, bukan cuma template statis.

PENTING - soal API key:
- Isi api_key ASLI kamu di file `config.yaml` (copy dari config.example.yaml),
  JANGAN pernah ditulis langsung di kode atau di-commit ke Git.
- File `config.yaml` sudah masuk .gitignore supaya aman.

Kalau config.yaml belum ada / api_key belum diisi / endpoint tidak bisa
diakses (mis. kamu di luar jaringan kantor/VPN), fungsi ini otomatis
fallback ke template kalimat statis - jadi demo tidak akan pernah gagal
total gara-gara LLM.
"""
import os

import requests
import yaml

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.yaml")
PLACEHOLDER_KEY = "PASTE_YOUR_INTERNAL_API_KEY_HERE"


def _load_config() -> dict:
    if not os.path.exists(CONFIG_PATH):
        return {}
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return yaml.safe_load(f).get("llm_config", {})
    except Exception as e:
        print(f"[llm_client] Gagal baca config.yaml: {e}")
        return {}


def _fallback_message(customer_name: str, rate: float, tenor_months: int, product: str) -> str:
    return f"Special offer for {customer_name}: {rate}% p.a. {tenor_months}-month {product}."


def generate_offer_message(
    customer_name: str,
    rate: float,
    tenor_months: int,
    product: str = "Deposito Online",
) -> str:
    """Minta LLM internal menulis 1 kalimat pesan notifikasi yang personal.
    Fallback ke template statis kalau LLM tidak tersedia."""
    cfg = _load_config()

    if not cfg or cfg.get("api_key") in (None, "", PLACEHOLDER_KEY):
        # Belum di-setup - langsung fallback, tidak usah coba network call.
        return _fallback_message(customer_name, rate, tenor_months, product)

    prompt = (
        f"Tulis satu kalimat pesan notifikasi bank yang ramah dan singkat "
        f"(maksimal 25 kata) untuk nasabah bernama {customer_name}, menawarkan "
        f"{product} tenor {tenor_months} bulan dengan rate spesial {rate}% per tahun. "
        f"Boleh Bahasa Indonesia atau Inggris santai. Jangan pakai emoji berlebihan, "
        f"cukup satu kalimat saja tanpa tanda kutip."
    )

    try:
        response = requests.post(
            f"{cfg['base_url']}/chat/completions",
            headers={
                "Authorization": f"Bearer {cfg['api_key']}",
                "Content-Type": "application/json",
            },
            json={
                "model": cfg["model"],
                "temperature": cfg.get("temperature", 0.6),
                "max_tokens": 80,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=8,
        )
        response.raise_for_status()
        data = response.json()
        message = data["choices"][0]["message"]["content"].strip().strip('"')
        return message or _fallback_message(customer_name, rate, tenor_months, product)
    except Exception as e:
        print(f"[llm_client] LLM call gagal, pakai fallback. Alasan: {e}")
        return _fallback_message(customer_name, rate, tenor_months, product)


if __name__ == "__main__":
    print(generate_offer_message("Rina Santoso", 4.75, 12))
