"""
Agent 1 - AI Alco/FTP
Fungsi: menentukan modal dasar bank untuk menetapkan Fund Transfer Pricing (FTP)
ke segment dan product. Owner: ALCO, including Treasury.

Untuk hackathon, "AI" di sini disederhanakan jadi rule-based lookup dari FTP
table + sedikit penyesuaian likuiditas. Di production sebenarnya, bagian ini
diisi model time-series forecasting atas stock of money, supply/demand harian,
benchmark kompetitor, dan tren pasar.
"""
import csv
import os

FTP_TABLE_PATH = os.path.join(os.path.dirname(__file__), "data", "ftp_table.csv")


def _load_ftp_table() -> list[dict]:
    with open(FTP_TABLE_PATH, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def get_ftp(segment: str, product: str, tenor_months: int) -> float:
    """Look up the base FTP rate (% p.a.) for a segment/product/tenor combo."""
    table = _load_ftp_table()
    for row in table:
        if (
            row["segment"] == segment
            and row["product"] == product
            and int(row["tenor_months"]) == tenor_months
        ):
            return float(row["ftp_rate"])
    # Fallback: if the exact combo isn't in the table, use a safe default
    return 3.50


def adjust_ftp_for_liquidity(base_ftp: float, liquidity_ratio: float = 1.0) -> float:
    """
    Small illustrative adjustment: if the bank has excess liquidity
    (ratio > 1), it can afford to offer a slightly higher FTP to attract
    more funding; if liquidity is tight (ratio < 1), FTP tightens.
    This stands in for the daily supply/demand + market trend inputs.
    """
    adjustment = (liquidity_ratio - 1.0) * 0.10  # max +/-0.10% for demo purposes
    return round(base_ftp + adjustment, 2)


if __name__ == "__main__":
    rate = get_ftp("Emerging Affluent", "Deposito Online", 12)
    print(f"Base FTP: {rate}% p.a.")
    print(f"Adjusted for tight liquidity: {adjust_ftp_for_liquidity(rate, 0.9)}% p.a.")
