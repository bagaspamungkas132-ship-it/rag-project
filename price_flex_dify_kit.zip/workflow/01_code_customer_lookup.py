# Dify Code node — Customer Lookup
# Inputs expected: customer_id (string), customers_json (string)

import json

def main(customer_id: str, customers_json: str) -> dict:
    try:
        data = json.loads(customers_json)
    except Exception as e:
        return {"found": False, "error": f"Invalid customers_json: {e}"}

    customer = next((x for x in data if x.get("customer_id") == customer_id), None)
    if not customer:
        return {"found": False, "customer": None, "error": "Customer not found"}

    eligible = (
        customer.get("active_customer") == "Y"
        and customer.get("digital_eligible") == "Y"
        and customer.get("active_conflicting_offer") == "N"
        and customer.get("push_opt_out") == "N"
    )
    return {"found": True, "customer": customer, "eligible_precheck": eligible}
