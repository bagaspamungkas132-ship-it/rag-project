"""
Generate synthetic customer data for the PriceFlex hackathon demo.
No external libraries needed (pure Python stdlib) so it runs anywhere for free.

Run:
    python generate_customers.py
Produces:
    customers.csv
"""
import csv
import random

random.seed(42)  # reproducible results across the team

FIRST_NAMES = [
    "Budi", "Siti", "Andi", "Rina", "Dewi", "Agus", "Putri", "Rudi",
    "Sri", "Hendra", "Wati", "Joko", "Lina", "Yudi", "Maya", "Fajar",
]
LAST_NAMES = [
    "Santoso", "Wijaya", "Kusuma", "Pratama", "Saputra", "Lestari",
    "Nugroho", "Setiawan", "Hidayat", "Rahayu",
]
SEGMENTS = ["Personal Banking", "Emerging Affluent", "Business Banking"]
PRODUCT_HOLDINGS = ["Savings only", "Savings + Card", "Savings + Investment", "Full suite"]

NUM_CUSTOMERS = 300


def generate_usual_txn_hours(customer_id: int) -> tuple[int, int]:
    """
    Simulates: "based on the last ~90 days of transaction timestamps in
    core banking / mobile app logs, what is this customer's peak activity
    window?" For the demo we synthesize this instead of mining real
    timestamps, but it's computed with a RNG seeded by customer_id (not
    the shared global `random` stream), so it's reproducible on its own
    and doesn't shift if the rest of this file changes.

    In production this column would instead be the output of a small
    stats job over real transaction logs (e.g. hour-of-day mode, or the
    interquartile range of transaction timestamps per customer).
    """
    rng = random.Random(customer_id * 7919 + 13)
    start_hour = rng.choice(list(range(6, 22)))
    width_hours = rng.choice([1, 1, 1, 2])  # mostly 1-hour windows, sometimes 2
    end_hour = min(start_hour + width_hours, 22)
    return start_hour, end_hour


def generate_row(customer_id: int) -> dict:
    name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
    aum = round(random.uniform(2_000_000, 500_000_000), -3)  # IDR
    vintage_years = round(random.uniform(0.1, 15), 1)
    profitability_score = round(random.uniform(0, 100), 1)
    engagement_score = round(random.uniform(0, 100), 1)
    usual_txn_hour_start, usual_txn_hour_end = generate_usual_txn_hours(customer_id)
    return {
        "customer_id": customer_id,
        "name": name,
        "segment": random.choice(SEGMENTS),
        "aum_idr": int(aum),
        "vintage_years": vintage_years,
        "product_holding": random.choice(PRODUCT_HOLDINGS),
        "profitability_score": profitability_score,
        "engagement_score": engagement_score,
        "usual_txn_hour_start": usual_txn_hour_start,
        "usual_txn_hour_end": usual_txn_hour_end,
    }


def main():
    rows = [generate_row(i) for i in range(1, NUM_CUSTOMERS + 1)]
    fieldnames = list(rows[0].keys())
    with open("customers.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Generated {len(rows)} synthetic customers -> customers.csv")


if __name__ == "__main__":
    main()
