from openai import OpenAI


class LLMClient:
    def __init__(self, api_key: str, base_url: str, model: str,
                 temperature: float = 0.0, max_tokens: int = 200):
        self.client = OpenAI(api_key=api_key, base_url=base_url)
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

    def verify(self, question: str, chunks: list) -> str:
        context_blocks = [
            f"[FILE: {c['filename']}]\n{c['chunk_text']}" for c in chunks
        ]
        context = "\n\n---\n\n".join(context_blocks)

        prompt = f"""Kamu adalah verifikator dokumen internal. Berikut potongan-potongan dokumen hasil pencarian:

{context}

Pertanyaan user: "{question}"

Tugasmu: tentukan apakah jawaban atas pertanyaan tersebut BENAR-BENAR ada di salah satu potongan di atas (bukan sekadar mirip topik/kata kunci).

Jawab HANYA dengan salah satu format berikut, tanpa penjelasan tambahan, tanpa markdown:
DITEMUKAN | <nama_file_persis_seperti_di_atas>
atau
TIDAK DITEMUKAN"""

        response = self.client.chat.completions.create(
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.choices[0].message.content.strip()
