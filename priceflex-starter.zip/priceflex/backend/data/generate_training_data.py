"""
Generate synthetic HISTORICAL customer data + outcome label, dipakai untuk
melatih model XGBoost Agent 3 (agent3_train_model.py).

Ini BEDA dari customers.csv (data nasabah "hari ini" yang dipakai buat demo
generate offer). File ini adalah simulasi log histori: "dari nasabah yang
pernah ditawari rate personal, siapa yang akhirnya benar-benar membuka/
menambah produk?" - label itu (`converted`) yang jadi target belajar model.

Di production, data ini akan datang dari data warehouse/CDP nyata (histori
campaign response), bukan disintesis. Untuk hackathon, kita simulasikan
dengan formula tersembunyi (hidden ground-truth function) + noise acak, jadi
modelnya beneran harus "belajar" pola dari data, bukan cuma menghafal
formula training di file lain.

Run:
    python generate_training_data.py
Produces:
    historical_customers.csv  (6000 baris)
"""
import csv
import math
import random

random.seed(2024)  # seed beda dari generate_customers.py, sengaja independen

N_SAMPLES = 6000

SEGMENTS = ["Personal Banking", "Emerging Affluent", "Business Banking"]
PRODUCT_HOLDINGS = ["Savings only", "Savings + Card", "Savings + Investment", "Full suite"]

# Bobot "kebenaran tersembunyi" yang dipakai buat mensimulasikan histori -
# model XGBoost TIDAK melihat angka-angka ini, dia harus menebak polanya
# dari data historical_customers.csv saja (sama seperti model ML sungguhan).
SEGMENT_BONUS = {"Personal Banking": 0.0, "Emerging Affluent": 0.7, "Business Banking": 0.3}
PRODUCT_BONUS = {
    "Savings only": 0.0,
    "Savings + Card": 0.3,
    "Savings + Investment": 0.5,
    "Full suite": 0.8,
}


def _sigmoid(z: float) -> float:
    return 1.0 / (1.0 + math.exp(-z))


def generate_row(row_id: int) -> dict:
    aum_idr = round(random.uniform(2_000_000, 500_000_000), -3)
    vintage_years = round(random.uniform(0.1, 15), 1)
    profitability_score = round(random.uniform(0, 100), 1)
    engagement_score = round(random.uniform(0, 100), 1)
    segment = random.choice(SEGMENTS)
    product_holding = random.choice(PRODUCT_HOLDINGS)

    # Hidden ground-truth propensity - kombinasi non-linear-ish dari fitur +
    # noise acak (supaya tidak "terlalu mudah" buat model, mirip data nyata
    # yang selalu ada faktor tak terukur).
    z = (
        -4.0
        + 3.0 * (aum_idr / 500_000_000)
        + 2.0 * (vintage_years / 15)
        + 1.8 * (profitability_score / 100)
        + 1.0 * (engagement_score / 100)
        + SEGMENT_BONUS[segment]
        + PRODUCT_BONUS[product_holding]
        + random.gauss(0, 0.7)
    )
    true_prob = _sigmoid(z)
    converted = 1 if random.random() < true_prob else 0

    return {
        "row_id": row_id,
        "aum_idr": int(aum_idr),
        "vintage_years": vintage_years,
        "profitability_score": profitability_score,
        "engagement_score": engagement_score,
        "segment": segment,
        "product_holding": product_holding,
        "converted": converted,
    }


def main():
    rows = [generate_row(i) for i in range(1, N_SAMPLES + 1)]
    fieldnames = list(rows[0].keys())
    with open("historical_customers.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    conversion_rate = sum(r["converted"] for r in rows) / len(rows)
    print(f"Generated {len(rows)} historical records -> historical_customers.csv")
    print(f"Overall conversion rate in this synthetic history: {conversion_rate:.1%}")


if __name__ == "__main__":
    main()
