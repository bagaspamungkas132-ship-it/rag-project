# 3-Minute Demo Script

## 0:00–0:30 — Problem
“Today, customers with very different value, behavior and timing can still receive the same promotional rate. Price Flex moves from one rate for everyone to the right rate for the right customer at the right time.”

## 0:30–1:00 — Show the engine
Show the four agents:
1. AI ALCO / FTP
2. AI Product Rate
3. AI Dynamic Rate
4. AI Conductor

Then show the principle:
**AI recommends. Rules govern.**

## 1:00–1:40 — Run C001 / Budi
Input: Deposito Online, Rp500m, 6 months.
Show customer behavior peaking around 19:00.
Show reference rate 5.00% and a simulated personalized rate of 5.35%.

## 1:40–2:20 — Switch to mobile
Show the notification arriving at 19:05 in the demo script:
“A special rate is available for you — 5.35% p.a.”
Open the offer and click the CTA.

## 2:20–3:00 — Business impact
Show simulated KPI cards only, clearly marked as simulated. Example placeholders:
- Offer conversion: +12%
- Engagement: +18%
- Margin: +5 bps
- Funding cost: -8 bps

## Important
Do not claim these KPIs are real OCBC results.
