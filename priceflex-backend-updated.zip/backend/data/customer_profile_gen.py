"""
Generator atribut nasabah sintetis, dipakai bersama oleh:
  - generate_customers.py       -> customers.csv (nasabah "hari ini", demo)
  - generate_training_data.py   -> historical_customers.csv (data latih Agent 3)

Dipisah jadi modul sendiri dengan alasan yang SAMA seperti kenapa
agent3_features.py dipisah dari agent3_dynamic_rate.py/agent3_train_model.py:
satu sumber kebenaran untuk nama kolom & kemungkinan nilainya, supaya skema
customers.csv dan historical_customers.csv tidak pernah "diam-diam" beda.

RNG tetap independen per caller - fungsi di sini SELALU menerima instance
random.Random milik pemanggil (bukan module-level `random` global), supaya
customers.csv dan historical_customers.csv tetap 2 dataset acak yang beda,
persis seperti desain sebelumnya (seed 42 vs seed 2024).

Skema field mengikuti taksonomi data nasabah riil (functionalgroup/
functionalsubgroup, product holding flags ph_xx/sa_xx/dst) yang dipakai
tim, BUKAN skema demo lama (segment sederhana Personal/Emerging/Business).
Fungsi pricing_segment_for() di bawah yang menjembatani ke 3 kategori lama
supaya Agent 1 (FTP) & Agent 2 (margin) tidak perlu diubah sama sekali.
"""
import random

# --- Taksonomi segmen riil -------------------------------------------------
FUNCTIONAL_SUBGROUPS = [
    ("CONSUMER BANKING", "MASS"),
    ("CONSUMER BANKING", "PREMIER BANKING"),
    ("BUSINESS BANKING", "BUSINESS BANKING"),
]
FUNCTIONAL_SUBGROUP_WEIGHTS = [0.62, 0.23, 0.15]

CHANNELS = ["Mobile Banking", "Internet Banking", "Branch", "Contact Center"]
OCCUPCATS = ["Salaried Worker", "Self Employed", "Professional", "Student", "Retired"]
OCCUPATIONS = ["Employee", "Entrepreneur", "Freelancer", "Business Owner", "Not Working"]
RISK_PROFILES = ["A - Rendah", "B - Menengah", "C - Menengah Tinggi", "D - Tinggi"]
RISK_PROFILE_ORDINAL = {label: i + 1 for i, label in enumerate(RISK_PROFILES)}
MARITAL_STATUSES = ["A - Menikah", "B - Belum Menikah"]
EDUCATIONS = ["D - <SMA", "C - SMA", "B - S1/D3", "A - S2/S3"]
EDUCATION_ORDINAL = {label: i + 1 for i, label in enumerate(EDUCATIONS)}
JOBS = ["PSW-Pegawai Swasta", "WSW-Wiraswasta", "PNS-Pegawai Negeri", "PRO-Profesional", "MHS-Mahasiswa"]
GENDERS = ["M", "F"]

# --- Product holding flags (1/0), sesuai kolom kuning di source data ------
PRODUCT_FLAG_COLUMNS = [
    "ph_27", "sa_idr", "ca_idr", "ca_fcy", "casa_fcy", "sa_taka", "td",
    "sa_tnd_rdn", "td_str", "sa_tnd_jnr", "creditcard", "personalloan",
    "kpr", "kmg", "revolver", "nonrevolver", "kur", "ibl", "iil",
    "tradebg", "tradelc", "tradeloan", "ori", "unittrust",
    "ba_unitlink", "ba_nonunitlink", "emas", "wpb",
]

# Probabilitas kepemilikan produk rata-rata (semua nasabah).
BASE_PRODUCT_PROB = {
    "ph_27": 0.10, "sa_idr": 0.95, "ca_idr": 0.20, "ca_fcy": 0.05,
    "casa_fcy": 0.05, "sa_taka": 0.15, "td": 0.25, "sa_tnd_rdn": 0.05,
    "td_str": 0.03, "sa_tnd_jnr": 0.05, "creditcard": 0.30,
    "personalloan": 0.10, "kpr": 0.12, "kmg": 0.08, "revolver": 0.05,
    "nonrevolver": 0.05, "kur": 0.03, "ibl": 0.02, "iil": 0.02,
    "tradebg": 0.01, "tradelc": 0.01, "tradeloan": 0.02, "ori": 0.05,
    "unittrust": 0.08, "ba_unitlink": 0.04, "ba_nonunitlink": 0.04,
    "emas": 0.06, "wpb": 0.03,
}
# Nasabah PREMIER BANKING: lebih affluent -> lebih banyak produk simpanan
# bertenor & investasi.
PREMIER_BOOST = {
    "td": 0.45, "td_str": 0.12, "unittrust": 0.25, "ori": 0.18,
    "ba_unitlink": 0.15, "ba_nonunitlink": 0.12, "emas": 0.15,
    "creditcard": 0.55, "sa_taka": 0.30, "ca_idr": 0.35,
}
# Nasabah BUSINESS BANKING: lebih banyak produk transaksi/trade finance.
BUSINESS_BOOST = {
    "ca_idr": 0.70, "ca_fcy": 0.30, "casa_fcy": 0.25, "tradebg": 0.20,
    "tradelc": 0.20, "tradeloan": 0.15, "kur": 0.10, "wpb": 0.25,
    "revolver": 0.15, "nonrevolver": 0.15,
}


def generate_profile(rng: random.Random) -> dict:
    """Generate SATU profil atribut nasabah (tanpa customerid/nama/label
    training), dipakai baik untuk customers.csv maupun historical_customers.csv."""
    functionalgroup, functionalsubgroup = rng.choices(
        FUNCTIONAL_SUBGROUPS, weights=FUNCTIONAL_SUBGROUP_WEIGHTS, k=1
    )[0]

    if functionalsubgroup == "MASS":
        aum = round(rng.uniform(2_000_000, 150_000_000), -3)
        income = round(rng.uniform(3_000_000, 15_000_000), -3)
    elif functionalsubgroup == "PREMIER BANKING":
        aum = round(rng.uniform(150_000_000, 1_000_000_000), -3)
        income = round(rng.uniform(15_000_000, 80_000_000), -3)
    else:  # BUSINESS BANKING
        aum = round(rng.uniform(50_000_000, 2_000_000_000), -3)
        income = round(rng.uniform(20_000_000, 150_000_000), -3)
    lum = round(rng.uniform(0, aum * 0.3), -3) if rng.random() < 0.3 else 0

    age = rng.randint(18, 65)  # sengaja macam-macam, bukan cuma Gen Z/Millennial
    activity_status = "Active" if rng.random() < 0.8 else "Dormant"
    functionalsubgroup_boost = (
        PREMIER_BOOST if functionalsubgroup == "PREMIER BANKING"
        else BUSINESS_BOOST if functionalsubgroup == "BUSINESS BANKING"
        else {}
    )
    products = {
        col: (1 if rng.random() < functionalsubgroup_boost.get(col, BASE_PRODUCT_PROB[col]) else 0)
        for col in PRODUCT_FLAG_COLUMNS
    }
    ph_27bal = round(rng.uniform(500_000, 50_000_000), -3) if products["ph_27"] else 0

    return {
        "functionalgroup": functionalgroup,
        "functionalsubgroup": functionalsubgroup,
        "channel": rng.choice(CHANNELS),
        "flagdorman": "N" if activity_status == "Active" else "Y",
        "custtype": (
            "Company" if functionalsubgroup == "BUSINESS BANKING" and rng.random() < 0.4
            else "Individual"
        ),
        "aum_idr": int(aum),
        "lum_idr": int(lum),
        "income_idr": int(income),
        "occupcat": rng.choice(OCCUPCATS),
        "occupation": rng.choice(OCCUPATIONS),
        "customerage": age,
        "customerriskprofile": rng.choice(RISK_PROFILES),
        "maritalstatus": rng.choice(MARITAL_STATUSES),
        "customereducation": rng.choice(EDUCATIONS),
        "customeractivitystatus": activity_status,
        "customerjob": rng.choice(JOBS),
        "customergender": rng.choice(GENDERS),
        **products,
        "ph_27bal_idr": int(ph_27bal),
    }


def pricing_segment_for(functionalgroup: str, functionalsubgroup: str) -> str:
    """Petakan taksonomi riil (functionalgroup/functionalsubgroup) ke 3
    kategori pricing_segment lama yang dipakai Agent 1 (FTP table, lihat
    data/ftp_table.csv) & Agent 2 (margin) - supaya Agent 1-2 TIDAK perlu
    diubah sama sekali walau skema data nasabah berubah total."""
    if functionalgroup == "BUSINESS BANKING":
        return "Business Banking"
    if functionalsubgroup == "PREMIER BANKING":
        return "Emerging Affluent"
    return "Personal Banking"
