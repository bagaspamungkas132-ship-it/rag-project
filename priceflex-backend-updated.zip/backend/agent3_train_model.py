"""
Melatih model XGBoost untuk Agent 3 (AI Dynamic Rate).

Menggantikan skor CLV "weighted formula" manual (yang bobotnya ditebak
sendiri: AUM 40%, vintage 25%, dst) dengan model yang BELAJAR bobotnya dari
data histori (data/historical_customers.csv, lihat generate_training_data.py)
- lebih meyakinkan buat juri karena ada angka validasi (AUC) yang bisa
ditunjukkan, bukan cuma "menurut kami begini".

Cara pakai:
    cd backend
    pip install -r requirements-optional-ml.txt   # hanya kalau CML/laptop
                                                    # kamu bisa install extra
                                                    # package (lihat README)
    python data/generate_training_data.py          # generate sample data
    python agent3_train_model.py                   # latih & simpan model

Kalau langkah ini TIDAK dijalankan (mis. karena environment CML kamu tidak
bisa install xgboost), Agent 3 otomatis tetap jalan pakai rule-based scoring
lama sebagai fallback - lihat agent3_dynamic_rate.py. Jadi aman untuk dicoba;
kalau gagal di tengah jalan, demo tidak akan rusak.
"""
import json
import os
import random

from agent3_features import FEATURE_NAMES, encode_features

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "historical_customers.csv")
MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")
MODEL_PATH = os.path.join(MODEL_DIR, "agent3_clv_model.json")
METADATA_PATH = os.path.join(MODEL_DIR, "agent3_model_metadata.json")

RANDOM_SEED = 7
VAL_FRACTION = 0.2


def _load_rows() -> list:
    import csv

    if not os.path.exists(DATA_PATH):
        raise SystemExit(
            "historical_customers.csv belum ada. Jalankan dulu:\n"
            "    python data/generate_training_data.py"
        )
    with open(DATA_PATH, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main():
    try:
        import xgboost as xgb
    except ImportError as e:
        raise SystemExit(
            "Package 'xgboost' belum ter-install. Install dulu dengan:\n"
            "    pip install -r requirements-optional-ml.txt\n"
            f"(detail error: {e})"
        )

    rows = _load_rows()
    X = [encode_features(row) for row in rows]
    y = [int(row["converted"]) for row in rows]

    # Split train/val manual (tanpa scikit-learn, biar dependency minimal).
    indices = list(range(len(rows)))
    random.Random(RANDOM_SEED).shuffle(indices)
    n_val = int(len(indices) * VAL_FRACTION)
    val_idx, train_idx = indices[:n_val], indices[n_val:]

    X_train = [X[i] for i in train_idx]
    y_train = [y[i] for i in train_idx]
    X_val = [X[i] for i in val_idx]
    y_val = [y[i] for i in val_idx]

    dtrain = xgb.DMatrix(X_train, label=y_train, feature_names=FEATURE_NAMES)
    dval = xgb.DMatrix(X_val, label=y_val, feature_names=FEATURE_NAMES)

    params = {
        "objective": "binary:logistic",
        "eval_metric": "auc",
        "max_depth": 4,
        "eta": 0.1,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "seed": RANDOM_SEED,
    }
    evals_result = {}
    booster = xgb.train(
        params,
        dtrain,
        num_boost_round=300,
        evals=[(dtrain, "train"), (dval, "val")],
        early_stopping_rounds=20,
        evals_result=evals_result,
        verbose_eval=False,
    )

    val_auc = evals_result["val"]["auc"][booster.best_iteration]
    train_auc = evals_result["train"]["auc"][booster.best_iteration]
    importance = booster.get_score(importance_type="gain")
    # Normalize importance to percentages for easier display
    total_gain = sum(importance.values()) or 1.0
    importance_pct = {k: round(v / total_gain * 100, 1) for k, v in importance.items()}

    os.makedirs(MODEL_DIR, exist_ok=True)
    booster.save_model(MODEL_PATH)

    metadata = {
        "n_train": len(train_idx),
        "n_val": len(val_idx),
        "train_auc": round(train_auc, 4),
        "val_auc": round(val_auc, 4),
        "best_iteration": booster.best_iteration,
        "feature_names": FEATURE_NAMES,
        "feature_importance_pct": importance_pct,
        "xgboost_version": xgb.__version__,
    }
    with open(METADATA_PATH, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)

    print(f"Model disimpan ke: {MODEL_PATH}")
    print(f"Metadata disimpan ke: {METADATA_PATH}")
    print(f"Train AUC: {train_auc:.4f} | Val AUC: {val_auc:.4f}")
    print("Feature importance (% gain):")
    for name, pct in sorted(importance_pct.items(), key=lambda kv: -kv[1]):
        print(f"  {name}: {pct}%")


if __name__ == "__main__":
    main()
