# AI Price Flex — Demo Policy & Governance

## Scope
This policy controls the hackathon prototype. It is **not** an OCBC production policy.

## Objective
Move from “one rate for everyone” to “the right rate for the right customer at the right time” while protecting economics and applying explicit guardrails.

## Core decision dimensions
1. Customer value
2. Product fit
3. Engagement / digital propensity
4. Retention propensity
5. Funding economics (simulated FTP)
6. Campaign / product constraints
7. Timing propensity

## Variables that must NOT directly determine pricing
Do not use protected or potentially discriminatory attributes such as race/ethnicity, religion, gender, or other protected characteristics as a direct pricing factor.

## Demo eligibility rules
A customer may receive an offer only when all are true:
- customer is active
- digital channel is eligible
- product is available to the customer
- requested placement meets product minimum
- customer does not have an active conflicting offer
- campaign window is open

## Demo pricing guardrails
These values are intentionally simulated for the hackathon and must be visibly labeled as such.

### Deposito Online
- Personalized uplift cap: +0.50 percentage point (50 bps) over the published online counter rate.
- Minimum economics: final rate must be at least FTP + 0.75 percentage point.
- If the guardrail creates an invalid interval, cap the offer at the highest safe value and mark `guardrail_adjusted=true`.

### TAKA
- Personalized uplift cap: +0.50 percentage point (50 bps) over the published product rate used in this prototype.
- Minimum economics: final rate must be at least FTP + 0.50 percentage point.

## Suggested scoring model (prototype only)
Customer score 0–100:
- Value score: 30%
- Product-fit score: 25%
- Engagement score: 20%
- Retention propensity: 15%
- Balance / liquidity signal: 10%

Suggested uplift from score:
- <60: 0 bps
- 60–69: 10 bps
- 70–79: 20 bps
- 80–89: 35 bps
- 90–100: 50 bps

The score is a prioritization mechanism, not a guarantee.

## Timing rules
The conductor should select a 60-minute engagement window based on the customer’s historical transaction-hour distribution.
- Prefer the hour with the highest historical transaction count.
- Avoid sending during an explicitly opted-out quiet period.
- If historical data are sparse, use the customer’s broader digital activity profile.

## Channel rules
Primary demo channel: mobile push notification.
Fallback: in-app inbox.

## Explanation requirement
Every offer should produce a short reason code such as:
- HIGH_VALUE_HIGH_ENGAGEMENT
- RETENTION_OPPORTUNITY
- BALANCE_GROWTH
- GOAL_SAVING_FIT

Never expose sensitive internal scoring details to the end customer.

## Governance principle
**AI recommends. Rules govern.**
