# Dify Code node — Best Engagement Window
# Inputs: hour_counts_json (e.g. {"07":3,"08":1,...})

import json

def main(hour_counts_json: str) -> dict:
    try:
        counts=json.loads(hour_counts_json)
        counts={str(k).zfill(2): int(v) for k,v in counts.items()}
    except Exception:
        return {"best_window":"19:00-20:00","fallback":True}
    if not counts:
        return {"best_window":"19:00-20:00","fallback":True}
    best=max(counts.items(), key=lambda kv: kv[1])[0]
    h=int(best)
    return {"best_window":f"{h:02d}:00-{(h+1)%24:02d}:00","peak_hour":h,"peak_count":counts[best],"fallback":False}
