"""
Agent 4 - campaign budget pool (first-come-first-served allocation).

Treasury allocates a fixed pool (CAMPAIGN_BUDGET_IDR, pricing_config.py) to
be exhausted within CAMPAIGN_BUDGET_WINDOW_DAYS. Every eligible customer who
buys before the pool runs dry (or the window closes) gets the personalized
rate; whoever is too slow, even if eligible, does not - this module is the
shared, persisted "how much is left" state that makes that race real across
Streamlit reruns/sessions, not just an in-memory counter that resets on
every click.

State is a single JSON file (not a database) - fine for a hackathon demo
with one process; would move to a real DB/cache with row-level locking for
concurrent production traffic.
"""
import datetime
import json
import os
import threading

STATE_PATH = os.path.join(os.path.dirname(__file__), "data", "campaign_budget_state.json")
_lock = threading.Lock()  # avoid a torn read-modify-write if Streamlit fires overlapping reruns


def _now() -> datetime.datetime:
    return datetime.datetime.now()


def _default_state() -> dict:
    from pricing_config import CAMPAIGN_BUDGET_IDR, CAMPAIGN_BUDGET_WINDOW_DAYS

    return {
        "budget_total_idr": CAMPAIGN_BUDGET_IDR,
        "budget_used_idr": 0,
        "campaign_start": _now().isoformat(timespec="seconds"),
        "window_days": CAMPAIGN_BUDGET_WINDOW_DAYS,
        "purchases": [],  # list of {customer_id, amount_idr, timestamp}
    }


def _load_state() -> dict:
    if not os.path.exists(STATE_PATH):
        state = _default_state()
        _save_state(state)
        return state
    with open(STATE_PATH, encoding="utf-8") as f:
        return json.load(f)


def _save_state(state: dict) -> None:
    os.makedirs(os.path.dirname(STATE_PATH), exist_ok=True)
    with open(STATE_PATH, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


def get_status() -> dict:
    """Everything the UI needs to show the budget race: totals, remaining,
    % used, and whether the campaign window is still open."""
    state = _load_state()
    total = state["budget_total_idr"]
    used = state["budget_used_idr"]
    remaining = max(0, total - used)
    start = datetime.datetime.fromisoformat(state["campaign_start"])
    end = start + datetime.timedelta(days=state["window_days"])
    now = _now()
    days_remaining = max(0.0, (end - now).total_seconds() / 86400)
    return {
        "budget_total_idr": total,
        "budget_used_idr": used,
        "budget_remaining_idr": remaining,
        "pct_used": round(used / total, 4) if total else 0.0,
        "campaign_start": state["campaign_start"],
        "campaign_end": end.isoformat(timespec="seconds"),
        "days_remaining": round(days_remaining, 1),
        "is_window_open": now < end,
        "is_exhausted": remaining <= 0,
        "n_purchases": len(state["purchases"]),
    }


def purchase(customer_id: str, amount_idr: float) -> dict:
    """Attempt to claim `amount_idr` from the shared pool for `customer_id`.
    First-come-first-served: whichever call reaches here first (thread lock
    covers same-process races; a real deployment would use a DB-level lock
    for cross-process races) claims the budget - a later caller can find the
    pool already exhausted even if THEY were also eligible."""
    with _lock:
        state = _load_state()
        status = get_status()
        if not status["is_window_open"]:
            return {"success": False, "message": "Campaign window has closed.", "status": status}
        if amount_idr > status["budget_remaining_idr"]:
            return {
                "success": False,
                "message": (
                    f"Sold out: only Rp{status['budget_remaining_idr']:,} left in the "
                    f"campaign pool, less than the requested Rp{amount_idr:,}."
                ),
                "status": status,
            }
        state["budget_used_idr"] += amount_idr
        state["purchases"].append(
            {
                "customer_id": customer_id,
                "amount_idr": amount_idr,
                "timestamp": _now().isoformat(timespec="seconds"),
            }
        )
        _save_state(state)
        return {"success": True, "message": "Purchase confirmed.", "status": get_status()}


def reset() -> dict:
    """Start a fresh campaign window (new budget, empty purchase log) - for
    demo convenience, so a presenter can replay the race from zero."""
    with _lock:
        state = _default_state()
        _save_state(state)
        return get_status()


if __name__ == "__main__":
    print("Resetting campaign budget for a demo run...")
    print(reset())
    print("Simulating 3 purchases of Rp100jt each...")
    for cid in ["CUST-001", "CUST-002", "CUST-003"]:
        result = purchase(cid, 100_000_000)
        print(cid, "->", result["success"], "-", result["message"])
    print("Final status:", get_status())
