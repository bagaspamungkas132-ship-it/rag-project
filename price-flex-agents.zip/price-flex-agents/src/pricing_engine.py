"""
pricing_engine.py
Logika Agent 1 (AI Alco/FTP) dan Agent 2 (AI Product Rate).

CATATAN PENTING (dari sisi data science): kedua agent ini secara natur adalah
kalkulasi kuantitatif treasury, bukan tugas yang butuh LLM untuk "berpikir".
Di sini mereka diimplementasikan sebagai fungsi Python deterministik yang lalu
dibungkus jadi Tool dan dipanggil oleh CrewAI Agent (lihat tools.py) -- supaya
agent tetap bisa menjelaskan hasilnya dalam bahasa natural ke user/juri, tapi
angkanya selalu konsisten dan bisa diaudit (bukan halusinasi LLM).
"""
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# AGENT 1 -- AI Alco/FTP
# Fungsi: Menentukan Modal Dasar Bank untuk Fund Transfer Pricing (FTP)
# ke segment & product. Variable: stock of money, daily supply/demand,
# competitor benchmark, market trend. Basis: Daily.
# ---------------------------------------------------------------------------

@dataclass
class FTPInput:
    base_cost_of_fund: float       # biaya dana dasar bank, mis. BI rate acuan (desimal, cth 0.0600)
    stock_of_money_ratio: float    # rasio stock of money vs target (1.0 = sesuai target)
    demand_supply_index: float     # -1 (oversupply) s.d +1 (demand tinggi/butuh dana)
    competitor_benchmark: float    # rata-rata rate kompetitor produk sejenis (desimal)
    market_trend_bps: float        # penyesuaian tren pasar dlm basis poin (mis. +5 = +0.05%)


def calc_ftp(inp: FTPInput, tenor_bulan: int) -> float:
    """
    Menghasilkan FTP (Fund Transfer Price) harian untuk suatu tenor.
    Formula (disederhanakan untuk demo, tapi mengikuti logika treasury nyata):
        FTP = base_cost_of_fund
              + liquidity_premium(tenor)          # makin panjang tenor, makin mahal
              + demand_supply_adjustment
              + stock_of_money_adjustment
              blended dengan competitor_benchmark (30%) supaya tetap kompetitif
              + market_trend_bps
    """
    # premi likuiditas naik seiring tenor (fungsi tangga sederhana)
    if tenor_bulan <= 3:
        liquidity_premium = 0.0025
    elif tenor_bulan <= 12:
        liquidity_premium = 0.0050
    elif tenor_bulan <= 36:
        liquidity_premium = 0.0075
    else:
        liquidity_premium = 0.0100

    demand_supply_adj = inp.demand_supply_index * 0.0030   # max +-0.30%
    stock_adj = (1 - inp.stock_of_money_ratio) * 0.0020    # kalau stock kurang dari target, FTP naik

    raw_ftp = (
        inp.base_cost_of_fund
        + liquidity_premium
        + demand_supply_adj
        + stock_adj
        + inp.market_trend_bps / 10_000
    )

    # blending 70% hasil internal, 30% competitor benchmark supaya tetap market-aligned
    ftp = 0.7 * raw_ftp + 0.3 * inp.competitor_benchmark
    return round(ftp, 5)


# ---------------------------------------------------------------------------
# AGENT 2 -- AI Product Rate
# Fungsi: Menentukan Margin per Product based on FTP -> harga dasar per produk.
# Variable: product type, product currency, tenor, premi factors. Basis: Daily.
# ---------------------------------------------------------------------------

# Margin yang ditahan bank (spread) per jenis produk -- ini yang mengubah FTP
# jadi rate yang ditawarkan ke nasabah. Angka ini contoh, harus diisi/diapprove
# oleh Product Owner & Treasury sungguhan.
PRODUCT_MARGIN_TABLE = {
    "TAKA Online": 0.0125,       # bank menahan margin 1.25% dari FTP
    "Deposito Online": 0.0100,   # bank menahan margin 1.00% dari FTP
}

# Premi tambahan/pengurang per faktor tambahan (contoh: currency, tenor promo)
PREMI_FACTORS = {
    "IDR": 0.0000,
    "USD": -0.0050,  # produk valas biasanya rate lebih rendah
}


def calc_base_product_rate(ftp: float, produk: str, currency: str = "IDR") -> float:
    """
    base_product_rate = FTP - margin_bank + premi_factor
    Ini rate dasar (belum personalisasi) yang ditampilkan sebagai "harga
    normal" produk sebelum Agent 3 menambahkan uplift personalisasi.
    """
    if produk not in PRODUCT_MARGIN_TABLE:
        raise ValueError(f"Produk '{produk}' tidak dikenal di PRODUCT_MARGIN_TABLE")
    margin = PRODUCT_MARGIN_TABLE[produk]
    premi = PREMI_FACTORS.get(currency, 0.0)
    base_rate = ftp - margin + premi
    return round(max(base_rate, 0), 5)


if __name__ == "__main__":
    # contoh pemakaian manual (tanpa CrewAI) untuk sanity check
    ftp_input = FTPInput(
        base_cost_of_fund=0.0550,
        stock_of_money_ratio=0.95,
        demand_supply_index=0.4,
        competitor_benchmark=0.0525,
        market_trend_bps=3,
    )
    ftp_12m = calc_ftp(ftp_input, tenor_bulan=12)
    print(f"FTP tenor 12 bulan: {ftp_12m:.4%}")

    base_taka = calc_base_product_rate(ftp_12m, "TAKA Online")
    base_deposito = calc_base_product_rate(ftp_12m, "Deposito Online")
    print(f"Base rate TAKA Online: {base_taka:.4%}")
    print(f"Base rate Deposito Online: {base_deposito:.4%}")
