"""
PriceFlex - Streamlit Demo

Run from inside the backend/ folder:
    streamlit run streamlit_app.py

This is the "one app runs everything" demo build - no separate FastAPI
service needed, convenient for presenting straight from VSCode.
"""
import csv
import json
import os

import streamlit as st
import streamlit.components.v1 as components

import campaign_budget
from agent1_ftp import get_ftp
from agent4_conductor import generate_offer, purchase_deposit, reroll_notification_time
from pricing_config import (
    ELIGIBLE_AGE_MAX,
    ELIGIBLE_AGE_MIN,
    ELIGIBLE_FUNCTIONAL_SUBGROUPS,
    MAX_PLACEMENT_PER_CUSTOMER_IDR,
)

CUSTOMERS_PATH = os.path.join(os.path.dirname(__file__), "data", "customers.csv")
MOCKUP_PATH = os.path.join(
    os.path.dirname(__file__), "..", "frontend", "mobile_banking_mockup_interactive.html"
)

st.set_page_config(page_title="PriceFlex Demo", page_icon="💳", layout="wide")


@st.cache_data
def load_customers():
    with open(CUSTOMERS_PATH, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def render_mockup_with_offer(offer: dict) -> str:
    """Read the mockup HTML file as-is, then inject the offer result (from
    Agent 1-2-3-4) directly into it - no separate FastAPI backend needed
    when demoed through Streamlit."""
    with open(MOCKUP_PATH, encoding="utf-8") as f:
        html = f.read()

    if offer.get("eligible", False):
        injected = json.dumps(
            {
                "personalized_rate": offer["personalized_rate"],
                "tenor_months": offer["tenor_months"],
                "message": offer["message"],
                "notification_time_label": offer.get("notification_time_label"),
                "max_placement_idr": offer.get("max_placement_idr"),
            }
        )
        init_script = (
            f"window.__PRICEFLEX_OFFER__ = {injected};"
        )
    else:
        # Customer is not eligible - hide the notification & offer card
        # entirely, so the contrast with an eligible customer is visible.
        init_script = "window.__PRICEFLEX_NOT_ELIGIBLE__ = true;"

    html = html.replace("<body>", f"<body>\n<script>{init_script}</script>", 1)
    html = html.replace(
        "loadOfferFromBackend();",
        (
            "if (window.__PRICEFLEX_NOT_ELIGIBLE__) { hideOffer(); } "
            "else if (window.__PRICEFLEX_OFFER__) { "
            "currentOffer = window.__PRICEFLEX_OFFER__; "
            "updateOfferUI(currentOffer); "
            "} else { loadOfferFromBackend(); }"
        ),
    )
    return html


customers = load_customers()
customer_options = {
    f"{c['name']} · {c['functionalgroup']} - {c['functionalsubgroup']} (ID {c['customerid']})": c["customerid"]
    for c in customers
}

st.title("💳 PriceFlex")
st.caption(
    "One People Company Hackathon — Price Flex: from \"one rate for everyone\" "
    "to \"the right rate for the right customer at the right time\""
)

with st.sidebar:
    st.header("Customer Simulation")
    selected_label = st.selectbox("Select a customer", list(customer_options.keys()))
    customer_id = customer_options[selected_label]
    run = st.button("🚀 Generate Personalized Offer", use_container_width=True)
    st.divider()
    st.caption(
        f"Target audience: Emerging Affluent Gen Z & Millennial only - "
        f"age {ELIGIBLE_AGE_MIN}-{ELIGIBLE_AGE_MAX}, segment "
        f"{' / '.join(sorted(ELIGIBLE_FUNCTIONAL_SUBGROUPS))} "
        f"(see `pricing_config.py`)."
    )
    st.caption(
        "LLM copywriting uses OCBC's internal model (see `config.yaml`). "
        "If it isn't set up or unreachable, the system automatically falls "
        "back to template text - the demo still runs."
    )

    st.divider()
    st.subheader("🏁 Campaign budget (race)")
    st.caption(
        f"Being eligible only means a customer CAN get this offer - the "
        f"personalized rate is first-come-first-served against a shared "
        f"Treasury-set pool, capped at Rp{MAX_PLACEMENT_PER_CUSTOMER_IDR:,} "
        f"per customer."
    )
    budget = campaign_budget.get_status()
    st.progress(min(1.0, budget["pct_used"]))
    st.caption(
        f"Rp{budget['budget_used_idr']:,} / Rp{budget['budget_total_idr']:,} used "
        f"({budget['pct_used']:.1%}) · {budget['n_purchases']} purchase(s) · "
        f"{budget['days_remaining']} day(s) left in this campaign window."
    )
    if budget["is_exhausted"]:
        st.error("Budget exhausted - no more purchases can be confirmed this window.")
    if st.button("🔄 Reset campaign budget (demo only)", use_container_width=True):
        campaign_budget.reset()
        st.rerun()

if run:
    st.session_state["offer"] = generate_offer(customer_id)
    st.session_state["raw_customer"] = next(
        c for c in customers if c["customerid"] == customer_id
    )

offer = st.session_state.get("offer")
raw_customer = st.session_state.get("raw_customer")

col_agents, col_phone = st.columns([1.1, 1])

with col_agents:
    if not offer:
        st.info("Pick a customer in the sidebar, then click **Generate Personalized Offer**.")
    elif not offer.get("eligible", False):
        if offer.get("error"):
            st.error(offer.get("message", "Agent 3 scoring is unavailable."))
        else:
            st.warning(offer.get("message", "This customer does not meet the offer threshold."))
    else:
        st.subheader("4-agent decision trail")
        a1, a2 = st.columns(2)
        a1.metric("Agent 1 · Base FTP", f"{get_ftp(offer['segment'], offer['product'], offer['tenor_months'])}%")
        a2.metric("Agent 2 · Base rate", f"{offer['base_rate']}%")
        if offer.get("amount_tier"):
            st.caption(
                f"Placement amount: IDR {offer['placement_amount_idr']:,} → tier "
                f"**{offer['amount_tier']}**. This base rate is calibrated to match "
                f"OCBC's published Counter Rate IDR - Online table exactly "
                f"(same tenor & placement-amount tiers) — not a synthetic number."
            )
        a3, a4 = st.columns(2)
        a3.metric("Agent 3 · CLV score", f"{offer['customer_score']}")
        a4.metric("Agent 4 · Personal rate", f"{offer['personalized_rate']}%", delta=f"+{round(offer['personalized_rate'] - offer['base_rate'], 2)}%")

        sm = offer.get("scoring_method", {})
        meta = sm.get("metadata") or {}
        st.caption(
            f"🧠 Agent 3 uses the **XGBoost** model "
            f"(val AUC {meta.get('val_auc', '?')}, trained on "
            f"{meta.get('n_train', '?')} historical customers)."
        )

        st.subheader("🛒 Buy this offer (first-come-first-served)")
        live_budget = campaign_budget.get_status()
        if live_budget["is_exhausted"]:
            st.error("Sold out — the campaign budget has already been fully claimed by other customers.")
        else:
            max_buyable = min(offer["max_placement_idr"], live_budget["budget_remaining_idr"])
            buy_amount = st.number_input(
                "Placement amount (IDR)",
                min_value=0,
                max_value=int(max_buyable),
                value=int(max_buyable),
                step=1_000_000,
                help=f"Capped at Rp{offer['max_placement_idr']:,} per customer, and by whatever's left in the campaign pool.",
            )
            if st.button("Confirm purchase", type="primary"):
                result = purchase_deposit(customer_id, offer, buy_amount)
                if result["success"]:
                    st.success(f"Purchase confirmed for Rp{buy_amount:,} at {offer['personalized_rate']}% p.a.")
                else:
                    st.error(result["message"])
                st.rerun()

        with st.expander("📊 Agent 3 methodology (CLV/propensity score)"):
            elig = sm.get("eligibility", {})
            if meta:
                st.markdown(
                    f"""
- **Model**: XGBoost binary classifier — target: probability that a
  customer responds positively to the personalized-rate offer (learned
  from `data/historical_customers.csv`, {meta.get('n_train', '?')} training
  rows + {meta.get('n_val', '?')} validation rows).
- **Validation**: train AUC {meta.get('train_auc', '?')}, validation AUC
  **{meta.get('val_auc', '?')}** (measured on data the model never trained
  on, so it's honest — not a memorized number). Note: AUC measures ranking
  quality, it is deliberately NOT used to set the score cutoff below.
- **Eligibility, in order**: (1) target audience filter — age
  {ELIGIBLE_AGE_MIN}-{ELIGIBLE_AGE_MAX}, segment
  {' / '.join(sorted(ELIGIBLE_FUNCTIONAL_SUBGROUPS))} — checked BEFORE the
  score, independent of it; (2) CLV score must clear
  **{elig.get('score_min', '?')}**.
- **Where that score cutoff comes from**: {elig.get('source', '?')}.
                    """
                )
                if elig.get("source") == "calibrated":
                    st.markdown(
                        f"  - Derived from campaign capacity: top "
                        f"**{elig.get('capacity_pct', 0):.0%}** of "
                        f"{elig.get('n_target_audience', '?')} target-audience "
                        f"customers scored today "
                        f"({elig.get('n_eligible', '?')} eligible) — "
                        f"calibrated {elig.get('computed_at', '?')} by "
                        f"`agent3_calibrate_threshold.py`. Re-run that script "
                        f"after retraining or when `CAMPAIGN_CAPACITY_PCT` in "
                        f"`pricing_config.py` changes."
                    )
                else:
                    st.markdown(
                        "  - ⚠️ Not yet calibrated - run `python "
                        "agent3_calibrate_threshold.py` to replace this "
                        "placeholder with a real campaign-capacity-derived "
                        "number."
                    )
                st.markdown(
                    "- **Most influential features** (% contribution to the "
                    "model, from `feature_importance_pct`):"
                )
                importance = meta.get("feature_importance_pct") or {}
                for name, pct in sorted(importance.items(), key=lambda kv: -kv[1])[:5]:
                    st.markdown(f"  - `{name}`: {pct}%")
                st.markdown(
                    "- **Guardrail**: the 0-100 score from this model is mapped "
                    "to a rate uplift capped as a **percentage of base_rate** "
                    "(`GUARDRAIL_MAX_UPLIFT_PCT` in `pricing_config.py`, "
                    "mirrors how real deposit-rate caps like the FDIC's are "
                    "structured — a % of a reference rate, not a fixed pp "
                    "add-on) — the model can never push the personal rate "
                    "past the limit approved by Treasury/ALCO."
                )
            else:
                st.markdown(
                    "No trained model found. Run `python "
                    "data/generate_training_data.py` then `python "
                    "agent3_train_model.py` (requires the `xgboost` package, "
                    "see `requirements-optional-ml.txt`) to enable scoring."
                )

        st.subheader("⏱ Agent 4 · Personalized notification schedule")
        t1, t2 = st.columns(2)
        t1.metric(
            "Customer's usual active hours",
            f"{offer['usual_txn_hour_start']:02d}.00–{offer['usual_txn_hour_end']:02d}.00",
        )
        t2.metric("Notification scheduled for", offer["notification_time_label"])
        st.caption(
            "The time above is picked RANDOMLY (uniform random) within the "
            "customer's usual transaction window — different customers get "
            "different times; click the button below to reroll and see the "
            "next random pick, still within the same window."
        )
        if st.button("🔀 Reroll notification time (same customer)"):
            st.session_state["offer"] = reroll_notification_time(offer)
            st.rerun()

        with st.expander("📐 How the notification time is computed"):
            st.markdown(
                f"""
1. **Input** — the `usual_txn_hour_start` & `usual_txn_hour_end` columns per
   customer in `customers.csv`. In this demo they're synthetic, but they
   represent the output of analyzing a customer's most frequent transaction
   hours from the last 90 days of core banking / mobile app logs (e.g. mode
   or IQR of transaction timestamps).
2. **Convert to minutes** — the hour range is converted to minutes since
   midnight:
   `window = [{offer['usual_txn_hour_start']} × 60, {offer['usual_txn_hour_end']} × 60]`
   = `[{offer['usual_txn_hour_start']*60}, {offer['usual_txn_hour_end']*60}]`
3. **Pick a random point** — `random.uniform(window_start, window_end)`,
   rounded to the nearest minute → this run's result: **{offer['notification_time_label']}**
4. **Why random, not a fixed point?** So the schedule doesn't feel robotic
   (always the exact same round hour every day) while still guaranteed to
   land within the customer's usual active hours — not 3am.
5. This time is **purely the output of Agent 4's calculation**, not the
   LLM — in this architecture the LLM is only ever used for text (see the
   panel below), never for rate or time figures.
                """
            )

        st.subheader("🤖 Decision summary (generative, Agent 4 — OCBC internal LLM)")
        st.info(offer["decision_narrative"])

        st.subheader("💬 Notification message sent (generative, Agent 4)")
        st.success(offer["message"])

        with st.expander("🗂 Customer data (raw input to Agent 1-3)"):
            st.caption(
                "For transparency to the judges: this is exactly the customer "
                "data row used as input, before it goes into Agent 1-3."
            )
            rows_md = "\n".join(f"| {k} | {v} |" for k, v in raw_customer.items())
            st.markdown(f"| field | value |\n|---|---|\n{rows_md}")

        with st.expander("View raw JSON output (Agent 1-4)"):
            st.json(offer)

        st.subheader("Architecture")
        st.markdown(
            """
            1. **AI Alco/FTP** — base FTP per segment & product (Treasury)
            2. **AI Product Rate** — FTP + margin = base rate
            3. **AI Dynamic Rate** — target-audience filter + CLV/propensity score (XGBoost) → personal rate (bounded by guardrail)
            4. **AI Conductor** — orchestration + notification schedule (customer's usual active hours)
               + message copy & decision summary (LLM) + display on the customer's channel
            """
        )

with col_phone:
    st.subheader("Preview in the customer's app")
    st.caption(
        "The clock in the status bar & lock screen follows the notification "
        "time scheduled by Agent 4 above (not hardcoded to 9:41)."
    )
    if offer:
        components.html(render_mockup_with_offer(offer), height=820, scrolling=True)
    else:
        with open(MOCKUP_PATH, encoding="utf-8") as f:
            components.html(f.read(), height=820, scrolling=True)
