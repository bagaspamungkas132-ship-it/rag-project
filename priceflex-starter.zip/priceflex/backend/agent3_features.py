"""
Shared feature encoding for Agent 3 (AI Dynamic Rate).

Dipakai oleh DUA tempat:
  1. agent3_train_model.py  - saat training model XGBoost
  2. agent3_dynamic_rate.py - saat inference (skor customer real-time)

Sengaja dipisah jadi modul sendiri (bukan didefinisikan ulang di 2 tempat)
supaya urutan & definisi fitur antara training dan inference TIDAK PERNAH
berbeda - ini penyebab paling umum model ML "salah" di production (training-
serving skew). Modul ini murni Python stdlib, tidak butuh pandas/numpy/xgboost,
jadi aman diimpor di mana saja termasuk saat xgboost belum ter-install.
"""

SEGMENTS = ["Personal Banking", "Emerging Affluent", "Business Banking"]
PRODUCT_HOLDINGS = ["Savings only", "Savings + Card", "Savings + Investment", "Full suite"]

FEATURE_NAMES = [
    "aum_idr_million",
    "vintage_years",
    "profitability_score",
    "engagement_score",
    "segment_personal_banking",
    "segment_emerging_affluent",
    "segment_business_banking",
    "product_savings_only",
    "product_savings_card",
    "product_savings_investment",
    "product_full_suite",
]


def encode_features(customer: dict) -> list:
    """Convert a customer record (dict with the same keys as a row in
    customers.csv / historical_customers.csv) into a fixed-order numeric
    feature vector, matching FEATURE_NAMES exactly."""
    aum_million = float(customer["aum_idr"]) / 1_000_000
    vintage = float(customer["vintage_years"])
    profitability = float(customer["profitability_score"])
    engagement = float(customer["engagement_score"])
    segment = customer["segment"]
    product = customer["product_holding"]

    return [
        aum_million,
        vintage,
        profitability,
        engagement,
        1.0 if segment == "Personal Banking" else 0.0,
        1.0 if segment == "Emerging Affluent" else 0.0,
        1.0 if segment == "Business Banking" else 0.0,
        1.0 if product == "Savings only" else 0.0,
        1.0 if product == "Savings + Card" else 0.0,
        1.0 if product == "Savings + Investment" else 0.0,
        1.0 if product == "Full suite" else 0.0,
    ]
