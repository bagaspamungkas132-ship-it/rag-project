"""
PriceFlex - Streamlit Demo

Jalankan dari dalam folder backend/:
    streamlit run streamlit_app.py

Ini adalah versi demo "1 aplikasi jalan semua" - tidak perlu FastAPI
terpisah, cocok untuk presentasi ke juri langsung dari VSCode.
"""
import csv
import json
import os

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

from agent1_ftp import get_ftp
from agent4_conductor import generate_offer, reroll_notification_time

CUSTOMERS_PATH = os.path.join(os.path.dirname(__file__), "data", "customers.csv")
MOCKUP_PATH = os.path.join(
    os.path.dirname(__file__), "..", "frontend", "mobile_banking_mockup_interactive.html"
)

st.set_page_config(page_title="PriceFlex Demo", page_icon="💳", layout="wide")


@st.cache_data
def load_customers():
    with open(CUSTOMERS_PATH, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def render_mockup_with_offer(offer: dict) -> str:
    """Baca file mockup HTML apa adanya, lalu suntik hasil offer (dari Agent
    1-2-3-4) langsung ke dalamnya - tanpa perlu backend FastAPI terpisah
    saat didemokan lewat Streamlit."""
    with open(MOCKUP_PATH, encoding="utf-8") as f:
        html = f.read()

    if offer.get("eligible", False):
        injected = json.dumps(
            {
                "personalized_rate": offer["personalized_rate"],
                "tenor_months": offer["tenor_months"],
                "message": offer["message"],
                "notification_time_label": offer.get("notification_time_label"),
            }
        )
        init_script = (
            f"window.__PRICEFLEX_OFFER__ = {injected};"
        )
    else:
        # Nasabah tidak eligible - sembunyikan notif & offer card sepenuhnya,
        # supaya kelihatan bedanya dengan nasabah yang eligible.
        init_script = "window.__PRICEFLEX_NOT_ELIGIBLE__ = true;"

    html = html.replace("<body>", f"<body>\n<script>{init_script}</script>", 1)
    html = html.replace(
        "loadOfferFromBackend();",
        (
            "if (window.__PRICEFLEX_NOT_ELIGIBLE__) { hideOffer(); } "
            "else if (window.__PRICEFLEX_OFFER__) { "
            "currentOffer = window.__PRICEFLEX_OFFER__; "
            "updateOfferUI(currentOffer); "
            "} else { loadOfferFromBackend(); }"
        ),
    )
    return html


customers = load_customers()
customer_options = {
    f"{c['name']} · {c['segment']} (ID {c['customer_id']})": int(c["customer_id"])
    for c in customers
}

st.title("💳 PriceFlex")
st.caption(
    "One People Company Hackathon — Price Flex: dari \"one rate for everyone\" "
    "ke \"the right rate for the right customer at the right time\""
)

with st.sidebar:
    st.header("Simulasi Nasabah")
    selected_label = st.selectbox("Pilih nasabah", list(customer_options.keys()))
    customer_id = customer_options[selected_label]
    run = st.button("🚀 Generate Personalized Offer", use_container_width=True)
    st.divider()
    st.caption(
        "LLM copywriting memakai model internal OCBC (lihat `config.yaml`). "
        "Kalau belum di-setup atau tidak bisa diakses, sistem otomatis "
        "memakai kalimat template sebagai fallback - demo tetap jalan."
    )

if run:
    st.session_state["offer"] = generate_offer(customer_id)
    st.session_state["raw_customer"] = next(
        c for c in customers if int(c["customer_id"]) == customer_id
    )

offer = st.session_state.get("offer")
raw_customer = st.session_state.get("raw_customer")

col_agents, col_phone = st.columns([1.1, 1])

with col_agents:
    if not offer:
        st.info("Pilih nasabah di sidebar lalu klik **Generate Personalized Offer**.")
    elif not offer.get("eligible", False):
        st.warning(offer.get("message", "Nasabah belum memenuhi ambang batas penawaran."))
    else:
        st.subheader("Jejak keputusan 4 agent")
        a1, a2 = st.columns(2)
        a1.metric("Agent 1 · FTP dasar", f"{get_ftp(offer['segment'], offer['product'], offer['tenor_months'])}%")
        a2.metric("Agent 2 · Base rate", f"{offer['base_rate']}%")
        a3, a4 = st.columns(2)
        a3.metric("Agent 3 · Skor CLV", f"{offer['customer_score']}")
        a4.metric("Agent 4 · Rate personal", f"{offer['personalized_rate']}%", delta=f"+{round(offer['personalized_rate'] - offer['base_rate'], 2)}%")

        st.subheader("⏱ Agent 4 · Jadwal notifikasi personal")
        t1, t2 = st.columns(2)
        t1.metric(
            "Jam biasa nasabah aktif",
            f"{offer['usual_txn_hour_start']:02d}.00–{offer['usual_txn_hour_end']:02d}.00",
        )
        t2.metric("Notifikasi dijadwalkan", offer["notification_time_label"])
        st.caption(
            "Jam di atas diambil ACAK (uniform random) di dalam rentang jam "
            "kebiasaan transaksi nasabah — beda nasabah, beda jam; klik "
            "ulang tombol di bawah untuk lihat hasil acak berikutnya, masih "
            "dalam rentang jam yang sama."
        )
        if st.button("🔀 Acak ulang jam notifikasi (nasabah sama)"):
            st.session_state["offer"] = reroll_notification_time(offer)
            st.rerun()

        with st.expander("📐 Teknis perhitungan jam notifikasi"):
            st.markdown(
                f"""
1. **Input** — kolom `usual_txn_hour_start` & `usual_txn_hour_end` per nasabah
   di `customers.csv`. Di demo ini disintesis, tapi mewakili hasil analisis
   jam-jam nasabah paling sering bertransaksi dari log core banking / mobile
   app 90 hari terakhir (mis. modus atau IQR dari jam transaksi).
2. **Konversi ke menit** — rentang jam diubah ke menit sejak tengah malam:
   `window = [{offer['usual_txn_hour_start']} × 60, {offer['usual_txn_hour_end']} × 60]`
   = `[{offer['usual_txn_hour_start']*60}, {offer['usual_txn_hour_end']*60}]`
3. **Pilih titik acak** — `random.uniform(window_start, window_end)`, lalu
   dibulatkan ke menit terdekat → hasil kali ini: **{offer['notification_time_label']}**
4. **Kenapa acak, bukan titik tetap?** Supaya jadwal tidak terasa robotic
   (selalu pas jam bulat yang sama tiap hari) tapi tetap terjamin muncul di
   jam nasabah biasanya membuka HP-nya — bukan jam 3 pagi.
5. Angka jam ini **murni hasil perhitungan Agent 4**, bukan dari LLM — LLM
   di arsitektur ini cuma dipakai untuk teks (lihat panel di bawah), tidak
   pernah untuk angka rate atau jam.
                """
            )

        st.subheader("🤖 Ringkasan keputusan (generative, Agent 4 — LLM internal OCBC)")
        st.info(offer["decision_narrative"])

        st.subheader("💬 Pesan notifikasi yang dikirim (generative, Agent 4)")
        st.success(offer["message"])

        with st.expander("🗂 Data nasabah (input mentah ke Agent 1-3)"):
            st.caption(
                "Supaya transparan ke juri: ini persis baris data nasabah yang "
                "dipakai sebagai input, sebelum masuk ke Agent 1-3."
            )
            st.dataframe(
                pd.DataFrame([raw_customer]).T.rename(columns={0: "value"}),
                use_container_width=True,
            )

        with st.expander("Lihat raw JSON output (Agent 1-4)"):
            st.json(offer)

        st.subheader("Arsitektur")
        st.markdown(
            """
            1. **AI Alco/FTP** — FTP dasar per segmen & produk (Treasury)
            2. **AI Product Rate** — FTP + margin = base rate
            3. **AI Dynamic Rate** — skor CLV nasabah → rate personal (dibatasi guardrail)
            4. **AI Conductor** — orkestrasi + jadwal notifikasi (jam kebiasaan nasabah)
               + copy pesan & ringkasan keputusan (LLM) + tampil di channel nasabah
            """
        )

with col_phone:
    st.subheader("Preview di aplikasi nasabah")
    st.caption(
        "Jam di status bar & lock screen mengikuti jam notifikasi yang "
        "dijadwalkan Agent 4 di atas (bukan hardcode 9:41)."
    )
    if offer:
        components.html(render_mockup_with_offer(offer), height=820, scrolling=True)
    else:
        with open(MOCKUP_PATH, encoding="utf-8") as f:
            components.html(f.read(), height=820, scrolling=True)
