"""
Agent 2 - AI Product Rate
Fungsi: menentukan margin per product berdasarkan FTP sehingga menghasilkan
harga dasar per product. Owner: Product Owner, Treasury.

Untuk hackathon: margin per product disederhanakan jadi dictionary tetap.
Di production, ini bisa jadi model optimasi margin berbasis elastisitas
volume/rate historis.
"""
from agent1_ftp import get_ftp

# Margin (percentage points) added on top of FTP, varies by product & tenor.
MARGIN_TABLE = {
    ("TAKA Online", 3): 0.75,
    ("TAKA Online", 6): 0.85,
    ("TAKA Online", 12): 0.95,
    ("Deposito Online", 3): 0.60,
    ("Deposito Online", 6): 0.70,
    ("Deposito Online", 12): 0.85,
}


def get_margin(product: str, tenor_months: int) -> float:
    return MARGIN_TABLE.get((product, tenor_months), 0.70)


def get_base_rate(segment: str, product: str, tenor_months: int) -> float:
    """Base rate card = FTP (Agent 1) + margin."""
    ftp = get_ftp(segment, product, tenor_months)
    margin = get_margin(product, tenor_months)
    return round(ftp + margin, 2)


if __name__ == "__main__":
    rate = get_base_rate("Emerging Affluent", "Deposito Online", 12)
    print(f"Base product rate: {rate}% p.a.")
