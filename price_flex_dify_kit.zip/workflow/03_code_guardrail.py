# Dify Code node — Deterministic Price Guardrail
# Inputs expected:
# published_rate_pct, ftp_rate_pct, recommended_uplift_bps, product_name

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def main(published_rate_pct: float, ftp_rate_pct: float, recommended_uplift_bps: int, product_name: str) -> dict:
    product = (product_name or '').lower()
    if 'deposit' in product:
        uplift_cap = 0.50
        margin_floor = 0.75
    else:
        uplift_cap = 0.50
        margin_floor = 0.50

    requested = published_rate_pct + (recommended_uplift_bps / 100.0)
    max_rate = published_rate_pct + uplift_cap
    min_rate = ftp_rate_pct + margin_floor
    raw_final = clamp(requested, min_rate, max_rate)

    # If economics floor is above the published cap, the offer cannot be created safely.
    valid = min_rate <= max_rate
    final_rate = round(raw_final, 2) if valid else None

    return {
      "valid": valid,
      "published_rate_pct": published_rate_pct,
      "requested_rate_pct": round(requested, 2),
      "min_rate_pct": round(min_rate, 2),
      "max_rate_pct": round(max_rate, 2),
      "final_rate_pct": final_rate,
      "guardrail_adjusted": (final_rate is not None and abs(final_rate-requested) > 0.001),
      "is_simulated": True
    }
