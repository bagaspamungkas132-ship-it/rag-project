"""
PriceFlex - central pricing & eligibility configuration.

Single source of truth for every business rule/threshold that Product,
Treasury, Risk or Compliance might want to challenge or tune. Nothing in
agent3_dynamic_rate.py or agent4_conductor.py should hardcode a business
number directly - it should import it from here, so that:

  1. Tuning a rule (e.g. "raise the max age to 45") means editing ONE line
     in ONE file, not hunting through agent code.
  2. When a teammate pushes back on a guardrail/threshold in a review, this
     is the file you point them to and negotiate over - every number here
     is meant to be defensible on its own (who approves it, why this value).

Nothing in this file talks to xgboost, pandas, or any other dependency -
it is safe to import from anywhere, including before packages are installed.
"""

# ---------------------------------------------------------------------------
# Target audience: Emerging Affluent, Gen Z & Millennial only.
# PriceFlex is scoped to this segment on purpose (see project brief) - a
# 65-year-old Business Banking customer should NEVER be eligible, regardless
# of how high their CLV score is.
# ---------------------------------------------------------------------------

# Age range in years, checked against `customerage`.
# Default reasoning (as of 2026): Gen Z ~ born 2000-2012 (age 14-26),
# Millennial ~ born 1981-1996 (age 30-45). Floored at 18 (legal banking age)
# and capped at 43 to stay inside "Millennial", not drift into Gen X.
# Change these two numbers to widen/narrow the target age window.
ELIGIBLE_AGE_MIN = 18
ELIGIBLE_AGE_MAX = 43

# functionalsubgroup values considered part of the "Emerging Affluent"
# target segment. BUSINESS BANKING is intentionally excluded - it is a
# wholesale/SME segment, not an individual retail Gen Z/Millennial customer.
# Owner: Segment/Proposition Owner.
ELIGIBLE_FUNCTIONAL_SUBGROUPS = {"MASS", "PREMIER BANKING"}

# ---------------------------------------------------------------------------
# Agent 3 - CLV/propensity score threshold, derived from CAMPAIGN CAPACITY -
# NOT from AUC. AUC measures how well the model RANKS customers relative to
# each other; it says nothing about where to cut that ranking. The cutoff is
# a business decision: "how many target-audience customers can Treasury
# actually afford to give a special rate to this campaign?"
#
# CAMPAIGN_CAPACITY_PCT below is that business decision. The actual score
# number is computed by agent3_calibrate_threshold.py (scores every current
# target-audience customer in data/customers.csv, then finds the score at
# this percentile) and cached to model/agent3_eligibility_threshold.json.
# Re-run that script whenever: the model is retrained, this percentage
# changes, or the customer base changes meaningfully.
# ---------------------------------------------------------------------------
CAMPAIGN_CAPACITY_PCT = 0.20  # e.g. 0.20 = top 20% of target-audience customers by CLV score

# Fallback threshold used ONLY if agent3_calibrate_threshold.py has never
# been run yet (no cached threshold file present) - so the app still works
# out of the box before the first calibration run.
ELIGIBILITY_SCORE_MIN_DEFAULT = 30.0

# ---------------------------------------------------------------------------
# Guardrail: maximum personal-rate uplift over the base rate, in %-points.
# This is the number Treasury/ALCO must formally approve. The model's score
# can NEVER push the personal rate past base_rate + GUARDRAIL_MAX_UPLIFT,
# no matter how high the predicted propensity is.
# ---------------------------------------------------------------------------
GUARDRAIL_MAX_UPLIFT = 0.95  # e.g. base 3.80% -> personal rate capped at 4.75%

# Optional absolute floor/cap on the final personal rate, applied on top of
# the uplift guardrail above (belt-and-braces, independent of base_rate).
# Set to a number (e.g. 6.00) to enable; leave as None to disable.
PERSONAL_RATE_MIN = None
PERSONAL_RATE_MAX = None
