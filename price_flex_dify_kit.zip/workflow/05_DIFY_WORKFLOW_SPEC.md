# Dify Workflow Specification — AI Price Flex

## App
**AI Price Flex Engine**

## Recommended app type
Workflow

## Workflow graph
```text
START
  |
  v
[Input Validation]
  |
  v
[Customer Lookup - Code]
  |
  +---- not found/invalid ----> [END: Manual Check]
  |
  v
[IF: eligible_precheck]
  | NO
  +----------------------------> [END: Not Eligible]
  | YES
  v
[Knowledge Retrieval: Product KB]
  |
  v
[Agent 1: AI ALCO / FTP]
  |
  v
[Code: Published Rate Lookup]
  |
  v
[Agent 2: AI Product Rate]
  |
  v
[Agent 3: AI Dynamic Rate]
  |
  v
[Code: Guardrail]
  |
  +---- invalid ----> [END: Offer Blocked]
  | valid
  v
[Code: Best Timing]
  |
  v
[Agent 4: AI Conductor]
  |
  v
[Final JSON / END]
```

## Start inputs
Create these workflow variables:
- `customer_id` — short text, required
- `product_name` — short text, required (e.g. `Deposito Online` or `TAKA`)
- `placement_amount_idr` — number, required
- `tenor_months` — number, required for Deposito; use `12` or `0` consistently for TAKA demo
- `liquidity_state` — select/text: `tight|balanced|surplus`
- `market_trend` — select/text: `rising|stable|falling`
- `competitor_gap_pct` — number
- `customers_json` — paragraph/text; paste `07_demo_customers.json` during the hackathon
- `hour_counts_json` — paragraph/text, optional

## Knowledge Base
Create a single knowledge base named `OCBC Price Flex Knowledge` and upload:
1. `01_OCBC_DEPOSITO_ONLINE.md`
2. `02_OCBC_TAKA.md`
3. `03_PRICE_FLEX_POLICY.md`
4. `04_PRICE_FLEX_FAQ.md`

For a hackathon, this keeps retrieval simple and deterministic.

## Node details

### 1) Customer Lookup — Code
Use `01_code_customer_lookup.py`.
Inputs: `customer_id`, `customers_json`.

### 2) IF/ELSE — Eligibility Precheck
Condition: `eligible_precheck == true`.

### 3) Knowledge Retrieval
Query should be built from:
`product_name + tenor_months + placement_amount_idr + published rate`
Top-k: 3 is enough for the demo.

### 4) Agent 1 — AI ALCO / FTP
Use `01_AGENT_ALCO_FTP.md`.
Inject retrieved/supplied `ftp_policy_json`.

### 5) Published Rate Lookup — Code
Use `02_code_public_rate_lookup.py`.

### 6) Agent 2 — AI Product Rate
Use `02_AGENT_PRODUCT_RATE.md`.
Give it the Knowledge Retrieval context and Agent 1 output.

### 7) Agent 3 — AI Dynamic Rate
Use `03_AGENT_DYNAMIC_RATE.md`.
Give it customer profile, product fit, and Agent 2 output.

### 8) Guardrail — Code
Use `03_code_guardrail.py`.
This is the authoritative numeric step for the demo.

### 9) Best Timing — Code
Use `04_code_timing.py` when historical hour counts are provided.

### 10) Agent 4 — AI Conductor
Use `04_AGENT_CONDUCTOR.md`.
It gets customer, final rate, eligibility, and timing.

### 11) Final output
End with a JSON object like the sample in `06_sample_output.json`.

## Dify model selection for a hackathon
Use one fast/cheap model for all four LLM nodes to conserve free credits. You can start with the smallest good model available in your Dify workspace, then move to a stronger model for the final demo if needed.

## Important implementation note
Do not put the 100-customer CSV directly into a Knowledge Base and expect exact customer lookup. For the live hackathon flow, use a small JSON demo set (`07_demo_customers.json`) in the workflow input or put the data behind a small API. The CSV is the larger dataset for analysis/dashboard work.
