# RAG Document Checker — PRD & Panduan

## 1. Tujuan
Mengecek apakah jawaban atas pertanyaan user **ada di dalam kumpulan dokumen** (ribuan file PDF & MD),
dan jika ada, sebutkan **nama file**-nya. Output berupa teks biasa.

## 2. Sumber dokumen
- `product-knowledge/osg/pdf/*.pdf`
- `product-knowledge/rm-copilot/**` (campuran pdf/md)
- `promo-knowledge/osg/md_file/*.md`

Path ini diatur di `config.yaml` → `folders:`. Bisa ditambah/dikurangi sesuai kebutuhan.

## 3. Arsitektur (2 tahap, biar efisien & akurat)

```
Query user
   │
   ▼
[1] Embed pertanyaan (lokal, sentence-transformers)
   │
   ▼
[2] ANN search di FAISS index (top_k chunk paling mirip)
   │
   ▼
[3] Filter berdasarkan similarity_threshold
   │
   ├── Tidak ada yang lolos threshold → jawab "TIDAK DITEMUKAN" (LLM TIDAK dipanggil)
   │
   └── Ada yang lolos → kirim top_k chunk + pertanyaan ke LLM (Qwen)
              │
              ▼
       LLM verifikasi apakah jawaban BENAR-BENAR ada di chunk (bukan cuma mirip topik)
              │
              ▼
       Output: "DITEMUKAN | nama_file.pdf" atau "TIDAK DITEMUKAN"
```

**Kenapa efisien untuk ribuan file:**
- Retrieval pakai FAISS (ANN) → tetap cepat walau jumlah file besar.
- LLM cuma dipanggil kalau retrieval sudah cukup yakin (threshold filter) → hemat biaya/latency.
- Indexing bersifat **incremental**: file yang sudah pernah di-index (hash sama) tidak diproses ulang.

## 4. Kenapa PDF di-parse pakai tabel khusus
Dokumen seperti RIPLAY (contoh: `38_RIPLAY_Umum_KMG_Regular_Mar_2025.pdf`) berisi tabel
(suku bunga per tenor, biaya, syarat dokumen). Kalau diekstrak sebagai teks polos, baris tabel
bisa berantakan (angka lepas dari labelnya). Karena itu `pdf_parser.py` mendeteksi tabel dan
mengonversinya ke format Markdown table, supaya konteks (misal "Fixed 1 tahun = 7,75%") tetap utuh
saat masuk ke chunk.

## 5. Setup

```bash
conda create -n rag-project python=3.11 -y
conda activate rag-project
pip install -r requirements.txt
```

Isi file `.env` (copy dari `.env.example`):
```
LLM_API_KEY=isi_api_key_kamu_di_sini
```

Sesuaikan `config.yaml`:
- `folders:` → path folder dokumen kamu
- `embedding.device:` → `"cuda"` kalau ada GPU, kalau tidak biarkan `"cpu"`
- `llm.base_url` / `llm.model` → sesuai config Qwen kamu

## 6. Cara pakai

**A. Bangun index (jalankan sekali di awal, lalu ulang tiap ada file baru):**
```bash
cd src
python ingest.py
```
Kalau ingin index ulang total (misal banyak file lama berubah isinya):
```bash
python ingest.py --rebuild
```

**B. Query:**
```bash
python query.py "berapa suku bunga fixed 1 tahun untuk KMG?"
```
atau jalankan tanpa argumen lalu ketik pertanyaan saat diminta.

## 7. Keterbatasan yang perlu diketahui
- Update incremental hanya menambah chunk untuk file **baru**. Kalau isi file lama **berubah**
  (hash berbeda), chunk lama belum otomatis terhapus — pakai `--rebuild` secara berkala untuk
  membersihkan.
- `similarity_threshold` di `config.yaml` perlu di-tuning sedikit setelah dicoba dengan beberapa
  pertanyaan asli, tergantung karakteristik dokumen.
- Model embedding default (`BAAI/bge-m3`) mendukung Bahasa Indonesia dengan baik dan multilingual,
  tapi ukurannya lumayan besar (~2GB unduhan pertama kali).
