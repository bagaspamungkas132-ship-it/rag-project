"""
tools.py
Membungkus fungsi-fungsi deterministik & model ML jadi CrewAI Tool, supaya
agent CrewAI bisa memanggilnya sebagai "aksi" dan menjelaskan hasilnya secara
natural -- tapi angkanya tetap dari kalkulasi/model asli, bukan karangan LLM.
"""
import json
from crewai.tools import tool

from .pricing_engine import FTPInput, calc_ftp, calc_base_product_rate
from .dynamic_rate_model import DynamicRateAgent
from .conductor_rules import CampaignWindow, should_send_offer, next_send_time_label

_dynamic_agent = None


def _get_dynamic_agent() -> DynamicRateAgent:
    global _dynamic_agent
    if _dynamic_agent is None:
        _dynamic_agent = DynamicRateAgent()
    return _dynamic_agent


@tool("Hitung FTP (Fund Transfer Price)")
def tool_calc_ftp(
    base_cost_of_fund: float,
    stock_of_money_ratio: float,
    demand_supply_index: float,
    competitor_benchmark: float,
    market_trend_bps: float,
    tenor_bulan: int,
) -> str:
    """
    Menghitung FTP harian untuk suatu tenor berdasarkan cost of fund, rasio
    stock of money, indeks demand/supply, benchmark kompetitor, dan tren pasar.
    Kembalikan JSON string berisi nilai ftp (desimal, mis. 0.0589 = 5.89%).
    """
    inp = FTPInput(
        base_cost_of_fund=base_cost_of_fund,
        stock_of_money_ratio=stock_of_money_ratio,
        demand_supply_index=demand_supply_index,
        competitor_benchmark=competitor_benchmark,
        market_trend_bps=market_trend_bps,
    )
    ftp = calc_ftp(inp, tenor_bulan)
    return json.dumps({"ftp": ftp, "ftp_percent": f"{ftp:.4%}", "tenor_bulan": tenor_bulan})


@tool("Hitung Base Product Rate")
def tool_calc_base_rate(ftp: float, produk: str, currency: str = "IDR") -> str:
    """
    Menghitung base_product_rate = FTP - margin bank + premi currency, untuk
    produk "TAKA Online" atau "Deposito Online". Kembalikan JSON string.
    """
    base_rate = calc_base_product_rate(ftp, produk, currency)
    return json.dumps({"produk": produk, "base_product_rate": base_rate, "base_product_rate_percent": f"{base_rate:.4%}"})


@tool("Rekomendasi Dynamic Rate per Nasabah")
def tool_dynamic_rate(customer_json: str, target_produk: str, base_product_rate: float) -> str:
    """
    Input customer_json: JSON string berisi field customer_id, usia,
    vintage_bulan, saldo_rata_rata, product_holding, profitability_score,
    engagement_score, jumlah_transaksi_bulanan, tenor_preference_bulan.
    Menjalankan model ML (dengan guardrail rate_min-rate_max) untuk
    menentukan apakah nasabah eligible dan berapa final_rate yang
    direkomendasikan. Kembalikan JSON string hasil rekomendasi.
    """
    customer = json.loads(customer_json)
    agent = _get_dynamic_agent()
    result = agent.recommend(customer, target_produk, base_product_rate)
    return json.dumps(result)


@tool("Cek Jadwal Kampanye dan Waktu Kirim")
def tool_should_send(
    nama_campaign: str,
    tanggal_mulai: str,
    tanggal_selesai: str,
    produk_campaign: str,
    tanggal_cek: str,
    produk: str,
    eligible: bool,
    jam_favorit_nasabah: str,
) -> str:
    """
    Mengecek apakah tanggal_cek berada dalam periode campaign untuk produk
    tersebut, dan menggabungkannya dengan status eligible dari Agent 3, untuk
    memutuskan should_send (boolean). Juga mengembalikan window waktu kirim
    yang disarankan berdasarkan jam_favorit_nasabah. Kembalikan JSON string.
    """
    camp = CampaignWindow(
        nama_campaign=nama_campaign,
        tanggal_mulai=tanggal_mulai,
        tanggal_selesai=tanggal_selesai,
        produk=produk_campaign,
    )
    decision = should_send_offer(camp, tanggal_cek, produk, eligible)
    decision["waktu_kirim_disarankan"] = next_send_time_label(jam_favorit_nasabah)
    return json.dumps(decision)
