"""
crew.py
Mendefinisikan 4 agent (persis sesuai diagram "AI Price Flex" kamu) sebagai
CrewAI Agent + Task, lalu merangkainya jadi satu Crew yang jalan berurutan
(Process.sequential): Agent1 -> Agent2 -> Agent3 -> Agent4.

CARA PAKAI:
1. Isi environment variable API key model yang mau dipakai, contoh:
     export ANTHROPIC_API_KEY="sk-ant-..."
   (atau OPENAI_API_KEY kalau mau pakai model OpenAI -- tinggal ganti string
   model di ChatLLM di bawah)
2. python3 -m src.crew

CATATAN: Agent 1 & 2 di-briefing untuk SELALU memanggil tool kalkulasi (bukan
menghitung sendiri dengan "insting" LLM), supaya angkanya konsisten & bisa
diaudit. Agent 3 memanggil model ML asli. Agent 4 yang paling bebas menulis
bahasa natural karena tugasnya memang komunikasi ke nasabah.
"""
import os
import json
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM

from .tools import tool_calc_ftp, tool_calc_base_rate, tool_dynamic_rate, tool_should_send

# Baca file .env otomatis (kalau ada) supaya tidak perlu `export` manual di
# terminal -- jalan sama di Windows/Mac/Linux. Cari .env di folder root
# project (satu level di atas folder src/).
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

# --- Konfigurasi LLM ---
# Opsi A (default): pakai provider resmi (Anthropic/OpenAI/dst) lewat API key
# biasa. Ganti string model sesuai provider, contoh:
#   "anthropic/claude-sonnet-4-5-20250929", "openai/gpt-4o-mini"
#
# Opsi B: pakai endpoint LLM sendiri (internal/company LLM, atau proxy)
# yang kompatibel format OpenAI. Isi PRICE_FLEX_LLM_BASE_URL dan
# PRICE_FLEX_LLM_API_KEY di .env, lalu PRICE_FLEX_LLM_MODEL diisi NAMA
# MODEL sesuai yang dikenali endpoint tersebut (bukan string "provider/model"
# seperti Opsi A -- cukup nama modelnya saja, mis. "gpt-4o" atau nama model
# custom internal).
CUSTOM_BASE_URL = os.getenv("PRICE_FLEX_LLM_BASE_URL")  # kosongkan kalau tidak dipakai
CUSTOM_API_KEY = os.getenv("PRICE_FLEX_LLM_API_KEY")    # kosongkan kalau tidak dipakai

_default_model = "gpt-4o" if CUSTOM_BASE_URL else "anthropic/claude-sonnet-4-5-20250929"
MODEL_NAME = os.getenv("PRICE_FLEX_LLM_MODEL", _default_model)

if CUSTOM_BASE_URL and CUSTOM_API_KEY:
    # Endpoint custom (OpenAI-compatible) -- ini yang dipakai kalau kamu isi
    # base_url & api_key milikmu sendiri di .env
    llm = LLM(
        model=f"openai/{MODEL_NAME}",
        base_url=CUSTOM_BASE_URL,
        api_key=CUSTOM_API_KEY,
        custom_openai=True,
    )
else:
    # Fallback ke provider resmi biasa (butuh ANTHROPIC_API_KEY/OPENAI_API_KEY dll.)
    llm = LLM(model=MODEL_NAME)

# ---------------------------------------------------------------------------
# AGENT 1 -- AI Alco/FTP
# ---------------------------------------------------------------------------
agent1_alco_ftp = Agent(
    role="AI Alco/FTP",
    goal=(
        "Menentukan Modal Dasar Bank untuk Fund Transfer Pricing (FTP) harian "
        "ke segment dan product, dengan SELALU memanggil tool kalkulasi FTP "
        "(jangan pernah menghitung sendiri secara manual)."
    ),
    backstory=(
        "Kamu mewakili fungsi ALCO (Asset Liability Committee) termasuk Treasury. "
        "Kamu bertanggung jawab atas stock of money, daily supply/demand, "
        "competitor benchmark, dan market trend sebagai basis penentuan FTP."
    ),
    tools=[tool_calc_ftp],
    llm=llm,
    verbose=True,
)

# ---------------------------------------------------------------------------
# AGENT 2 -- AI Product Rate
# ---------------------------------------------------------------------------
agent2_product_rate = Agent(
    role="AI Product Rate",
    goal=(
        "Menentukan margin per product berdasarkan FTP dari Agent 1, sehingga "
        "menghasilkan harga dasar (base rate) per produk, dengan SELALU "
        "memanggil tool kalkulasi base rate."
    ),
    backstory=(
        "Kamu mewakili fungsi Product Owner bersama Treasury. Kamu menentukan "
        "harga dasar Deposit Product dan Loan Product berdasarkan product type, "
        "currency, tenor, dan premi factors."
    ),
    tools=[tool_calc_base_rate],
    llm=llm,
    verbose=True,
)

# ---------------------------------------------------------------------------
# AGENT 3 -- AI Dynamic Rate
# ---------------------------------------------------------------------------
agent3_dynamic_rate = Agent(
    role="AI Dynamic Rate",
    goal=(
        "Menentukan special rate per customer berdasarkan customer life time "
        "value (demografis, vintage, AUM/LUM, product holding, profitability, "
        "atribut lain), dengan SELALU memanggil tool rekomendasi dynamic rate "
        "yang sudah memakai model ML dan guardrail resmi."
    ),
    backstory=(
        "Kamu mewakili fungsi Product Owner dan Segment/Proposition Owner. "
        "Kamu TIDAK BOLEH pernah merekomendasikan rate di luar guardrail yang "
        "dikembalikan oleh tool -- tool sudah menjamin itu, kamu cukup "
        "melaporkan hasilnya apa adanya."
    ),
    tools=[tool_dynamic_rate],
    llm=llm,
    verbose=True,
)

# ---------------------------------------------------------------------------
# AGENT 4 -- AI Conductor
# ---------------------------------------------------------------------------
agent4_conductor = Agent(
    role="AI Conductor",
    goal=(
        "Menampilkan offer ke customer baik berbasis aplikasi/web sesuai "
        "jadwal program/campaign -- 'the right rate for the right customer at "
        "the right time'. Cek dulu jadwal campaign & waktu kirim lewat tool, "
        "baru tulis draf pesan notifikasi singkat bila should_send = true."
    ),
    backstory=(
        "Kamu mewakili fungsi Platform Owner dan Segment/Proposition Owner. "
        "Kamu adalah satu-satunya agent yang boleh menulis pesan ke nasabah "
        "-- nada ramah, singkat, tidak menyebut skor internal atau tier."
    ),
    tools=[tool_should_send],
    llm=llm,
    verbose=True,
)


def build_tasks(context: dict) -> list[Task]:
    """
    context: dict berisi semua parameter yang dibutuhkan seluruh pipeline,
    lihat run_demo.py untuk contoh isinya.
    """
    task1 = Task(
        description=(
            f"Hitung FTP untuk tenor {context['tenor_bulan']} bulan dengan "
            f"base_cost_of_fund={context['base_cost_of_fund']}, "
            f"stock_of_money_ratio={context['stock_of_money_ratio']}, "
            f"demand_supply_index={context['demand_supply_index']}, "
            f"competitor_benchmark={context['competitor_benchmark']}, "
            f"market_trend_bps={context['market_trend_bps']}. "
            f"Gunakan tool 'Hitung FTP (Fund Transfer Price)'."
        ),
        expected_output="JSON hasil dari tool berisi field ftp dan ftp_percent.",
        agent=agent1_alco_ftp,
    )

    task2 = Task(
        description=(
            f"Ambil nilai ftp dari hasil Task 1, lalu hitung base_product_rate "
            f"untuk produk '{context['target_produk']}' dengan currency "
            f"'{context.get('currency', 'IDR')}'. Gunakan tool 'Hitung Base "
            f"Product Rate'."
        ),
        expected_output="JSON hasil dari tool berisi field produk dan base_product_rate.",
        agent=agent2_product_rate,
        context=[task1],
    )

    customer_json = json.dumps(context["customer"])
    task3 = Task(
        description=(
            f"Ambil base_product_rate dari hasil Task 2. Data nasabah (JSON): "
            f"{customer_json}. Jalankan tool 'Rekomendasi Dynamic Rate per "
            f"Nasabah' dengan customer_json di atas, target_produk="
            f"'{context['target_produk']}', dan base_product_rate dari Task 2."
        ),
        expected_output=(
            "JSON hasil dari tool berisi eligible, final_rate, uplift_bps_applied, "
            "dan reason."
        ),
        agent=agent3_dynamic_rate,
        context=[task2],
    )

    task4 = Task(
        description=(
            f"Ambil status eligible dari Task 3. Jalankan tool 'Cek Jadwal "
            f"Kampanye dan Waktu Kirim' dengan nama_campaign="
            f"'{context['campaign']['nama_campaign']}', tanggal_mulai="
            f"'{context['campaign']['tanggal_mulai']}', tanggal_selesai="
            f"'{context['campaign']['tanggal_selesai']}', produk_campaign="
            f"'{context['campaign']['produk']}', tanggal_cek="
            f"'{context['tanggal_cek']}', produk='{context['target_produk']}', "
            f"eligible=<hasil dari Task 3>, jam_favorit_nasabah="
            f"'{context['customer']['jam_transaksi_favorit']}'. "
            f"JIKA should_send bernilai true DAN eligible dari Task 3 true, "
            f"tulis draf pesan notifikasi maksimal 3 kalimat bahasa Indonesia, "
            f"nada ramah, sebutkan rate final_rate dari Task 3 secara jelas, "
            f"JANGAN sebutkan skor internal/tier/data pribadi. JIKA tidak, "
            f"jelaskan singkat kenapa notifikasi tidak dikirim."
        ),
        expected_output=(
            "Ringkasan akhir berisi: keputusan should_send, final_rate yang "
            "direkomendasikan, waktu kirim disarankan, dan draf pesan "
            "notifikasi (jika should_send true)."
        ),
        agent=agent4_conductor,
        context=[task3],
    )

    return [task1, task2, task3, task4]


def run_price_flex_pipeline(context: dict) -> str:
    tasks = build_tasks(context)
    crew = Crew(
        agents=[agent1_alco_ftp, agent2_product_rate, agent3_dynamic_rate, agent4_conductor],
        tasks=tasks,
        process=Process.sequential,
        verbose=True,
    )
    result = crew.kickoff()
    return str(result)


if __name__ == "__main__":
    demo_context = {
        "base_cost_of_fund": 0.0550,
        "stock_of_money_ratio": 0.95,
        "demand_supply_index": 0.4,
        "competitor_benchmark": 0.0525,
        "market_trend_bps": 3,
        "tenor_bulan": 12,
        "target_produk": "TAKA Online",
        "currency": "IDR",
        "tanggal_cek": "2026-09-09",
        "campaign": {
            "nama_campaign": "Price Flex Launch - TAKA Online",
            "tanggal_mulai": "2026-09-01",
            "tanggal_selesai": "2026-09-30",
            "produk": "TAKA Online",
        },
        "customer": {
            "customer_id": "CUST-DEMO-01",
            "usia": 32,
            "vintage_bulan": 48,
            "saldo_rata_rata": 55_000_000,
            "product_holding": 3,
            "profitability_score": 82,
            "engagement_score": 90,
            "jumlah_transaksi_bulanan": 18,
            "tenor_preference_bulan": 12,
            "jam_transaksi_favorit": "19:00-21:00",
        },
    }
    print(run_price_flex_pipeline(demo_context))
