"""
Cek apakah jawaban atas pertanyaan ada di dalam dokumen yang sudah di-index.

Pemakaian:
    python query.py "berapa suku bunga fixed 1 tahun untuk KMG?"
atau jalankan tanpa argumen lalu ketik pertanyaan saat diminta.
"""
import os
import sys
import yaml
from dotenv import load_dotenv

sys.path.append(os.path.dirname(__file__))
from embedder import Embedder
from vector_store import VectorStore
from llm_client import LLMClient

load_dotenv()


def main():
    with open("config.yaml", "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    question = " ".join(sys.argv[1:]).strip()
    if not question:
        question = input("Masukkan pertanyaan: ").strip()
    if not question:
        print("Pertanyaan kosong.")
        return

    store = VectorStore(
        dim=cfg["embedding"]["dim"],
        index_path=cfg["vector_store"]["index_path"],
        metadata_path=cfg["vector_store"]["metadata_path"],
    )
    if not store.exists():
        print("Index belum dibuat. Jalankan `python ingest.py` terlebih dahulu.")
        return
    store.load()

    embedder = Embedder(cfg["embedding"]["model_name"], cfg["embedding"].get("device", "cpu"))
    query_emb = embedder.encode([question], is_query=True)[0]

    top_k = cfg["vector_store"]["top_k"]
    results = store.search(query_emb, top_k=top_k)

    threshold = cfg["vector_store"]["similarity_threshold"]
    strong_results = [r for r in results if r["score"] >= threshold]

    # Tahap 1: kalau tidak ada kandidat yang cukup mirip, jangan panggil LLM sama sekali (hemat biaya/waktu)
    if not strong_results:
        print("TIDAK DITEMUKAN")
        if results:
            best = results[0]
            print(f"(skor kemiripan tertinggi hanya {best['score']:.3f}, di bawah threshold {threshold})")
        return

    # Tahap 2: verifikasi lewat LLM hanya untuk kandidat yang lolos threshold
    api_key = os.getenv("LLM_API_KEY", "")
    if not api_key:
        print("[ERROR] LLM_API_KEY belum diatur. Isi di file .env")
        return

    llm = LLMClient(
        api_key=api_key,
        base_url=cfg["llm"]["base_url"],
        model=cfg["llm"]["model"],
        temperature=cfg["llm"].get("temperature", 0.0),
        max_tokens=cfg["llm"].get("max_tokens", 200),
    )

    verdict = llm.verify(question, strong_results)
    print(verdict)


if __name__ == "__main__":
    main()
