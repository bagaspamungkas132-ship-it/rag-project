"""
Generate synthetic HISTORICAL customer data + outcome label, dipakai untuk
melatih model XGBoost Agent 3 (agent3_train_model.py).

Ini BEDA dari customers.csv (data nasabah "hari ini" yang dipakai buat demo
generate offer). File ini adalah simulasi log histori: "dari nasabah yang
pernah ditawari rate personal, siapa yang akhirnya benar-benar membuka/
menambah produk?" - label itu (`converted`) yang jadi target belajar model.

Skema atribut (functionalgroup/functionalsubgroup, product holding flags,
dst) berbagi definisi yang SAMA dengan customers.csv lewat
customer_profile_gen.py, supaya tidak ada training-serving skew di level
skema kolom. profitability_score/engagement_score sudah di-exclude dari
seluruh pipeline Agent 3 sesuai keputusan tim.

Di production, data ini akan datang dari data warehouse/CDP nyata (histori
campaign response), bukan disintesis. Untuk hackathon, kita simulasikan
dengan formula tersembunyi (hidden ground-truth function) + noise acak, jadi
modelnya beneran harus "belajar" pola dari data, bukan cuma menghafal
formula training di file lain.

Run:
    python generate_training_data.py
Produces:
    historical_customers.csv  (6000 baris)
"""
import csv
import math
import os
import random

from customer_profile_gen import PRODUCT_FLAG_COLUMNS, RISK_PROFILE_ORDINAL, generate_profile

OUTPUT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "historical_customers.csv")

random.seed(2024)  # seed beda dari generate_customers.py, sengaja independen

N_SAMPLES = 6000

AGE_MIN, AGE_MAX = 18, 65
RISK_MAX = max(RISK_PROFILE_ORDINAL.values())

# Bobot "kebenaran tersembunyi" yang dipakai buat mensimulasikan histori -
# model XGBoost TIDAK melihat angka-angka ini, dia harus menebak polanya
# dari data historical_customers.csv saja (sama seperti model ML sungguhan).
FUNCTIONALSUBGROUP_BONUS = {"MASS": 0.0, "PREMIER BANKING": 0.6, "BUSINESS BANKING": 0.3}


def _sigmoid(z: float) -> float:
    return 1.0 / (1.0 + math.exp(-z))


def generate_row(row_id: int) -> dict:
    profile = generate_profile(random)

    product_count = sum(profile[col] for col in PRODUCT_FLAG_COLUMNS)
    risk_ordinal = RISK_PROFILE_ORDINAL[profile["customerriskprofile"]]
    is_active = 1.0 if profile["customeractivitystatus"] == "Active" else 0.0
    age_youth_bonus = 1.0 - (profile["customerage"] - AGE_MIN) / (AGE_MAX - AGE_MIN)  # muda = bonus lebih tinggi

    # Hidden ground-truth propensity - kombinasi non-linear-ish dari fitur +
    # noise acak (supaya tidak "terlalu mudah" buat model, mirip data nyata
    # yang selalu ada faktor tak terukur).
    z = (
        -4.0
        + 2.5 * (profile["aum_idr"] / 1_000_000_000)
        + 1.5 * (profile["income_idr"] / 150_000_000)
        + 1.5 * (product_count / len(PRODUCT_FLAG_COLUMNS))
        + 1.0 * is_active
        + 0.8 * (risk_ordinal / RISK_MAX)
        + 1.0 * age_youth_bonus
        + FUNCTIONALSUBGROUP_BONUS[profile["functionalsubgroup"]]
        + random.gauss(0, 0.7)
    )
    true_prob = _sigmoid(z)
    converted = 1 if random.random() < true_prob else 0

    return {"row_id": row_id, **profile, "converted": converted}


def main():
    rows = [generate_row(i) for i in range(1, N_SAMPLES + 1)]
    fieldnames = list(rows[0].keys())
    with open(OUTPUT_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    conversion_rate = sum(r["converted"] for r in rows) / len(rows)
    print(f"Generated {len(rows)} historical rows -> {OUTPUT_PATH}")
    print(f"Overall conversion rate: {conversion_rate:.1%}")


if __name__ == "__main__":
    main()
