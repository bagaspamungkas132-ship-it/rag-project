"""
conductor_rules.py
Bagian deterministik dari Agent 4 (AI Conductor): menentukan APAKAH dan KAPAN
sebuah offer boleh ditampilkan/dikirim ke nasabah.

Bagian "menulis pesan notifikasi yang natural" ada di crew.py (itu bagian yang
memang cocok pakai LLM). Bagian DI SINI murni aturan bisnis: jadwal campaign,
jam favorit nasabah, dan guard supaya tidak spam notifikasi.
"""
from dataclasses import dataclass
from datetime import datetime, time


@dataclass
class CampaignWindow:
    nama_campaign: str
    tanggal_mulai: str   # "YYYY-MM-DD"
    tanggal_selesai: str # "YYYY-MM-DD"
    produk: str           # "TAKA Online" / "Deposito Online" / "ALL"


def is_within_campaign(campaign: CampaignWindow, tanggal_cek: str, produk: str) -> bool:
    mulai = datetime.strptime(campaign.tanggal_mulai, "%Y-%m-%d").date()
    selesai = datetime.strptime(campaign.tanggal_selesai, "%Y-%m-%d").date()
    cek = datetime.strptime(tanggal_cek, "%Y-%m-%d").date()
    produk_cocok = campaign.produk == "ALL" or campaign.produk == produk
    return mulai <= cek <= selesai and produk_cocok


def parse_jam_favorit(jam_favorit_str: str) -> tuple[time, time]:
    """'19:00-21:00' -> (time(19,0), time(21,0))"""
    start_str, end_str = jam_favorit_str.split("-")
    h1, m1 = map(int, start_str.split(":"))
    h2, m2 = map(int, end_str.split(":"))
    return time(h1, m1), time(h2, m2)


def next_send_time_label(jam_favorit_str: str) -> str:
    """
    Mengembalikan label waktu kirim yang disarankan (untuk demo, ini cukup
    mengembalikan jam favorit nasabah sebagai window pengiriman).
    Di production, ini bisa diganti scheduler beneran (Power Automate/cron)
    yang menjadwalkan job pengiriman pada jam tersebut.
    """
    start, end = parse_jam_favorit(jam_favorit_str)
    return f"{start.strftime('%H:%M')}-{end.strftime('%H:%M')}"


def should_send_offer(
    campaign: CampaignWindow,
    tanggal_cek: str,
    produk: str,
    eligible_from_agent3: bool,
) -> dict:
    """
    Gate akhir sebelum notifikasi benar-benar dikirim. Menggabungkan:
    - eligible = Ya dari Agent 3
    - tanggal sekarang berada dalam periode campaign
    """
    in_window = is_within_campaign(campaign, tanggal_cek, produk)
    decision = bool(eligible_from_agent3 and in_window)
    return {
        "should_send": decision,
        "in_campaign_window": in_window,
        "campaign": campaign.nama_campaign,
    }


if __name__ == "__main__":
    camp = CampaignWindow(
        nama_campaign="Price Flex Launch - TAKA Online",
        tanggal_mulai="2026-09-01",
        tanggal_selesai="2026-09-30",
        produk="TAKA Online",
    )
    print(should_send_offer(camp, "2026-09-09", "TAKA Online", eligible_from_agent3=True))
    print(next_send_time_label("19:00-21:00"))
