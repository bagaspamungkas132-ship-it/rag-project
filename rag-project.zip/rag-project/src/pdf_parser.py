"""
Ekstraksi teks dari PDF, dengan tabel dikonversi ke format Markdown
supaya konteks (misal: label suku bunga <-> angkanya) tidak berantakan
saat dipecah jadi chunk.
"""
import pdfplumber
from typing import List


def _in_bbox(obj, bbox) -> bool:
    x0, top, x1, bottom = bbox
    return (
        obj.get("x0", 0) >= x0
        and obj.get("x1", 0) <= x1
        and obj.get("top", 0) >= top
        and obj.get("bottom", 0) <= bottom
    )


def _table_to_markdown(table: List[List]) -> str:
    if not table or not table[0]:
        return ""
    rows = [[(cell or "").strip().replace("\n", " ") for cell in row] for row in table]
    header = rows[0]
    lines = [
        "| " + " | ".join(header) + " |",
        "| " + " | ".join(["---"] * len(header)) + " |",
    ]
    for row in rows[1:]:
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def extract_pdf_text(filepath: str) -> str:
    full_text = []
    with pdfplumber.open(filepath) as pdf:
        for page_num, page in enumerate(pdf.pages, start=1):
            page_parts = []

            tables = page.find_tables()
            table_bboxes = [t.bbox for t in tables]

            if table_bboxes:
                non_table = page.filter(
                    lambda obj: not any(_in_bbox(obj, bbox) for bbox in table_bboxes)
                )
                text = non_table.extract_text() or ""
            else:
                text = page.extract_text() or ""

            if text.strip():
                page_parts.append(text.strip())

            for table in page.extract_tables():
                md_table = _table_to_markdown(table)
                if md_table:
                    page_parts.append(md_table)

            if page_parts:
                full_text.append(f"[Halaman {page_num}]\n" + "\n\n".join(page_parts))

    return "\n\n".join(full_text)
