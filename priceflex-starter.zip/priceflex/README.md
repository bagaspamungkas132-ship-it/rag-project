# PriceFlex — Starter Project

Starter code untuk hackathon "One People Company" — implementasi 4 AI agent
(Alco/FTP, Product Rate, Dynamic Rate, Conductor) yang terhubung ke mockup
mobile banking interaktif, plus demo Streamlit yang menyematkan mockup HP
langsung di dalamnya dan memakai LLM internal (bukan API eksternal) untuk
menulis copy pesan promo.

Semua tool di panduan ini punya **free tier** dan cukup untuk kebutuhan demo
hackathon (bukan skala production).

## Struktur folder

```
priceflex/
├── backend/
│   ├── agent1_ftp.py             Agent 1 - AI Alco/FTP
│   ├── agent2_product_rate.py    Agent 2 - AI Product Rate
│   ├── agent3_dynamic_rate.py    Agent 3 - AI Dynamic Rate
│   ├── agent4_conductor.py       Agent 4 - AI Conductor (orkestrasi)
│   ├── llm_client.py             Wrapper ke LLM internal OCBC (dengan fallback)
│   ├── config.example.yaml       Template config LLM (copy jadi config.yaml)
│   ├── main.py                   FastAPI app (endpoint /offer/{id})
│   ├── streamlit_app.py          Demo Streamlit - mockup HP disematkan di sini
│   ├── requirements.txt
│   ├── .gitignore                supaya config.yaml (berisi API key) tidak ke-commit
│   └── data/
│       ├── customers.csv            data nasabah sintetis (sudah digenerate)
│       ├── generate_customers.py    script kalau mau generate ulang
│       └── ftp_table.csv            tabel FTP dasar (Agent 1)
└── frontend/
    └── mobile_banking_mockup_interactive.html   mockup dari sesi sebelumnya
```

## 0. Setup di VSCode

1. Extract zip ini, buka foldernya di VSCode (`File > Open Folder`).
2. Buka terminal terintegrasi (`` Ctrl+` ``), lalu buat virtual environment:
   ```bash
   cd backend
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # Mac/Linux:
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
3. Install extension "Python" dari Microsoft kalau belum ada, lalu pilih
   interpreter `.venv` yang baru dibuat (`Ctrl+Shift+P` → *Python: Select
   Interpreter*).

## 1. Setup LLM internal (WAJIB sebelum copy pesan LLM aktif)

1. Copy `config.example.yaml` menjadi `config.yaml` di folder yang sama:
   ```bash
   cp config.example.yaml config.yaml
   ```
2. Buka `config.yaml`, isi `api_key` dengan API key internal kamu yang asli
   (yang di screenshot foto kamu masih di-mask jadi `***`, jadi harus kamu
   isi manual — aku tidak bisa mengisikan key rahasia ini untukmu).
3. `base_url` dan `model` sudah aku isi sesuai config yang kamu tunjukkan
   (`llmqwen14b.wssdx.apps.cml.ocbcnisp.com`). Sesuaikan lagi kalau ada
   endpoint lain yang mau dipakai (baris yang di-comment pakai `#` adalah
   opsi alternatif, misal endpoint vision-language).
4. **Jangan commit `config.yaml` ke Git** — sudah otomatis diabaikan lewat
   `.gitignore`. Yang di-commit cukup `config.example.yaml` (tanpa key asli).
5. Kalau `config.yaml` belum ada / key belum diisi / endpoint tidak
   ke-reach (mis. sedang di luar jaringan kantor/VPN), semua fungsi tetap
   jalan normal — Agent 4 otomatis pakai kalimat template statis sebagai
   fallback, jadi demo tidak akan pernah gagal total.

## 2. Jalankan demo Streamlit (cara paling gampang untuk presentasi)

```bash
cd backend
streamlit run streamlit_app.py
```

Browser akan terbuka otomatis (`localhost:8501`). Di sini kamu bisa:
- Pilih nasabah dari dropdown di sidebar
- Klik **Generate Personalized Offer** → lihat jejak keputusan Agent 1-2-3-4
- Lihat pesan promo hasil LLM internal (atau fallback kalau belum di-setup)
- **Mockup HP-nya muncul langsung di sebelah kanan**, dengan rate & pesan
  yang sudah otomatis ke-update sesuai nasabah yang dipilih — tidak perlu
  jalankan FastAPI terpisah untuk mode demo ini.

## 3. (Opsional) Jalankan versi FastAPI + HTML terpisah

Kalau suatu saat mau demo mockup HTML-nya berdiri sendiri di browser
(bukan lewat Streamlit), tetap bisa:

```bash
cd backend
uvicorn main:app --reload
```

Buka `http://127.0.0.1:8000/docs` untuk Swagger UI, lalu buka
`frontend/mobile_banking_mockup_interactive.html` langsung di browser
(double click) selama backend ini jalan — mockup akan `fetch()` ke
`http://127.0.0.1:8000/offer/1` secara otomatis.

## 4. Kalau mau develop bareng tim (gratis, tanpa install lokal)

- **GitHub Codespaces** (gratis untuk akun personal, ada kuota jam/bulan):
  push folder ini ke repo GitHub (pastikan `config.yaml` asli TIDAK ikut ke-push),
  lalu buka lewat Codespaces.
- Alternatif: **Replit** (free tier).

## 5. Deploy (opsional, kalau mau demo dari HP juri langsung tanpa laptop kamu)

**Streamlit Community Cloud** (gratis, paling cocok karena demo utama kita di Streamlit):
1. Push repo ke GitHub (tanpa `config.yaml` asli).
2. Buka share.streamlit.io → connect repo → pilih `backend/streamlit_app.py`.
3. Di menu *Secrets*, masukkan isi `config.yaml` kamu (Streamlit Cloud
   punya fitur Secrets khusus untuk ini, jadi key tidak perlu ditulis di kode).
   Catatan: kalau pakai cara ini, `llm_client.py` perlu sedikit disesuaikan
   untuk baca dari `st.secrets` juga — kabari aku kalau mau aku bantu ubah.

**Render/Railway** untuk versi FastAPI + Netlify/Vercel untuk versi HTML statis
— lihat catatan di bagian sebelumnya kalau masih mau pakai jalur ini juga.

## 6. Urutan demo yang disarankan untuk juri

1. Buka Streamlit, pilih 1-2 nasabah berbeda → tunjukkan rate personalnya
   beda-beda (bukan hardcode) dan pesan LLM-nya juga berubah.
2. Tunjuk panel "Jejak keputusan 4 agent" — jelaskan tiap angka datang dari
   agent mana.
3. Perbesar/scroll ke mockup HP di sebelah kanan — tunjukkan bagaimana
   hasil yang sama muncul di sisi customer (notif, offer card, halaman deposit).
4. Kalau ditanya soal LLM: jelaskan pakai model internal OCBC (bukan API
   luar) via `config.yaml`, dengan fallback otomatis kalau endpoint tidak
   bisa diakses saat demo (menunjukkan sistem robust).

## Batasan yang jujur disampaikan ke juri (kalau ditanya)

- Data nasabah sintetis (generated), bukan data real — untuk hackathon ini
  cukup, di production akan pakai data core banking + CDP.
- Scoring Agent 3 masih rule-based (weighted formula), bukan model ML
  terlatih — roadmap-nya ke XGBoost/LightGBM dengan data transaksi historis.
- Guardrail (`GUARDRAIL_MAX_UPLIFT` di `agent3_dynamic_rate.py`) masih angka
  contoh — di production harus melalui sign-off Treasury/ALCO.
- Copy pesan Agent 4 memakai LLM internal untuk generative text saja
  (bukan untuk menentukan rate) — angka rate tetap 100% dari logic
  Agent 1-2-3 yang auditable, LLM tidak pernah menentukan angka.
