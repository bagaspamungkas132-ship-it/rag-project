"""
Splitter sederhana: coba pecah di batas paragraf dulu (\n\n),
baru fallback ke sliding window kalau satu paragraf terlalu panjang.
Ukuran dalam karakter (bukan token) supaya tidak butuh tokenizer tambahan.
"""
from typing import List


def split_text(text: str, chunk_size: int = 1200, overlap: int = 150) -> List[str]:
    if not text or not text.strip():
        return []
    if len(text) <= chunk_size:
        return [text.strip()]

    paragraphs = [p for p in text.split("\n\n") if p.strip()]
    raw_chunks = []
    current = ""

    for para in paragraphs:
        if len(current) + len(para) + 2 <= chunk_size:
            current = f"{current}\n\n{para}" if current else para
        else:
            if current:
                raw_chunks.append(current)
            if len(para) > chunk_size:
                step = max(chunk_size - overlap, 1)
                for i in range(0, len(para), step):
                    raw_chunks.append(para[i:i + chunk_size])
                current = ""
            else:
                current = para

    if current:
        raw_chunks.append(current)

    final_chunks = []
    for i, c in enumerate(raw_chunks):
        if i > 0 and overlap > 0:
            prev_tail = raw_chunks[i - 1][-overlap:]
            c = prev_tail + "\n" + c
        c = c.strip()
        if len(c) > 20:
            final_chunks.append(c)

    return final_chunks
