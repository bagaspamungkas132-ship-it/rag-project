"""
Agent 1 - AI Alco/FTP
Fungsi: menentukan modal dasar bank untuk menetapkan Fund Transfer Pricing (FTP)
ke segment dan product. Owner: ALCO, including Treasury.

Untuk hackathon, "AI" di sini disederhanakan jadi rule-based lookup dari FTP
table + sedikit penyesuaian likuiditas. Di production sebenarnya, bagian ini
diisi model time-series forecasting atas stock of money, supply/demand harian,
benchmark kompetitor, dan tren pasar.

Dua sumber FTP, dua status kematangan:

1. `data/ftp_curve.csv` - kurva FTP TENOR-ONLY (matched-maturity), berlaku
   untuk produk yang sudah dikalibrasi ke rate publik OCBC (lihat
   agent2_product_rate.py). Ini pendekatan FTP yang "benar" secara teori:
   FTP mencerminkan cost of funds bank di tenor tsb, TIDAK bergantung pada
   segmen nasabah atau produk mana yang membungkusnya - satu curve untuk
   semua, di-maintain Treasury di SATU tempat. Treasury tinggal edit angka
   `ftp_rate` di CSV ini kalau cost of funds berubah; tidak perlu sentuh
   kode Python sama sekali.
2. `data/ftp_table.csv` - tabel lama, per (segment, product, tenor_months).
   Dipertahankan untuk produk yang belum ada referensi rate publik untuk
   dikalibrasi (mis. TAKA Online) - supaya migrasi bisa bertahap per
   produk, bukan big-bang.

CURVE_PRODUCTS di bawah menentukan produk mana yang sudah pakai kurva baru.
"""
import csv
import os

FTP_TABLE_PATH = os.path.join(os.path.dirname(__file__), "data", "ftp_table.csv")
FTP_CURVE_PATH = os.path.join(os.path.dirname(__file__), "data", "ftp_curve.csv")

# Produk yang FTP-nya sudah dipindah ke kurva tenor-only (data/ftp_curve.csv)
# karena sudah dikalibrasi ke rate publik yang riil (lihat komentar sumber
# di agent2_product_rate.py). Produk lain masih pakai ftp_table.csv lama.
CURVE_PRODUCTS = {"Deposito Online"}


def _load_ftp_table() -> list[dict]:
    with open(FTP_TABLE_PATH, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _load_ftp_curve() -> dict:
    with open(FTP_CURVE_PATH, newline="", encoding="utf-8") as f:
        return {int(row["tenor_months"]): float(row["ftp_rate"]) for row in csv.DictReader(f)}


def get_ftp(segment: str, product: str, tenor_months: int) -> float:
    """Look up the base FTP rate (% p.a.) for a segment/product/tenor combo.
    For products in CURVE_PRODUCTS, `segment` is ignored on purpose - FTP is
    matched-maturity (tenor-only), not segment-dependent; segment-level
    differentiation happens later, in Agent 2's margin."""
    if product in CURVE_PRODUCTS:
        curve = _load_ftp_curve()
        if tenor_months in curve:
            return curve[tenor_months]
        # Tenor belum ada di kurva - Treasury belum isi. Fallback aman
        # supaya demo tidak crash, tapi ini seharusnya tidak pernah kepakai
        # di production (kurva harus lengkap untuk semua tenor yang dijual).
        return 3.50

    table = _load_ftp_table()
    for row in table:
        if (
            row["segment"] == segment
            and row["product"] == product
            and int(row["tenor_months"]) == tenor_months
        ):
            return float(row["ftp_rate"])
    # Fallback: if the exact combo isn't in the table, use a safe default
    return 3.50


def adjust_ftp_for_liquidity(base_ftp: float, liquidity_ratio: float = 1.0) -> float:
    """
    Small illustrative adjustment: if the bank has excess liquidity
    (ratio > 1), it can afford to offer a slightly higher FTP to attract
    more funding; if liquidity is tight (ratio < 1), FTP tightens.
    This stands in for the daily supply/demand + market trend inputs.
    """
    adjustment = (liquidity_ratio - 1.0) * 0.10  # max +/-0.10% for demo purposes
    return round(base_ftp + adjustment, 2)


if __name__ == "__main__":
    for tenor in (1, 3, 6, 12):
        rate = get_ftp("Emerging Affluent", "Deposito Online", tenor)
        print(f"FTP Deposito Online, {tenor}m: {rate}% p.a. (tenor-only curve, segment ignored)")
    rate = get_ftp("Emerging Affluent", "TAKA Online", 12)
    print(f"FTP TAKA Online, 12m: {rate}% p.a. (legacy segment-based table)")
