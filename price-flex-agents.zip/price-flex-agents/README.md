# Price Flex — 4-Agent Pricing Pipeline

Implementasi 4 agent sesuai diagram: **AI Alco/FTP → AI Product Rate → AI Dynamic Rate → AI Conductor**.

## Struktur folder
```
price-flex-agents/
├── requirements.txt
├── .env.example
├── run_demo.py              <- jalankan ini duluan (tanpa API key)
├── app.py                   <- dashboard Streamlit (tanpa API key)
├── data/
│   ├── generate_data.py     <- generator data training sintetis
│   └── customer_data.csv    <- 300 baris data nasabah (dihasilkan otomatis)
├── models/
│   └── dynamic_rate_model.pkl  <- model ML terlatih (dihasilkan otomatis)
└── src/
    ├── pricing_engine.py    <- Agent 1 & 2 (kalkulasi deterministik)
    ├── train_model.py       <- training model Agent 3
    ├── dynamic_rate_model.py<- Agent 3 (prediksi + guardrail)
    ├── conductor_rules.py   <- Agent 4 (logika jadwal, non-LLM)
    ├── tools.py              <- pembungkus semua di atas jadi CrewAI Tool
    └── crew.py               <- 4 CrewAI Agent + Task + Crew (BUTUH API key)
```

## Cara pakai (langkah demi langkah)

### 1. Setup environment
```bash
cd price-flex-agents
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Generate data & latih model (sekali saja)
```bash
python3 data/generate_data.py    # buat data/customer_data.csv (300 baris)
python3 src/train_model.py       # latih model, simpan ke models/dynamic_rate_model.pkl
```
Kamu akan lihat metrik model (MAE, R², feature importance) — ini bagus untuk
ditunjukkan ke juri sebagai bukti model benar-benar belajar dari data, bukan
rule statis.

### 3. Uji pipeline TANPA API key (paling cepat, paling aman untuk demo)
```bash
python3 run_demo.py
```
Ini menjalankan Agent 1→2→3→4 murni pakai Python (kalkulasi + model ML asli),
pesan notifikasi pakai template teks. Kalau ini jalan lancar, logika inti
kamu sudah benar.

### 4. Jalankan dashboard visual (untuk demo ke juri)
```bash
streamlit run app.py
```
Buka browser ke `http://localhost:8501`. Kamu bisa ubah slider market context
dan form profil nasabah secara live, lalu klik "Jalankan Pipeline Price Flex"
— hasil tiap agent tampil sebagai 4 kartu metrik + draf notifikasi.

### 5. (Opsional) Versi penuh dengan LLM menulis pesan notifikasi
Ini pakai CrewAI beneran — 4 agent saling lempar hasil, dan Agent 4 menulis
pesan notifikasi dengan bahasa natural (bukan template).
```bash
cp .env.example .env
# edit .env, isi ANTHROPIC_API_KEY kamu
export $(cat .env | xargs)      # atau pakai python-dotenv
python3 -m src.crew
```
Kalau mau pakai OpenAI/Gemini, ganti `MODEL_NAME` di `src/crew.py` dan isi
API key yang sesuai di `.env`.

## Kenapa dipisah jadi 2 mode (dengan & tanpa LLM)?

Sebagai catatan strategi demo: **jangan taruh semua telur di satu keranjang**.
Mode `run_demo.py` / `app.py` (tanpa LLM) menjamin kamu selalu punya demo yang
jalan 100% pasti, tanpa risiko API key habis kredit/limit/error jaringan pas
di depan juri — persis pelajaran dari masalah "out of credits" di Copilot
Studio kemarin. Mode `src/crew.py` (dengan LLM) dipakai kalau kamu mau
menunjukkan versi "penuh" dengan agent yang benar-benar berkomunikasi dan
menulis bahasa natural — tapi siapkan sebagai bonus, bukan tulang punggung
demo.

## Menyesuaikan angka ke kondisi nyata

Semua angka contoh (base_cost_of_fund, margin per produk, guardrail rate,
bobot fitur di data sintetis) **BUKAN angka resmi OCBC** — ganti sesuai data/
approval treasury yang sebenarnya kamu dapatkan:
- `src/pricing_engine.py` → `PRODUCT_MARGIN_TABLE`, `PREMI_FACTORS`
- `src/dynamic_rate_model.py` → `GUARDRAIL`
- `data/generate_data.py` → ganti dengan data nasabah asli/sample resmi kalau
  ada (format kolom harus sama dengan `FEATURES` di `src/train_model.py`)

## Troubleshooting singkat
- **ImportError terkait provider LLM** (mis. "Anthropic native provider not
  available") → jalankan `pip install "crewai[anthropic]"` (sudah termasuk di
  `requirements.txt`).
- **ModuleNotFoundError: No module named 'src'** saat run manual → pastikan
  kamu menjalankan perintah dari folder root `price-flex-agents/`, bukan dari
  dalam folder `src/`.
- **Model belum ada (`dynamic_rate_model.pkl` not found)** → jalankan langkah
  2 (`generate_data.py` lalu `train_model.py`) dulu sebelum `run_demo.py` atau
  `app.py`.
