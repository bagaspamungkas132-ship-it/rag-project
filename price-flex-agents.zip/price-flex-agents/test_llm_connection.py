"""
test_llm_connection.py
Tes koneksi langsung ke endpoint LLM internal (Qwen) TANPA CrewAI -- supaya
kalau ada error, pesannya jelas (bukan "ditelan" lapisan CrewAI).

Jalankan: python3 test_llm_connection.py
(dari folder root project, sejajar dengan file .env)
"""
import os
from dotenv import load_dotenv

load_dotenv()  # baca .env di folder yang sama dengan file ini

base_url = os.getenv("PRICE_FLEX_LLM_BASE_URL")
api_key = os.getenv("PRICE_FLEX_LLM_API_KEY")
model = os.getenv("PRICE_FLEX_LLM_MODEL")

print(f"base_url = {base_url}")
print(f"model    = {model}")
print(f"api_key  = {'(terisi, ' + str(len(api_key)) + ' karakter)' if api_key else '(KOSONG!)'}")
print("-" * 60)

from openai import OpenAI

client = OpenAI(api_key=api_key, base_url=base_url)

resp = client.chat.completions.create(
    model=model,
    messages=[{"role": "user", "content": "halo, ini tes koneksi"}],
    max_tokens=20,
)
print(resp)
