"""
Agent 3 - AI Dynamic Rate
Fungsi: menentukan special rate per customer berdasarkan Customer Life Time
Value dan berbagai variable atribut per customer. Owner: Product Owner,
Segment/Proposition Owner.

Skoring sekarang punya 2 jalur:

1. **XGBoost (utama)** - model dilatih di agent3_train_model.py dari
   data/historical_customers.csv (histori konversi nasabah), skor = P(nasabah
   akan merespons positif) x 100. Ini yang dipakai kalau package `xgboost`
   ter-install DAN file model/agent3_clv_model.json ada.
2. **Rule-based (fallback)** - weighted formula manual (AUM 40%, vintage 25%,
   profitability 20%, engagement 15%) yang dipakai versi sebelumnya. Dipakai
   otomatis kalau xgboost belum ter-install atau model belum dilatih, supaya
   demo TIDAK PERNAH gagal total hanya karena satu library ML belum ada di
   environment (sama seperti prinsip fallback LLM di llm_client.py).

Guardrail (batas kenaikan rate) WAJIB ada di kedua jalur, supaya tidak jadi
pricing bebas/diskriminatif - lihat GUARDRAIL_MAX_UPLIFT di bawah.
"""
import json
import os

from agent3_features import FEATURE_NAMES, encode_features

# Guardrail: kenaikan rate personal maksimum di atas base rate, dalam % poin.
# Angka ini yang secara konsep harus disetujui Treasury/ALCO.
GUARDRAIL_MAX_UPLIFT = 0.95  # contoh: base 3.80% -> max personal rate 4.75%

# Asumsi rentang normalisasi dipakai HANYA oleh jalur rule-based
# (production: ambil dari distribusi data aktual).
AUM_MAX = 500_000_000
VINTAGE_MAX_YEARS = 15

MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")
MODEL_PATH = os.path.join(MODEL_DIR, "agent3_clv_model.json")
METADATA_PATH = os.path.join(MODEL_DIR, "agent3_model_metadata.json")

_model = None
_model_load_error = None
try:
    import xgboost as xgb

    if os.path.exists(MODEL_PATH):
        try:
            _model = xgb.Booster()
            _model.load_model(MODEL_PATH)
        except Exception as e:  # model file corrupt/incompatible
            _model_load_error = f"Gagal load model file: {e}"
    else:
        _model_load_error = "Model belum dilatih (file model/agent3_clv_model.json tidak ada)."
except ImportError as e:
    _model_load_error = f"Package 'xgboost' belum ter-install ({e})."


def _load_metadata() -> dict:
    if os.path.exists(METADATA_PATH):
        try:
            with open(METADATA_PATH, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


_METADATA = _load_metadata()


def get_scoring_method() -> dict:
    """Info transparansi buat ditampilkan di Streamlit: metode skor mana
    yang SEDANG aktif dipakai, plus metadata model (AUC, feature importance)
    kalau ada - baik model sedang aktif atau tidak (supaya tetap kelihatan
    "kalau xgboost di-install, ini kualitas model yang sudah disiapkan")."""
    return {
        "method": "xgboost" if _model is not None else "rule_based",
        "fallback_reason": None if _model is not None else _model_load_error,
        "metadata": _METADATA,
    }


def _normalize(value: float, max_value: float) -> float:
    return max(0.0, min(1.0, value / max_value))


def _score_rule_based(customer: dict) -> float:
    """
    Menghasilkan skor 0-100 sebagai proxy Customer Lifetime Value.
    Bobot: AUM 40%, vintage 25%, profitability 20%, engagement 15%.
    Dipakai sebagai fallback kalau model XGBoost tidak tersedia.
    """
    aum_score = _normalize(customer["aum_idr"], AUM_MAX)
    vintage_score = _normalize(customer["vintage_years"], VINTAGE_MAX_YEARS)
    profitability_score = customer["profitability_score"] / 100
    engagement_score = customer["engagement_score"] / 100

    score = (
        0.40 * aum_score
        + 0.25 * vintage_score
        + 0.20 * profitability_score
        + 0.15 * engagement_score
    ) * 100
    return round(score, 1)


def _score_with_xgboost(customer: dict) -> float:
    """Skor = probabilitas model bahwa nasabah ini akan merespons positif
    terhadap penawaran (dipelajari dari histori konversi), dikali 100."""
    features = encode_features(customer)
    dmatrix = xgb.DMatrix([features], feature_names=FEATURE_NAMES)
    prob = float(_model.predict(dmatrix)[0])
    return round(prob * 100, 1)


def score_customer(customer: dict) -> float:
    """Titik masuk tunggal yang dipakai Agent 4 - otomatis pakai XGBoost
    kalau tersedia, else fallback rule-based. Kalau prediksi XGBoost error
    di tengah jalan (mis. skema fitur berubah), tetap fallback, bukan crash."""
    if _model is not None:
        try:
            return _score_with_xgboost(customer)
        except Exception as e:
            print(f"[agent3] Prediksi XGBoost gagal, fallback ke rule-based. Alasan: {e}")
    return _score_rule_based(customer)


def get_personalized_rate(base_rate: float, score: float) -> float:
    """
    Memetakan skor (0-100) ke uplift rate, di-clamp ke GUARDRAIL_MAX_UPLIFT
    supaya tetap dalam batas yang disetujui Treasury. Berlaku sama persis
    untuk skor dari XGBoost maupun rule-based - guardrail tidak pernah
    bergantung pada metode skoring yang dipakai.
    """
    uplift = (score / 100) * GUARDRAIL_MAX_UPLIFT
    uplift = round(min(uplift, GUARDRAIL_MAX_UPLIFT), 2)
    return round(base_rate + uplift, 2)


def is_eligible(customer: dict, min_score: float = 30.0) -> bool:
    """Filter sederhana: hanya nasabah dengan skor di atas ambang batas
    yang berhak menerima penawaran dynamic rate."""
    return score_customer(customer) >= min_score


if __name__ == "__main__":
    dummy_customer = {
        "aum_idr": 300_000_000,
        "vintage_years": 6,
        "profitability_score": 70,
        "engagement_score": 60,
        "segment": "Emerging Affluent",
        "product_holding": "Full suite",
    }
    print(f"Metode skor aktif: {get_scoring_method()['method']}")
    s = score_customer(dummy_customer)
    print(f"Customer score: {s}")
    print(f"Personalized rate on base 3.80%: {get_personalized_rate(3.80, s)}%")
