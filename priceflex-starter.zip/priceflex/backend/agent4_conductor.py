"""
Agent 4 - AI Conductor
Fungsi: menampilkan offer ke customer baik berbasis aplikasi/web sesuai
jadwal program/campaign. Owner: Platform Owner, Segment/Proposition Owner.

Untuk hackathon: orkestrasi cukup pakai pemanggilan fungsi berurutan
(Agent 1 -> 2 -> 3), tidak perlu framework agent berat seperti
LangGraph/CrewAI kecuali ingin nilai tambah "agentic architecture".
"""
import csv
import os
import time

from agent2_product_rate import get_base_rate
from agent3_dynamic_rate import score_customer, get_personalized_rate, is_eligible
from llm_client import generate_offer_message

CUSTOMERS_PATH = os.path.join(os.path.dirname(__file__), "data", "customers.csv")

# Campaign config - dalam production ini datang dari campaign management tool
CAMPAIGN_PRODUCT = "Deposito Online"
CAMPAIGN_TENOR_MONTHS = 12
OFFER_VALID_SECONDS = 60 * 60  # 1 jam, selaras dengan mockup


def _load_customer(customer_id: int) -> dict | None:
    with open(CUSTOMERS_PATH, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if int(row["customer_id"]) == customer_id:
                row["aum_idr"] = int(row["aum_idr"])
                row["vintage_years"] = float(row["vintage_years"])
                row["profitability_score"] = float(row["profitability_score"])
                row["engagement_score"] = float(row["engagement_score"])
                return row
    return None


def generate_offer(customer_id: int) -> dict:
    """Menjalankan Agent 1 -> 2 -> 3 secara berurutan dan menyusun offer
    yang siap dikirim ke Agent Conductor (channel/UI)."""
    customer = _load_customer(customer_id)
    if customer is None:
        return {"error": f"Customer {customer_id} not found"}

    if not is_eligible(customer):
        return {
            "eligible": False,
            "message": "Nasabah belum memenuhi ambang batas untuk penawaran khusus.",
        }

    base_rate = get_base_rate(
        segment=customer["segment"],
        product=CAMPAIGN_PRODUCT,
        tenor_months=CAMPAIGN_TENOR_MONTHS,
    )
    score = score_customer(customer)
    personal_rate = get_personalized_rate(base_rate, score)

    return {
        "eligible": True,
        "customer_id": customer_id,
        "customer_name": customer["name"],
        "segment": customer["segment"],
        "product": CAMPAIGN_PRODUCT,
        "tenor_months": CAMPAIGN_TENOR_MONTHS,
        "base_rate": base_rate,
        "customer_score": score,
        "personalized_rate": personal_rate,
        "valid_until_epoch": int(time.time()) + OFFER_VALID_SECONDS,
        "message": generate_offer_message(
            customer_name=customer["name"],
            rate=personal_rate,
            tenor_months=CAMPAIGN_TENOR_MONTHS,
            product=CAMPAIGN_PRODUCT,
        ),
    }


if __name__ == "__main__":
    import json

    print(json.dumps(generate_offer(1), indent=2, ensure_ascii=False))
